import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/active_filters_widget.dart';
import './widgets/empty_state_widget.dart';
import './widgets/filter_bottom_sheet_widget.dart';
import './widgets/search_bar_widget.dart';
import './widgets/sort_modal_widget.dart';
import './widgets/trade_card_widget.dart';

class TradeList extends StatefulWidget {
  const TradeList({super.key});

  @override
  State<TradeList> createState() => _TradeListState();
}

class _TradeListState extends State<TradeList> with TickerProviderStateMixin {
  final ScrollController _scrollController = ScrollController();
  final TextEditingController _searchController = TextEditingController();

  // State variables
  List<Map<String, dynamic>> _allTrades = [];
  List<Map<String, dynamic>> _filteredTrades = [];
  Map<String, dynamic> _activeFilters = {};
  SortOption _currentSort = SortOption.dateNewest;
  String _searchQuery = '';
  List<String> _recentSearches = ['AAPL', 'BTC/USD', 'EUR/USD', 'Breakout'];

  // Selection state
  bool _isSelectionMode = false;
  Set<String> _selectedTradeIds = {};

  // Loading and pagination
  bool _isLoading = false;
  bool _isLoadingMore = false;
  bool _hasMoreData = true;
  int _currentPage = 1;
  final int _itemsPerPage = 20;

  @override
  void initState() {
    super.initState();
    _initializeTrades();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _initializeTrades() {
    setState(() {
      _isLoading = true;
    });

    // Mock trade data
    _allTrades = [
      {
        "id": "TRD001",
        "symbol": "AAPL",
        "marketType": "Equity",
        "position": "Long",
        "entryPrice": 175.50,
        "exitPrice": 182.30,
        "quantity": 100,
        "pnl": 680.00,
        "date": "08/09/2025",
        "strategy": "Breakout",
        "confidence": 8,
        "timestamp": DateTime.now().subtract(const Duration(days: 1)),
      },
      {
        "id": "TRD002",
        "symbol": "BTC/USD",
        "marketType": "Crypto",
        "position": "Short",
        "entryPrice": 45200.00,
        "exitPrice": 43800.00,
        "quantity": 0.5,
        "pnl": 700.00,
        "date": "08/08/2025",
        "strategy": "Reversal",
        "confidence": 7,
        "timestamp": DateTime.now().subtract(const Duration(days: 2)),
      },
      {
        "id": "TRD003",
        "symbol": "EUR/USD",
        "marketType": "Forex",
        "position": "Long",
        "entryPrice": 1.0850,
        "exitPrice": 1.0820,
        "quantity": 10000,
        "pnl": -300.00,
        "date": "08/07/2025",
        "strategy": "Pullback",
        "confidence": 6,
        "timestamp": DateTime.now().subtract(const Duration(days: 3)),
      },
      {
        "id": "TRD004",
        "symbol": "TSLA",
        "marketType": "Equity",
        "position": "Long",
        "entryPrice": 245.80,
        "exitPrice": 252.40,
        "quantity": 50,
        "pnl": 330.00,
        "date": "08/06/2025",
        "strategy": "Momentum",
        "confidence": 9,
        "timestamp": DateTime.now().subtract(const Duration(days: 4)),
      },
      {
        "id": "TRD005",
        "symbol": "ETH/USD",
        "marketType": "Crypto",
        "position": "Short",
        "entryPrice": 2850.00,
        "exitPrice": 2920.00,
        "quantity": 2,
        "pnl": -140.00,
        "date": "08/05/2025",
        "strategy": "Mean Reversion",
        "confidence": 5,
        "timestamp": DateTime.now().subtract(const Duration(days: 5)),
      },
      {
        "id": "TRD006",
        "symbol": "GBP/USD",
        "marketType": "Forex",
        "position": "Long",
        "entryPrice": 1.2750,
        "exitPrice": 1.2810,
        "quantity": 15000,
        "pnl": 900.00,
        "date": "08/04/2025",
        "strategy": "Breakout",
        "confidence": 8,
        "timestamp": DateTime.now().subtract(const Duration(days: 6)),
      },
      {
        "id": "TRD007",
        "symbol": "NVDA",
        "marketType": "Equity",
        "position": "Short",
        "entryPrice": 485.20,
        "exitPrice": 478.90,
        "quantity": 25,
        "pnl": 157.50,
        "date": "08/03/2025",
        "strategy": "Scalping",
        "confidence": 7,
        "timestamp": DateTime.now().subtract(const Duration(days: 7)),
      },
      {
        "id": "TRD008",
        "symbol": "SOL/USD",
        "marketType": "Crypto",
        "position": "Long",
        "entryPrice": 95.40,
        "exitPrice": 88.20,
        "quantity": 10,
        "pnl": -72.00,
        "date": "08/02/2025",
        "strategy": "Swing Trading",
        "confidence": 6,
        "timestamp": DateTime.now().subtract(const Duration(days: 8)),
      },
    ];

    _applyFiltersAndSort();

    setState(() {
      _isLoading = false;
    });
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 200) {
      _loadMoreTrades();
    }
  }

  void _loadMoreTrades() {
    if (_isLoadingMore || !_hasMoreData) return;

    setState(() {
      _isLoadingMore = true;
    });

    // Simulate loading more data
    Future.delayed(const Duration(milliseconds: 1000), () {
      if (mounted) {
        setState(() {
          _isLoadingMore = false;
          _currentPage++;
          // In a real app, you would load more data here
          if (_currentPage > 3) {
            _hasMoreData = false;
          }
        });
      }
    });
  }

  void _applyFiltersAndSort() {
    List<Map<String, dynamic>> filtered = List.from(_allTrades);

    // Apply search filter
    if (_searchQuery.isNotEmpty) {
      filtered = filtered.where((trade) {
        final symbol = trade['symbol'].toString().toLowerCase();
        final strategy = trade['strategy'].toString().toLowerCase();
        final marketType = trade['marketType'].toString().toLowerCase();
        final query = _searchQuery.toLowerCase();

        return symbol.contains(query) ||
            strategy.contains(query) ||
            marketType.contains(query);
      }).toList();
    }

    // Apply date range filter
    if (_activeFilters['dateRange'] != null) {
      final dateRange = _activeFilters['dateRange'] as DateTimeRange;
      filtered = filtered.where((trade) {
        final tradeDate = trade['timestamp'] as DateTime;
        return tradeDate
                .isAfter(dateRange.start.subtract(const Duration(days: 1))) &&
            tradeDate.isBefore(dateRange.end.add(const Duration(days: 1)));
      }).toList();
    }

    // Apply market type filter
    if (_activeFilters['marketTypes'] != null) {
      final marketTypes = _activeFilters['marketTypes'] as List<String>;
      filtered = filtered.where((trade) {
        return marketTypes.contains(trade['marketType']);
      }).toList();
    }

    // Apply strategy filter
    if (_activeFilters['strategies'] != null) {
      final strategies = _activeFilters['strategies'] as List<String>;
      filtered = filtered.where((trade) {
        return strategies.contains(trade['strategy']);
      }).toList();
    }

    // Apply P&L range filter
    if (_activeFilters['pnlRange'] != null) {
      final pnlRange = _activeFilters['pnlRange'] as RangeValues;
      filtered = filtered.where((trade) {
        final pnl = (trade['pnl'] as num).toDouble();
        return pnl >= pnlRange.start && pnl <= pnlRange.end;
      }).toList();
    }

    // Apply sorting
    _sortTrades(filtered);

    setState(() {
      _filteredTrades = filtered;
    });
  }

  void _sortTrades(List<Map<String, dynamic>> trades) {
    switch (_currentSort) {
      case SortOption.dateNewest:
        trades.sort((a, b) =>
            (b['timestamp'] as DateTime).compareTo(a['timestamp'] as DateTime));
        break;
      case SortOption.dateOldest:
        trades.sort((a, b) =>
            (a['timestamp'] as DateTime).compareTo(b['timestamp'] as DateTime));
        break;
      case SortOption.pnlHighest:
        trades.sort((a, b) => (b['pnl'] as num).compareTo(a['pnl'] as num));
        break;
      case SortOption.pnlLowest:
        trades.sort((a, b) => (a['pnl'] as num).compareTo(b['pnl'] as num));
        break;
      case SortOption.symbolAZ:
        trades.sort(
            (a, b) => a['symbol'].toString().compareTo(b['symbol'].toString()));
        break;
      case SortOption.symbolZA:
        trades.sort(
            (a, b) => b['symbol'].toString().compareTo(a['symbol'].toString()));
        break;
      case SortOption.strategyAZ:
        trades.sort((a, b) =>
            a['strategy'].toString().compareTo(b['strategy'].toString()));
        break;
      case SortOption.strategyZA:
        trades.sort((a, b) =>
            b['strategy'].toString().compareTo(a['strategy'].toString()));
        break;
    }
  }

  void _onSearchChanged(String query) {
    setState(() {
      _searchQuery = query;
    });
    _applyFiltersAndSort();

    // Add to recent searches if not empty and not already present
    if (query.isNotEmpty && !_recentSearches.contains(query)) {
      setState(() {
        _recentSearches.insert(0, query);
        if (_recentSearches.length > 10) {
          _recentSearches = _recentSearches.take(10).toList();
        }
      });
    }
  }

  void _onFiltersChanged(Map<String, dynamic> filters) {
    setState(() {
      _activeFilters = filters;
    });
    _applyFiltersAndSort();
  }

  void _onSortChanged(SortOption sort) {
    setState(() {
      _currentSort = sort;
    });
    _applyFiltersAndSort();
  }

  void _onRemoveFilter(String filterKey) {
    setState(() {
      if (filterKey.startsWith('marketTypes_')) {
        final type = filterKey.substring('marketTypes_'.length);
        if (_activeFilters['marketTypes'] != null) {
          (_activeFilters['marketTypes'] as List<String>).remove(type);
          if ((_activeFilters['marketTypes'] as List<String>).isEmpty) {
            _activeFilters.remove('marketTypes');
          }
        }
      } else if (filterKey.startsWith('strategies_')) {
        final strategy = filterKey.substring('strategies_'.length);
        if (_activeFilters['strategies'] != null) {
          (_activeFilters['strategies'] as List<String>).remove(strategy);
          if ((_activeFilters['strategies'] as List<String>).isEmpty) {
            _activeFilters.remove('strategies');
          }
        }
      } else {
        _activeFilters.remove(filterKey);
      }
    });
    _applyFiltersAndSort();
  }

  void _clearAllFilters() {
    setState(() {
      _activeFilters.clear();
      _searchQuery = '';
      _searchController.clear();
    });
    _applyFiltersAndSort();
  }

  void _toggleSelection(String tradeId) {
    setState(() {
      if (_selectedTradeIds.contains(tradeId)) {
        _selectedTradeIds.remove(tradeId);
        if (_selectedTradeIds.isEmpty) {
          _isSelectionMode = false;
        }
      } else {
        _selectedTradeIds.add(tradeId);
        _isSelectionMode = true;
      }
    });
  }

  void _exitSelectionMode() {
    setState(() {
      _isSelectionMode = false;
      _selectedTradeIds.clear();
    });
  }

  void _showFilterBottomSheet() {
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => FilterBottomSheetWidget(
        currentFilters: _activeFilters,
        onFiltersChanged: _onFiltersChanged,
      ),
    );
  }

  void _showSortModal() {
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => SortModalWidget(
        currentSort: _currentSort,
        onSortChanged: _onSortChanged,
      ),
    );
  }

  Future<void> _onRefresh() async {
    HapticFeedback.lightImpact();
    await Future.delayed(const Duration(milliseconds: 1000));
    _initializeTrades();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      appBar: _buildAppBar(theme, colorScheme),
      body: Column(
        children: [
          // Search bar
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
            child: SearchBarWidget(
              initialQuery: _searchQuery,
              onSearchChanged: _onSearchChanged,
              onClear: () {
                setState(() {
                  _searchQuery = '';
                });
                _applyFiltersAndSort();
              },
              recentSearches: _recentSearches,
              onRecentSearchTap: (query) {
                setState(() {
                  _searchQuery = query;
                });
                _applyFiltersAndSort();
              },
            ),
          ),

          // Active filters
          ActiveFiltersWidget(
            activeFilters: _activeFilters,
            onRemoveFilter: _onRemoveFilter,
            onClearAll: _clearAllFilters,
          ),

          // Trade list
          Expanded(
            child: _isLoading
                ? _buildLoadingState()
                : _filteredTrades.isEmpty
                    ? _buildEmptyState()
                    : _buildTradeList(),
          ),
        ],
      ),
      floatingActionButton: _isSelectionMode
          ? null
          : FloatingActionButton(
              onPressed: () {
                HapticFeedback.lightImpact();
                Navigator.pushNamed(context, '/add-trade');
              },
              child: CustomIconWidget(
                iconName: 'add',
                size: 24,
                color: Colors.white,
              ),
            ),
    );
  }

  PreferredSizeWidget _buildAppBar(ThemeData theme, ColorScheme colorScheme) {
    if (_isSelectionMode) {
      return AppBar(
        backgroundColor: colorScheme.surface,
        elevation: 0,
        leading: IconButton(
          onPressed: _exitSelectionMode,
          icon: CustomIconWidget(
            iconName: 'close',
            size: 24,
            color: colorScheme.onSurface,
          ),
        ),
        title: Text(
          '${_selectedTradeIds.length} selected',
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              // Handle bulk edit
              HapticFeedback.lightImpact();
            },
            icon: CustomIconWidget(
              iconName: 'edit',
              size: 24,
              color: colorScheme.onSurface,
            ),
          ),
          IconButton(
            onPressed: () {
              // Handle bulk delete
              HapticFeedback.lightImpact();
            },
            icon: CustomIconWidget(
              iconName: 'delete',
              size: 24,
              color: colorScheme.error,
            ),
          ),
        ],
      );
    }

    return AppBar(
      backgroundColor: colorScheme.surface,
      elevation: 0,
      title: Text(
        'Trade History',
        style: theme.textTheme.titleLarge?.copyWith(
          fontWeight: FontWeight.w600,
        ),
      ),
      actions: [
        IconButton(
          onPressed: _showFilterBottomSheet,
          icon: Stack(
            children: [
              CustomIconWidget(
                iconName: 'filter_list',
                size: 24,
                color: colorScheme.onSurface,
              ),
              if (_activeFilters.isNotEmpty)
                Positioned(
                  right: 0,
                  top: 0,
                  child: Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: colorScheme.primary,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
            ],
          ),
        ),
        IconButton(
          onPressed: _showSortModal,
          icon: CustomIconWidget(
            iconName: 'sort',
            size: 24,
            color: colorScheme.onSurface,
          ),
        ),
      ],
    );
  }

  Widget _buildLoadingState() {
    return ListView.builder(
      padding: EdgeInsets.symmetric(vertical: 2.h),
      itemCount: 8,
      itemBuilder: (context, index) => Container(
        margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
        height: 15.h,
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    if (_searchQuery.isNotEmpty) {
      return EmptyStateWidget.searchResults(
        searchQuery: _searchQuery,
        onClearSearch: () {
          setState(() {
            _searchQuery = '';
            _searchController.clear();
          });
          _applyFiltersAndSort();
        },
      );
    } else if (_activeFilters.isNotEmpty) {
      return EmptyStateWidget.filteredResults(
        onClearFilters: _clearAllFilters,
      );
    } else {
      return EmptyStateWidget(
        onButtonPressed: () {
          Navigator.pushNamed(context, '/add-trade');
        },
      );
    }
  }

  Widget _buildTradeList() {
    return RefreshIndicator(
      onRefresh: _onRefresh,
      child: ListView.builder(
        controller: _scrollController,
        padding: EdgeInsets.symmetric(vertical: 1.h),
        itemCount: _filteredTrades.length + (_isLoadingMore ? 1 : 0),
        itemBuilder: (context, index) {
          if (index == _filteredTrades.length) {
            return _buildLoadingMoreIndicator();
          }

          final trade = _filteredTrades[index];
          final tradeId = trade['id'] as String;
          final isSelected = _selectedTradeIds.contains(tradeId);

          return TradeCardWidget(
            trade: trade,
            isSelected: isSelected,
            onTap: () {
              if (_isSelectionMode) {
                _toggleSelection(tradeId);
              } else {
                Navigator.pushNamed(context, '/trade-detail', arguments: trade);
              }
            },
            onLongPress: () {
              _toggleSelection(tradeId);
            },
            onEdit: () {
              Navigator.pushNamed(context, '/add-trade', arguments: trade);
            },
            onDuplicate: () {
              final duplicatedTrade = Map<String, dynamic>.from(trade);
              duplicatedTrade['id'] =
                  'TRD${DateTime.now().millisecondsSinceEpoch}';
              Navigator.pushNamed(context, '/add-trade',
                  arguments: duplicatedTrade);
            },
            onDelete: () {
              setState(() {
                _allTrades.removeWhere((t) => t['id'] == tradeId);
              });
              _applyFiltersAndSort();
            },
          );
        },
      ),
    );
  }

  Widget _buildLoadingMoreIndicator() {
    return Container(
      padding: EdgeInsets.all(4.w),
      child: const Center(
        child: CircularProgressIndicator(),
      ),
    );
  }
}
