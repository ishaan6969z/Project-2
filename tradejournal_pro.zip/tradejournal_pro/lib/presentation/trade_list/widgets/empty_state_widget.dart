import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class EmptyStateWidget extends StatelessWidget {
  final String title;
  final String subtitle;
  final String buttonText;
  final VoidCallback? onButtonPressed;
  final bool isSearchResult;

  const EmptyStateWidget({
    super.key,
    this.title = 'No Trades Yet',
    this.subtitle =
        'Start your trading journey by adding your first trade. Track your performance and improve your strategy.',
    this.buttonText = 'Add Your First Trade',
    this.onButtonPressed,
    this.isSearchResult = false,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Center(
      child: Padding(
        padding: EdgeInsets.all(8.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Illustration
            Container(
              width: 40.w,
              height: 40.w,
              decoration: BoxDecoration(
                color: colorScheme.primary.withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: CustomIconWidget(
                iconName: isSearchResult ? 'search_off' : 'trending_up',
                size: 60,
                color: colorScheme.primary.withValues(alpha: 0.6),
              ),
            ),

            SizedBox(height: 4.h),

            // Title
            Text(
              title,
              style: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w600,
                color: colorScheme.onSurface,
                fontSize: 20.sp,
              ),
              textAlign: TextAlign.center,
            ),

            SizedBox(height: 2.h),

            // Subtitle
            Text(
              subtitle,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: colorScheme.onSurfaceVariant,
                fontSize: 14.sp,
                height: 1.5,
              ),
              textAlign: TextAlign.center,
            ),

            SizedBox(height: 4.h),

            // Action button
            if (onButtonPressed != null)
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () {
                    HapticFeedback.lightImpact();
                    onButtonPressed?.call();
                  },
                  icon: CustomIconWidget(
                    iconName: isSearchResult ? 'refresh' : 'add',
                    size: 20,
                    color: Colors.white,
                  ),
                  label: Text(
                    buttonText,
                    style: theme.textTheme.labelLarge?.copyWith(
                      fontWeight: FontWeight.w600,
                      fontSize: 14.sp,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(vertical: 1.8.h),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),

            if (!isSearchResult) ...[
              SizedBox(height: 3.h),

              // Quick tips
              Container(
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  color: colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        CustomIconWidget(
                          iconName: 'lightbulb',
                          size: 16,
                          color: colorScheme.primary,
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          'Quick Tips',
                          style: theme.textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.w600,
                            color: colorScheme.primary,
                            fontSize: 12.sp,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 1.5.h),
                    _buildTip(
                      context,
                      'Log every trade immediately after execution',
                      'schedule',
                    ),
                    SizedBox(height: 1.h),
                    _buildTip(
                      context,
                      'Include your emotional state and confidence level',
                      'psychology',
                    ),
                    SizedBox(height: 1.h),
                    _buildTip(
                      context,
                      'Review and analyze your trades regularly',
                      'analytics',
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildTip(BuildContext context, String text, String iconName) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: EdgeInsets.only(top: 0.2.h),
          child: CustomIconWidget(
            iconName: iconName,
            size: 12,
            color: colorScheme.onSurfaceVariant,
          ),
        ),
        SizedBox(width: 2.w),
        Expanded(
          child: Text(
            text,
            style: theme.textTheme.bodySmall?.copyWith(
              color: colorScheme.onSurfaceVariant,
              fontSize: 11.sp,
              height: 1.4,
            ),
          ),
        ),
      ],
    );
  }

  /// Factory constructor for search results
  factory EmptyStateWidget.searchResults({
    Key? key,
    required String searchQuery,
    VoidCallback? onClearSearch,
  }) {
    return EmptyStateWidget(
      key: key,
      title: 'No Results Found',
      subtitle:
          'No trades match "$searchQuery". Try adjusting your search terms or clearing filters.',
      buttonText: 'Clear Search',
      onButtonPressed: onClearSearch,
      isSearchResult: true,
    );
  }

  /// Factory constructor for filtered results
  factory EmptyStateWidget.filteredResults({
    Key? key,
    VoidCallback? onClearFilters,
  }) {
    return EmptyStateWidget(
      key: key,
      title: 'No Matching Trades',
      subtitle:
          'No trades match your current filters. Try adjusting your filter criteria.',
      buttonText: 'Clear Filters',
      onButtonPressed: onClearFilters,
      isSearchResult: true,
    );
  }
}
