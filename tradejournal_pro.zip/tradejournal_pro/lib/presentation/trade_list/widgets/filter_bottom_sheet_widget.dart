import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class FilterBottomSheetWidget extends StatefulWidget {
  final Map<String, dynamic> currentFilters;
  final Function(Map<String, dynamic>) onFiltersChanged;

  const FilterBottomSheetWidget({
    super.key,
    required this.currentFilters,
    required this.onFiltersChanged,
  });

  @override
  State<FilterBottomSheetWidget> createState() =>
      _FilterBottomSheetWidgetState();
}

class _FilterBottomSheetWidgetState extends State<FilterBottomSheetWidget> {
  late Map<String, dynamic> _filters;
  DateTimeRange? _dateRange;
  RangeValues _pnlRange = const RangeValues(-1000, 1000);
  final List<String> _selectedMarketTypes = [];
  final List<String> _selectedStrategies = [];

  final List<String> _marketTypes = ['Equity', 'Crypto', 'Forex'];
  final List<String> _strategies = [
    'Breakout',
    'Pullback',
    'Reversal',
    'Momentum',
    'Mean Reversion',
    'Scalping',
    'Swing Trading'
  ];

  @override
  void initState() {
    super.initState();
    _filters = Map<String, dynamic>.from(widget.currentFilters);
    _initializeFilters();
  }

  void _initializeFilters() {
    if (_filters['dateRange'] != null) {
      _dateRange = _filters['dateRange'] as DateTimeRange;
    }
    if (_filters['pnlRange'] != null) {
      _pnlRange = _filters['pnlRange'] as RangeValues;
    }
    if (_filters['marketTypes'] != null) {
      _selectedMarketTypes
          .addAll((_filters['marketTypes'] as List).cast<String>());
    }
    if (_filters['strategies'] != null) {
      _selectedStrategies
          .addAll((_filters['strategies'] as List).cast<String>());
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      height: 85.h,
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Handle bar
          Container(
            margin: EdgeInsets.only(top: 1.h),
            width: 12.w,
            height: 0.5.h,
            decoration: BoxDecoration(
              color: colorScheme.onSurfaceVariant.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Header
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Row(
              children: [
                Text(
                  'Filter Trades',
                  style: theme.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                    fontSize: 18.sp,
                  ),
                ),
                const Spacer(),
                TextButton(
                  onPressed: _clearAllFilters,
                  child: Text(
                    'Clear All',
                    style: theme.textTheme.labelLarge?.copyWith(
                      color: colorScheme.primary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),

          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildDateRangeSection(theme, colorScheme),
                  SizedBox(height: 3.h),
                  _buildMarketTypeSection(theme, colorScheme),
                  SizedBox(height: 3.h),
                  _buildStrategySection(theme, colorScheme),
                  SizedBox(height: 3.h),
                  _buildPnLRangeSection(theme, colorScheme),
                  SizedBox(height: 4.h),
                ],
              ),
            ),
          ),

          // Apply button
          Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: colorScheme.surface,
              border: Border(
                top: BorderSide(
                  color: colorScheme.outline.withValues(alpha: 0.2),
                  width: 1,
                ),
              ),
            ),
            child: SafeArea(
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _applyFilters,
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(vertical: 1.5.h),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: Text(
                    'Apply Filters',
                    style: theme.textTheme.labelLarge?.copyWith(
                      fontWeight: FontWeight.w600,
                      fontSize: 14.sp,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDateRangeSection(ThemeData theme, ColorScheme colorScheme) {
    return _buildFilterSection(
      title: 'Date Range',
      child: InkWell(
        onTap: _selectDateRange,
        borderRadius: BorderRadius.circular(8),
        child: Container(
          padding: EdgeInsets.all(3.w),
          decoration: BoxDecoration(
            border:
                Border.all(color: colorScheme.outline.withValues(alpha: 0.3)),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Row(
            children: [
              CustomIconWidget(
                iconName: 'date_range',
                size: 20,
                color: colorScheme.onSurfaceVariant,
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Text(
                  _dateRange != null
                      ? '${_formatDate(_dateRange!.start)} - ${_formatDate(_dateRange!.end)}'
                      : 'Select date range',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: _dateRange != null
                        ? colorScheme.onSurface
                        : colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
              if (_dateRange != null)
                GestureDetector(
                  onTap: () {
                    setState(() {
                      _dateRange = null;
                    });
                  },
                  child: CustomIconWidget(
                    iconName: 'close',
                    size: 18,
                    color: colorScheme.onSurfaceVariant,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMarketTypeSection(ThemeData theme, ColorScheme colorScheme) {
    return _buildFilterSection(
      title: 'Market Type',
      child: Wrap(
        spacing: 2.w,
        runSpacing: 1.h,
        children: _marketTypes.map((type) {
          final isSelected = _selectedMarketTypes.contains(type);
          return FilterChip(
            label: Text(type),
            selected: isSelected,
            onSelected: (selected) {
              HapticFeedback.lightImpact();
              setState(() {
                if (selected) {
                  _selectedMarketTypes.add(type);
                } else {
                  _selectedMarketTypes.remove(type);
                }
              });
            },
            selectedColor: colorScheme.primary.withValues(alpha: 0.2),
            checkmarkColor: colorScheme.primary,
            labelStyle: theme.textTheme.labelMedium?.copyWith(
              color: isSelected
                  ? colorScheme.primary
                  : colorScheme.onSurfaceVariant,
              fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildStrategySection(ThemeData theme, ColorScheme colorScheme) {
    return _buildFilterSection(
      title: 'Strategy',
      child: Wrap(
        spacing: 2.w,
        runSpacing: 1.h,
        children: _strategies.map((strategy) {
          final isSelected = _selectedStrategies.contains(strategy);
          return FilterChip(
            label: Text(strategy),
            selected: isSelected,
            onSelected: (selected) {
              HapticFeedback.lightImpact();
              setState(() {
                if (selected) {
                  _selectedStrategies.add(strategy);
                } else {
                  _selectedStrategies.remove(strategy);
                }
              });
            },
            selectedColor: colorScheme.primary.withValues(alpha: 0.2),
            checkmarkColor: colorScheme.primary,
            labelStyle: theme.textTheme.labelMedium?.copyWith(
              color: isSelected
                  ? colorScheme.primary
                  : colorScheme.onSurfaceVariant,
              fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
              fontSize: 11.sp,
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildPnLRangeSection(ThemeData theme, ColorScheme colorScheme) {
    return _buildFilterSection(
      title: 'P&L Range',
      child: Column(
        children: [
          RangeSlider(
            values: _pnlRange,
            min: -5000,
            max: 5000,
            divisions: 100,
            labels: RangeLabels(
              '\$${_pnlRange.start.round()}',
              '\$${_pnlRange.end.round()}',
            ),
            onChanged: (values) {
              setState(() {
                _pnlRange = values;
              });
            },
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '\$${_pnlRange.start.round()}',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                ),
              ),
              Text(
                '\$${_pnlRange.end.round()}',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFilterSection({required String title, required Widget child}) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
            fontSize: 14.sp,
          ),
        ),
        SizedBox(height: 1.h),
        child,
      ],
    );
  }

  void _selectDateRange() async {
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      initialDateRange: _dateRange,
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: Theme.of(context).colorScheme.copyWith(
                  primary: Theme.of(context).colorScheme.primary,
                ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        _dateRange = picked;
      });
    }
  }

  void _clearAllFilters() {
    HapticFeedback.lightImpact();
    setState(() {
      _dateRange = null;
      _pnlRange = const RangeValues(-1000, 1000);
      _selectedMarketTypes.clear();
      _selectedStrategies.clear();
    });
  }

  void _applyFilters() {
    HapticFeedback.lightImpact();

    final filters = <String, dynamic>{};

    if (_dateRange != null) {
      filters['dateRange'] = _dateRange;
    }

    if (_selectedMarketTypes.isNotEmpty) {
      filters['marketTypes'] = List<String>.from(_selectedMarketTypes);
    }

    if (_selectedStrategies.isNotEmpty) {
      filters['strategies'] = List<String>.from(_selectedStrategies);
    }

    if (_pnlRange.start != -1000 || _pnlRange.end != 1000) {
      filters['pnlRange'] = _pnlRange;
    }

    widget.onFiltersChanged(filters);
    Navigator.of(context).pop();
  }

  String _formatDate(DateTime date) {
    return '${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')}/${date.year}';
  }
}
