import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class ActiveFiltersWidget extends StatelessWidget {
  final Map<String, dynamic> activeFilters;
  final Function(String) onRemoveFilter;
  final VoidCallback onClearAll;

  const ActiveFiltersWidget({
    super.key,
    required this.activeFilters,
    required this.onRemoveFilter,
    required this.onClearAll,
  });

  @override
  Widget build(BuildContext context) {
    if (activeFilters.isEmpty) {
      return const SizedBox.shrink();
    }

    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final filterChips = _buildFilterChips(context);

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Active Filters (${_getTotalFilterCount()})',
                style: theme.textTheme.labelMedium?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                  fontWeight: FontWeight.w600,
                  fontSize: 12.sp,
                ),
              ),
              const Spacer(),
              TextButton(
                onPressed: () {
                  HapticFeedback.lightImpact();
                  onClearAll();
                },
                style: TextButton.styleFrom(
                  padding:
                      EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                  minimumSize: Size.zero,
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
                child: Text(
                  'Clear All',
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: colorScheme.primary,
                    fontWeight: FontWeight.w600,
                    fontSize: 11.sp,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 0.5.h),
          Wrap(
            spacing: 2.w,
            runSpacing: 0.5.h,
            children: filterChips,
          ),
        ],
      ),
    );
  }

  List<Widget> _buildFilterChips(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final chips = <Widget>[];

    // Date range filter
    if (activeFilters['dateRange'] != null) {
      final dateRange = activeFilters['dateRange'] as DateTimeRange;
      chips.add(_buildFilterChip(
        context,
        'Date: ${_formatDate(dateRange.start)} - ${_formatDate(dateRange.end)}',
        'dateRange',
        colorScheme.primary,
      ));
    }

    // Market types filter
    if (activeFilters['marketTypes'] != null) {
      final marketTypes = activeFilters['marketTypes'] as List<String>;
      for (final type in marketTypes) {
        chips.add(_buildFilterChip(
          context,
          type,
          'marketTypes_$type',
          _getMarketTypeColor(type),
        ));
      }
    }

    // Strategies filter
    if (activeFilters['strategies'] != null) {
      final strategies = activeFilters['strategies'] as List<String>;
      for (final strategy in strategies) {
        chips.add(_buildFilterChip(
          context,
          strategy,
          'strategies_$strategy',
          colorScheme.tertiary,
        ));
      }
    }

    // P&L range filter
    if (activeFilters['pnlRange'] != null) {
      final pnlRange = activeFilters['pnlRange'] as RangeValues;
      chips.add(_buildFilterChip(
        context,
        'P&L: \$${pnlRange.start.round()} - \$${pnlRange.end.round()}',
        'pnlRange',
        colorScheme.secondary,
      ));
    }

    return chips;
  }

  Widget _buildFilterChip(
    BuildContext context,
    String label,
    String filterKey,
    Color color,
  ) {
    final theme = Theme.of(context);

    return Container(
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: color.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: InkWell(
        onTap: () {
          HapticFeedback.lightImpact();
          onRemoveFilter(filterKey);
        },
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.8.h),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Flexible(
                child: Text(
                  label,
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: color,
                    fontWeight: FontWeight.w600,
                    fontSize: 10.sp,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              SizedBox(width: 1.w),
              CustomIconWidget(
                iconName: 'close',
                size: 14,
                color: color,
              ),
            ],
          ),
        ),
      ),
    );
  }

  int _getTotalFilterCount() {
    int count = 0;

    if (activeFilters['dateRange'] != null) count++;
    if (activeFilters['marketTypes'] != null) {
      count += (activeFilters['marketTypes'] as List).length;
    }
    if (activeFilters['strategies'] != null) {
      count += (activeFilters['strategies'] as List).length;
    }
    if (activeFilters['pnlRange'] != null) count++;

    return count;
  }

  Color _getMarketTypeColor(String marketType) {
    switch (marketType.toLowerCase()) {
      case 'equity':
        return Colors.blue;
      case 'crypto':
        return Colors.orange;
      case 'forex':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  String _formatDate(DateTime date) {
    return '${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')}';
  }
}
