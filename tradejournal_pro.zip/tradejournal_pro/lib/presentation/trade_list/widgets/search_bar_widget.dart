import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class SearchBarWidget extends StatefulWidget {
  final String? initialQuery;
  final Function(String) onSearchChanged;
  final VoidCallback? onClear;
  final List<String> recentSearches;
  final Function(String)? onRecentSearchTap;

  const SearchBarWidget({
    super.key,
    this.initialQuery,
    required this.onSearchChanged,
    this.onClear,
    this.recentSearches = const [],
    this.onRecentSearchTap,
  });

  @override
  State<SearchBarWidget> createState() => _SearchBarWidgetState();
}

class _SearchBarWidgetState extends State<SearchBarWidget> {
  late TextEditingController _controller;
  late FocusNode _focusNode;
  bool _showRecentSearches = false;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialQuery);
    _focusNode = FocusNode();

    _focusNode.addListener(() {
      setState(() {
        _showRecentSearches = _focusNode.hasFocus &&
            _controller.text.isEmpty &&
            widget.recentSearches.isNotEmpty;
      });
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Column(
      children: [
        Container(
          height: 6.h,
          decoration: BoxDecoration(
            color: colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: _focusNode.hasFocus
                  ? colorScheme.primary
                  : colorScheme.outline.withValues(alpha: 0.3),
              width: _focusNode.hasFocus ? 2 : 1,
            ),
          ),
          child: Row(
            children: [
              Padding(
                padding: EdgeInsets.only(left: 3.w),
                child: CustomIconWidget(
                  iconName: 'search',
                  size: 20,
                  color: _focusNode.hasFocus
                      ? colorScheme.primary
                      : colorScheme.onSurfaceVariant,
                ),
              ),
              Expanded(
                child: TextField(
                  controller: _controller,
                  focusNode: _focusNode,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    fontSize: 14.sp,
                  ),
                  decoration: InputDecoration(
                    hintText: 'Search trades, symbols, strategies...',
                    hintStyle: theme.textTheme.bodyMedium?.copyWith(
                      color:
                          colorScheme.onSurfaceVariant.withValues(alpha: 0.6),
                      fontSize: 14.sp,
                    ),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: 3.w,
                      vertical: 1.h,
                    ),
                  ),
                  onChanged: (value) {
                    widget.onSearchChanged(value);
                    setState(() {
                      _showRecentSearches = value.isEmpty &&
                          _focusNode.hasFocus &&
                          widget.recentSearches.isNotEmpty;
                    });
                  },
                  onSubmitted: (value) {
                    if (value.isNotEmpty) {
                      _focusNode.unfocus();
                    }
                  },
                ),
              ),
              if (_controller.text.isNotEmpty)
                GestureDetector(
                  onTap: () {
                    HapticFeedback.lightImpact();
                    _controller.clear();
                    widget.onSearchChanged('');
                    widget.onClear?.call();
                    setState(() {
                      _showRecentSearches = _focusNode.hasFocus &&
                          widget.recentSearches.isNotEmpty;
                    });
                  },
                  child: Padding(
                    padding: EdgeInsets.only(right: 3.w),
                    child: CustomIconWidget(
                      iconName: 'close',
                      size: 18,
                      color: colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
            ],
          ),
        ),

        // Recent searches dropdown
        if (_showRecentSearches)
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            margin: EdgeInsets.only(top: 1.h),
            decoration: BoxDecoration(
              color: colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: colorScheme.shadow.withValues(alpha: 0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.all(3.w),
                  child: Row(
                    children: [
                      CustomIconWidget(
                        iconName: 'history',
                        size: 16,
                        color: colorScheme.onSurfaceVariant,
                      ),
                      SizedBox(width: 2.w),
                      Text(
                        'Recent Searches',
                        style: theme.textTheme.labelMedium?.copyWith(
                          color: colorScheme.onSurfaceVariant,
                          fontWeight: FontWeight.w600,
                          fontSize: 12.sp,
                        ),
                      ),
                    ],
                  ),
                ),
                ...widget.recentSearches
                    .take(5)
                    .map(
                      (search) => InkWell(
                        onTap: () {
                          HapticFeedback.lightImpact();
                          _controller.text = search;
                          widget.onSearchChanged(search);
                          widget.onRecentSearchTap?.call(search);
                          _focusNode.unfocus();
                          setState(() {
                            _showRecentSearches = false;
                          });
                        },
                        child: Container(
                          width: double.infinity,
                          padding: EdgeInsets.symmetric(
                              horizontal: 3.w, vertical: 1.5.h),
                          child: Row(
                            children: [
                              SizedBox(width: 6.w),
                              CustomIconWidget(
                                iconName: 'search',
                                size: 14,
                                color: colorScheme.onSurfaceVariant
                                    .withValues(alpha: 0.6),
                              ),
                              SizedBox(width: 3.w),
                              Expanded(
                                child: Text(
                                  search,
                                  style: theme.textTheme.bodyMedium?.copyWith(
                                    fontSize: 13.sp,
                                  ),
                                ),
                              ),
                              CustomIconWidget(
                                iconName: 'north_west',
                                size: 14,
                                color: colorScheme.onSurfaceVariant
                                    .withValues(alpha: 0.4),
                              ),
                            ],
                          ),
                        ),
                      ),
                    )
                    .toList(),
              ],
            ),
          ),
      ],
    );
  }
}
