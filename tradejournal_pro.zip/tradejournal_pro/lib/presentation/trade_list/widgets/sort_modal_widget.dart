import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

enum SortOption {
  dateNewest,
  dateOldest,
  pnlHighest,
  pnlLowest,
  symbolAZ,
  symbolZA,
  strategyAZ,
  strategyZA,
}

class SortModalWidget extends StatefulWidget {
  final SortOption currentSort;
  final Function(SortOption) onSortChanged;

  const SortModalWidget({
    super.key,
    required this.currentSort,
    required this.onSortChanged,
  });

  @override
  State<SortModalWidget> createState() => _SortModalWidgetState();
}

class _SortModalWidgetState extends State<SortModalWidget> {
  late SortOption _selectedSort;

  final Map<SortOption, Map<String, dynamic>> _sortOptions = {
    SortOption.dateNewest: {
      'title': 'Date (Newest First)',
      'subtitle': 'Most recent trades first',
      'icon': 'schedule',
    },
    SortOption.dateOldest: {
      'title': 'Date (Oldest First)',
      'subtitle': 'Oldest trades first',
      'icon': 'history',
    },
    SortOption.pnlHighest: {
      'title': 'P&L (Highest First)',
      'subtitle': 'Best performing trades first',
      'icon': 'trending_up',
    },
    SortOption.pnlLowest: {
      'title': 'P&L (Lowest First)',
      'subtitle': 'Worst performing trades first',
      'icon': 'trending_down',
    },
    SortOption.symbolAZ: {
      'title': 'Symbol (A-Z)',
      'subtitle': 'Alphabetical order',
      'icon': 'sort_by_alpha',
    },
    SortOption.symbolZA: {
      'title': 'Symbol (Z-A)',
      'subtitle': 'Reverse alphabetical order',
      'icon': 'sort_by_alpha',
    },
    SortOption.strategyAZ: {
      'title': 'Strategy (A-Z)',
      'subtitle': 'Strategy alphabetical order',
      'icon': 'category',
    },
    SortOption.strategyZA: {
      'title': 'Strategy (Z-A)',
      'subtitle': 'Strategy reverse alphabetical',
      'icon': 'category',
    },
  };

  @override
  void initState() {
    super.initState();
    _selectedSort = widget.currentSort;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle bar
          Container(
            margin: EdgeInsets.only(top: 1.h),
            width: 12.w,
            height: 0.5.h,
            decoration: BoxDecoration(
              color: colorScheme.onSurfaceVariant.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Header
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Row(
              children: [
                Text(
                  'Sort Trades',
                  style: theme.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                    fontSize: 18.sp,
                  ),
                ),
                const Spacer(),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: Text(
                    'Cancel',
                    style: theme.textTheme.labelLarge?.copyWith(
                      color: colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Sort options
          Flexible(
            child: ListView.separated(
              shrinkWrap: true,
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              itemCount: _sortOptions.length,
              separatorBuilder: (context, index) => Divider(
                height: 1,
                color: colorScheme.outline.withValues(alpha: 0.2),
              ),
              itemBuilder: (context, index) {
                final option = SortOption.values[index];
                final optionData = _sortOptions[option]!;
                final isSelected = _selectedSort == option;

                return ListTile(
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                  leading: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? colorScheme.primary.withValues(alpha: 0.1)
                          : colorScheme.surfaceContainerHighest,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: CustomIconWidget(
                      iconName: optionData['icon'],
                      size: 20,
                      color: isSelected
                          ? colorScheme.primary
                          : colorScheme.onSurfaceVariant,
                    ),
                  ),
                  title: Text(
                    optionData['title'],
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight:
                          isSelected ? FontWeight.w600 : FontWeight.w500,
                      color: isSelected
                          ? colorScheme.primary
                          : colorScheme.onSurface,
                      fontSize: 14.sp,
                    ),
                  ),
                  subtitle: Text(
                    optionData['subtitle'],
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: colorScheme.onSurfaceVariant,
                      fontSize: 12.sp,
                    ),
                  ),
                  trailing: Radio<SortOption>(
                    value: option,
                    groupValue: _selectedSort,
                    onChanged: (value) {
                      if (value != null) {
                        HapticFeedback.lightImpact();
                        setState(() {
                          _selectedSort = value;
                        });
                      }
                    },
                    activeColor: colorScheme.primary,
                  ),
                  onTap: () {
                    HapticFeedback.lightImpact();
                    setState(() {
                      _selectedSort = option;
                    });
                  },
                );
              },
            ),
          ),

          // Apply button
          Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: colorScheme.surface,
              border: Border(
                top: BorderSide(
                  color: colorScheme.outline.withValues(alpha: 0.2),
                  width: 1,
                ),
              ),
            ),
            child: SafeArea(
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _applySort,
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(vertical: 1.5.h),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: Text(
                    'Apply Sort',
                    style: theme.textTheme.labelLarge?.copyWith(
                      fontWeight: FontWeight.w600,
                      fontSize: 14.sp,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _applySort() {
    HapticFeedback.lightImpact();
    widget.onSortChanged(_selectedSort);
    Navigator.of(context).pop();
  }
}
