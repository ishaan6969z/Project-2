import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class PerformanceBreakdownWidget extends StatefulWidget {
  final List<Map<String, dynamic>> performanceData;

  const PerformanceBreakdownWidget({
    super.key,
    required this.performanceData,
  });

  @override
  State<PerformanceBreakdownWidget> createState() =>
      _PerformanceBreakdownWidgetState();
}

class _PerformanceBreakdownWidgetState
    extends State<PerformanceBreakdownWidget> {
  int touchedIndex = -1;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
        margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
            color: colorScheme.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
                color: colorScheme.outline.withValues(alpha: 0.2), width: 1),
            boxShadow: [
              BoxShadow(
                  color: colorScheme.shadow.withValues(alpha: 0.05),
                  blurRadius: 8,
                  offset: const Offset(0, 4)),
            ]),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CustomIconWidget(
                iconName: 'bar_chart', color: colorScheme.primary, size: 20),
            SizedBox(width: 2.w),
            Text('Performance by Market',
                style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600, color: colorScheme.onSurface)),
          ]),
          SizedBox(height: 3.h),
          SizedBox(
              height: 25.h,
              child: BarChart(BarChartData(
                  alignment: BarChartAlignment.spaceAround,
                  maxY: widget.performanceData
                          .map((e) => (e['wins'] as int) + (e['losses'] as int))
                          .reduce((a, b) => a > b ? a : b)
                          .toDouble() +
                      5,
                  barTouchData: BarTouchData(
                      enabled: true,
                      touchTooltipData: BarTouchTooltipData(
                          tooltipRoundedRadius: 8,
                          getTooltipItem: (group, groupIndex, rod, rodIndex) {
                            final data =
                                widget.performanceData[group.x.toInt()];
                            final isWins = rodIndex == 0;
                            return BarTooltipItem(
                                '${data['market']}\n${isWins ? 'Wins' : 'Losses'}: ${rod.toY.toInt()}',
                                TextStyle(
                                    color: colorScheme.onInverseSurface,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 12.sp));
                          }),
                      touchCallback: (FlTouchEvent event, barTouchResponse) {
                        setState(() {
                          if (!event.isInterestedForInteractions ||
                              barTouchResponse == null ||
                              barTouchResponse.spot == null) {
                            touchedIndex = -1;
                            return;
                          }
                          touchedIndex =
                              barTouchResponse.spot!.touchedBarGroupIndex;
                        });
                      }),
                  titlesData: FlTitlesData(
                      show: true,
                      rightTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                      topTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                      bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                              showTitles: true,
                              getTitlesWidget: (double value, TitleMeta meta) {
                                if (value.toInt() >= 0 &&
                                    value.toInt() <
                                        widget.performanceData.length) {
                                  final data =
                                      widget.performanceData[value.toInt()];
                                  return SideTitleWidget(
                                      axisSide: meta.axisSide,
                                      child: Text(data['market'] as String,
                                          style: theme.textTheme.bodySmall
                                              ?.copyWith(
                                                  color: colorScheme
                                                      .onSurfaceVariant,
                                                  fontSize: 10.sp)));
                                }
                                return const SizedBox.shrink();
                              },
                              reservedSize: 30)),
                      leftTitles: AxisTitles(
                          sideTitles: SideTitles(
                              showTitles: true,
                              reservedSize: 40,
                              interval: 5,
                              getTitlesWidget: (double value, TitleMeta meta) {
                                return SideTitleWidget(
                                    axisSide: meta.axisSide,
                                    child: Text(value.toInt().toString(),
                                        style: theme.textTheme.bodySmall
                                            ?.copyWith(
                                                color: colorScheme
                                                    .onSurfaceVariant,
                                                fontSize: 10.sp)));
                              }))),
                  borderData: FlBorderData(show: false),
                  barGroups:
                      widget.performanceData.asMap().entries.map((entry) {
                    final index = entry.key;
                    final data = entry.value;
                    final isTouched = index == touchedIndex;

                    return BarChartGroupData(
                        x: index,
                        barRods: [
                          BarChartRodData(
                              toY: (data['wins'] as int).toDouble(),
                              color: const Color(0xFF059669),
                              width: isTouched ? 6.w : 4.w,
                              borderRadius: BorderRadius.circular(2)),
                          BarChartRodData(
                              toY: (data['losses'] as int).toDouble(),
                              color: const Color(0xFFDC2626),
                              width: isTouched ? 6.w : 4.w,
                              borderRadius: BorderRadius.circular(2)),
                        ],
                        barsSpace: 1.w);
                  }).toList(),
                  gridData: FlGridData(
                      show: true,
                      drawVerticalLine: false,
                      horizontalInterval: 5,
                      getDrawingHorizontalLine: (value) {
                        return FlLine(
                            color: colorScheme.outline.withValues(alpha: 0.1),
                            strokeWidth: 1);
                      })))),
          SizedBox(height: 2.h),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            _buildLegendItem('Wins', const Color(0xFF059669), theme),
            SizedBox(width: 6.w),
            _buildLegendItem('Losses', const Color(0xFFDC2626), theme),
          ]),
        ]));
  }

  Widget _buildLegendItem(String label, Color color, ThemeData theme) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Container(
          width: 3.w,
          height: 3.w,
          decoration: BoxDecoration(
              color: color, borderRadius: BorderRadius.circular(2))),
      SizedBox(width: 2.w),
      Text(label,
          style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
              fontWeight: FontWeight.w500)),
    ]);
  }
}
