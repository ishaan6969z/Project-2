import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class MonthlyReturnsHeatmapWidget extends StatefulWidget {
  final List<Map<String, dynamic>> monthlyData;

  const MonthlyReturnsHeatmapWidget({
    super.key,
    required this.monthlyData,
  });

  @override
  State<MonthlyReturnsHeatmapWidget> createState() =>
      _MonthlyReturnsHeatmapWidgetState();
}

class _MonthlyReturnsHeatmapWidgetState
    extends State<MonthlyReturnsHeatmapWidget> {
  Map<String, dynamic>? selectedMonth;

  Color _getReturnColor(double returnValue, ColorScheme colorScheme) {
    if (returnValue > 0) {
      final intensity = (returnValue / 20).clamp(0.0, 1.0);
      return Color.lerp(
        colorScheme.surface,
        const Color(0xFF059669),
        intensity,
      )!;
    } else if (returnValue < 0) {
      final intensity = (returnValue.abs() / 20).clamp(0.0, 1.0);
      return Color.lerp(
        colorScheme.surface,
        const Color(0xFFDC2626),
        intensity,
      )!;
    }
    return colorScheme.surfaceContainerHighest;
  }

  void _showMonthDetails(Map<String, dynamic> monthData) {
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildMonthDetailsModal(monthData),
    );
  }

  Widget _buildMonthDetailsModal(Map<String, dynamic> monthData) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final returnValue = monthData['return'] as double;
    final isProfit = returnValue > 0;

    return Container(
      margin: EdgeInsets.all(4.w),
      padding: EdgeInsets.all(6.w),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.1),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                monthData['month'] as String,
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: colorScheme.onSurface,
                ),
              ),
              const Spacer(),
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: CustomIconWidget(
                  iconName: 'close',
                  color: colorScheme.onSurfaceVariant,
                  size: 20,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          _buildDetailRow(
              'Return',
              '${returnValue > 0 ? '+' : ''}\$${returnValue.toStringAsFixed(2)}',
              isProfit ? const Color(0xFF059669) : const Color(0xFFDC2626),
              theme),
          _buildDetailRow(
              'Trades', '${monthData['trades']}', colorScheme.onSurface, theme),
          _buildDetailRow('Win Rate', '${monthData['winRate']}%',
              colorScheme.onSurface, theme),
          _buildDetailRow('Best Day', '\$${monthData['bestDay']}',
              const Color(0xFF059669), theme),
          _buildDetailRow('Worst Day', '\$${monthData['worstDay']}',
              const Color(0xFFDC2626), theme),
          SizedBox(height: 2.h),
        ],
      ),
    );
  }

  Widget _buildDetailRow(
      String label, String value, Color valueColor, ThemeData theme) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 1.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          Text(
            value,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: valueColor,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: colorScheme.outline.withValues(alpha: 0.2),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'calendar_month',
                color: colorScheme.primary,
                size: 20,
              ),
              SizedBox(width: 2.w),
              Text(
                'Monthly Returns',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: colorScheme.onSurface,
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              crossAxisSpacing: 2.w,
              mainAxisSpacing: 1.h,
              childAspectRatio: 1.2,
            ),
            itemCount: widget.monthlyData.length,
            itemBuilder: (context, index) {
              final monthData = widget.monthlyData[index];
              final returnValue = monthData['return'] as double;
              final backgroundColor = _getReturnColor(returnValue, colorScheme);
              final textColor =
                  returnValue.abs() > 10 ? Colors.white : colorScheme.onSurface;

              return GestureDetector(
                onTap: () => _showMonthDetails(monthData),
                child: Container(
                  decoration: BoxDecoration(
                    color: backgroundColor,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: colorScheme.outline.withValues(alpha: 0.1),
                      width: 1,
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        monthData['month'] as String,
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: textColor,
                          fontWeight: FontWeight.w500,
                          fontSize: 10.sp,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 0.5.h),
                      Text(
                        '${returnValue > 0 ? '+' : ''}\$${returnValue.toStringAsFixed(0)}',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: textColor,
                          fontWeight: FontWeight.w700,
                          fontSize: 11.sp,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
          SizedBox(height: 2.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildLegendItem('Loss', const Color(0xFFDC2626), theme),
              _buildLegendItem(
                  'Neutral', colorScheme.surfaceContainerHighest, theme),
              _buildLegendItem('Profit', const Color(0xFF059669), theme),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildLegendItem(String label, Color color, ThemeData theme) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 3.w,
          height: 3.w,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        SizedBox(width: 1.w),
        Text(
          label,
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
            fontSize: 10.sp,
          ),
        ),
      ],
    );
  }
}
