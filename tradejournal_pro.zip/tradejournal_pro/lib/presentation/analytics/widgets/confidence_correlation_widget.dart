import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class ConfidenceCorrelationWidget extends StatefulWidget {
  final List<Map<String, dynamic>> confidenceData;

  const ConfidenceCorrelationWidget({
    super.key,
    required this.confidenceData,
  });

  @override
  State<ConfidenceCorrelationWidget> createState() =>
      _ConfidenceCorrelationWidgetState();
}

class _ConfidenceCorrelationWidgetState
    extends State<ConfidenceCorrelationWidget> {
  int? touchedIndex;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
        margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
            color: colorScheme.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
                color: colorScheme.outline.withValues(alpha: 0.2), width: 1),
            boxShadow: [
              BoxShadow(
                  color: colorScheme.shadow.withValues(alpha: 0.05),
                  blurRadius: 8,
                  offset: const Offset(0, 4)),
            ]),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CustomIconWidget(
                iconName: 'psychology', color: colorScheme.primary, size: 20),
            SizedBox(width: 2.w),
            Text('Confidence vs Performance',
                style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600, color: colorScheme.onSurface)),
          ]),
          SizedBox(height: 3.h),
          SizedBox(
              height: 25.h,
              child: ScatterChart(ScatterChartData(
                  scatterSpots:
                      widget.confidenceData.asMap().entries.map((entry) {
                    final data = entry.value;
                    return ScatterSpot((data['confidence'] as int).toDouble(),
                        data['return'] as double,
                        color: data['return'] > 0
                            ? const Color(0xFF059669)
                            : const Color(0xFFDC2626),
                        radius: 3);
                  }).toList(),
                  minX: 0,
                  maxX: 10,
                  minY: widget.confidenceData
                          .map((e) => e['return'] as double)
                          .reduce((a, b) => a < b ? a : b) -
                      50,
                  maxY: widget.confidenceData
                          .map((e) => e['return'] as double)
                          .reduce((a, b) => a > b ? a : b) +
                      50,
                  borderData: FlBorderData(show: false),
                  gridData: FlGridData(
                      show: true,
                      drawVerticalLine: true,
                      horizontalInterval: 100,
                      verticalInterval: 2,
                      getDrawingHorizontalLine: (value) {
                        return FlLine(
                            color: colorScheme.outline.withValues(alpha: 0.1),
                            strokeWidth: 1);
                      },
                      getDrawingVerticalLine: (value) {
                        return FlLine(
                            color: colorScheme.outline.withValues(alpha: 0.1),
                            strokeWidth: 1);
                      }),
                  titlesData: FlTitlesData(
                      show: true,
                      rightTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                      topTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                      bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                              showTitles: true,
                              reservedSize: 30,
                              interval: 2,
                              getTitlesWidget: (double value, TitleMeta meta) {
                                return SideTitleWidget(
                                    axisSide: meta.axisSide,
                                    child: Text(value.toInt().toString(),
                                        style: theme.textTheme.bodySmall
                                            ?.copyWith(
                                                color: colorScheme
                                                    .onSurfaceVariant,
                                                fontSize: 10.sp)));
                              })),
                      leftTitles: AxisTitles(
                          sideTitles: SideTitles(
                              showTitles: true,
                              reservedSize: 50,
                              interval: 100,
                              getTitlesWidget: (double value, TitleMeta meta) {
                                return SideTitleWidget(
                                    axisSide: meta.axisSide,
                                    child: Text('\$${value.toInt()}',
                                        style: theme.textTheme.bodySmall
                                            ?.copyWith(
                                                color: colorScheme
                                                    .onSurfaceVariant,
                                                fontSize: 10.sp)));
                              }))),
                  scatterTouchData: ScatterTouchData(
                      enabled: true,
                      touchTooltipData: ScatterTouchTooltipData(
                          tooltipRoundedRadius: 8,
                          getTooltipItems: (ScatterSpot touchedBarSpot) {
                            return ScatterTooltipItem(
                                'Confidence: ${touchedBarSpot.x.toInt()}\nReturn: \$${touchedBarSpot.y.toStringAsFixed(2)}',
                                textStyle: TextStyle(
                                    color: colorScheme.onInverseSurface,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 12.sp));
                          }))))),
          SizedBox(height: 2.h),
          Row(children: [
            Text('Confidence Level (1-10)',
                style: theme.textTheme.bodySmall?.copyWith(
                    color: colorScheme.onSurfaceVariant, fontSize: 10.sp)),
          ]),
          SizedBox(height: 1.h),
          Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                  color: colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(12)),
              child: Column(children: [
                Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Correlation Insights',
                          style: theme.textTheme.bodyMedium?.copyWith(
                              color: colorScheme.onSurface,
                              fontWeight: FontWeight.w600)),
                    ]),
                SizedBox(height: 1.h),
                _buildInsightRow(
                    'High confidence (8-10)',
                    '${_getHighConfidenceWinRate()}% win rate',
                    theme,
                    colorScheme),
                _buildInsightRow(
                    'Medium confidence (5-7)',
                    '${_getMediumConfidenceWinRate()}% win rate',
                    theme,
                    colorScheme),
                _buildInsightRow(
                    'Low confidence (1-4)',
                    '${_getLowConfidenceWinRate()}% win rate',
                    theme,
                    colorScheme),
              ])),
        ]));
  }

  Widget _buildInsightRow(
      String label, String value, ThemeData theme, ColorScheme colorScheme) {
    return Padding(
        padding: EdgeInsets.symmetric(vertical: 0.5.h),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(label,
              style: theme.textTheme.bodySmall
                  ?.copyWith(color: colorScheme.onSurfaceVariant)),
          Text(value,
              style: theme.textTheme.bodySmall?.copyWith(
                  color: colorScheme.onSurface, fontWeight: FontWeight.w600)),
        ]));
  }

  int _getHighConfidenceWinRate() {
    final highConfidenceTrades = widget.confidenceData
        .where((trade) => (trade['confidence'] as int) >= 8)
        .toList();
    if (highConfidenceTrades.isEmpty) return 0;
    final wins = highConfidenceTrades
        .where((trade) => (trade['return'] as double) > 0)
        .length;
    return ((wins / highConfidenceTrades.length) * 100).round();
  }

  int _getMediumConfidenceWinRate() {
    final mediumConfidenceTrades = widget.confidenceData.where((trade) {
      final confidence = trade['confidence'] as int;
      return confidence >= 5 && confidence <= 7;
    }).toList();
    if (mediumConfidenceTrades.isEmpty) return 0;
    final wins = mediumConfidenceTrades
        .where((trade) => (trade['return'] as double) > 0)
        .length;
    return ((wins / mediumConfidenceTrades.length) * 100).round();
  }

  int _getLowConfidenceWinRate() {
    final lowConfidenceTrades = widget.confidenceData
        .where((trade) => (trade['confidence'] as int) <= 4)
        .toList();
    if (lowConfidenceTrades.isEmpty) return 0;
    final wins = lowConfidenceTrades
        .where((trade) => (trade['return'] as double) > 0)
        .length;
    return ((wins / lowConfidenceTrades.length) * 100).round();
  }
}