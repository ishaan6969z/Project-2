import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class TimePerformanceWidget extends StatefulWidget {
  final List<Map<String, dynamic>> timeData;

  const TimePerformanceWidget({
    super.key,
    required this.timeData,
  });

  @override
  State<TimePerformanceWidget> createState() => _TimePerformanceWidgetState();
}

class _TimePerformanceWidgetState extends State<TimePerformanceWidget> {
  bool showHours = true;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
        margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
            color: colorScheme.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
                color: colorScheme.outline.withValues(alpha: 0.2), width: 1),
            boxShadow: [
              BoxShadow(
                  color: colorScheme.shadow.withValues(alpha: 0.05),
                  blurRadius: 8,
                  offset: const Offset(0, 4)),
            ]),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CustomIconWidget(
                iconName: 'schedule', color: colorScheme.primary, size: 20),
            SizedBox(width: 2.w),
            Text('Optimal Trading Times',
                style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600, color: colorScheme.onSurface)),
            const Spacer(),
            _buildToggleButton(theme, colorScheme),
          ]),
          SizedBox(height: 3.h),
          SizedBox(
              height: 25.h,
              child: BarChart(BarChartData(
                  alignment: BarChartAlignment.spaceAround,
                  maxY: _getMaxValue() + 100,
                  barTouchData: BarTouchData(
                      enabled: true,
                      touchTooltipData: BarTouchTooltipData(
                          tooltipRoundedRadius: 8,
                          getTooltipItem: (group, groupIndex, rod, rodIndex) {
                            final data = _getCurrentData()[group.x.toInt()];
                            return BarTooltipItem(
                                '${data['label']}\nProfit: \$${rod.toY.toStringAsFixed(0)}',
                                TextStyle(
                                    color: colorScheme.onInverseSurface,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 12.sp));
                          })),
                  titlesData: FlTitlesData(
                      show: true,
                      rightTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                      topTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                      bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                              showTitles: true,
                              getTitlesWidget: (double value, TitleMeta meta) {
                                final data = _getCurrentData();
                                if (value.toInt() >= 0 &&
                                    value.toInt() < data.length) {
                                  return SideTitleWidget(
                                      axisSide: meta.axisSide,
                                      child: Text(
                                          data[value.toInt()]['label']
                                              as String,
                                          style: theme.textTheme.bodySmall
                                              ?.copyWith(
                                                  color: colorScheme
                                                      .onSurfaceVariant,
                                                  fontSize: 9.sp)));
                                }
                                return const SizedBox.shrink();
                              },
                              reservedSize: 30)),
                      leftTitles: AxisTitles(
                          sideTitles: SideTitles(
                              showTitles: true,
                              reservedSize: 50,
                              interval: 200,
                              getTitlesWidget: (double value, TitleMeta meta) {
                                return SideTitleWidget(
                                    axisSide: meta.axisSide,
                                    child: Text('\$${value.toInt()}',
                                        style: theme.textTheme.bodySmall
                                            ?.copyWith(
                                                color: colorScheme
                                                    .onSurfaceVariant,
                                                fontSize: 10.sp)));
                              }))),
                  borderData: FlBorderData(show: false),
                  barGroups: _getCurrentData().asMap().entries.map((entry) {
                    final index = entry.key;
                    final data = entry.value;
                    final profit = data['profit'] as double;

                    return BarChartGroupData(x: index, barRods: [
                      BarChartRodData(
                          toY: profit,
                          color: profit > 0
                              ? const Color(0xFF059669)
                              : const Color(0xFFDC2626),
                          width: 4.w,
                          borderRadius: BorderRadius.circular(2)),
                    ]);
                  }).toList(),
                  gridData: FlGridData(
                      show: true,
                      drawVerticalLine: false,
                      horizontalInterval: 200,
                      getDrawingHorizontalLine: (value) {
                        return FlLine(
                            color: colorScheme.outline.withValues(alpha: 0.1),
                            strokeWidth: 1);
                      })))),
          SizedBox(height: 3.h),
          Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                  color: colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(12)),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Pattern Insights',
                        style: theme.textTheme.bodyMedium?.copyWith(
                            color: colorScheme.onSurface,
                            fontWeight: FontWeight.w600)),
                    SizedBox(height: 1.h),
                    ..._buildInsights(theme, colorScheme),
                  ])),
        ]));
  }

  Widget _buildToggleButton(ThemeData theme, ColorScheme colorScheme) {
    return Container(
        decoration: BoxDecoration(
            color: colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(8)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          GestureDetector(
              onTap: () => setState(() => showHours = true),
              child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                  decoration: BoxDecoration(
                      color:
                          showHours ? colorScheme.primary : Colors.transparent,
                      borderRadius: BorderRadius.circular(6)),
                  child: Text('Hours',
                      style: theme.textTheme.bodySmall?.copyWith(
                          color: showHours
                              ? Colors.white
                              : colorScheme.onSurfaceVariant,
                          fontWeight: FontWeight.w500)))),
          GestureDetector(
              onTap: () => setState(() => showHours = false),
              child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                  decoration: BoxDecoration(
                      color:
                          !showHours ? colorScheme.primary : Colors.transparent,
                      borderRadius: BorderRadius.circular(6)),
                  child: Text('Days',
                      style: theme.textTheme.bodySmall?.copyWith(
                          color: !showHours
                              ? Colors.white
                              : colorScheme.onSurfaceVariant,
                          fontWeight: FontWeight.w500)))),
        ]));
  }

  List<Map<String, dynamic>> _getCurrentData() {
    return showHours ? _getHourlyData() : _getDailyData();
  }

  List<Map<String, dynamic>> _getHourlyData() {
    return widget.timeData.where((data) => data['type'] == 'hour').toList();
  }

  List<Map<String, dynamic>> _getDailyData() {
    return widget.timeData.where((data) => data['type'] == 'day').toList();
  }

  double _getMaxValue() {
    final data = _getCurrentData();
    if (data.isEmpty) return 1000;
    return data
        .map((e) => (e['profit'] as double).abs())
        .reduce((a, b) => a > b ? a : b);
  }

  List<Widget> _buildInsights(ThemeData theme, ColorScheme colorScheme) {
    final data = _getCurrentData();
    if (data.isEmpty) return [];

    final bestTime = data.reduce(
        (a, b) => (a['profit'] as double) > (b['profit'] as double) ? a : b);
    final worstTime = data.reduce(
        (a, b) => (a['profit'] as double) < (b['profit'] as double) ? a : b);

    return [
      _buildInsightRow(
          'Best ${showHours ? 'hour' : 'day'}',
          '${bestTime['label']} (\$${(bestTime['profit'] as double).toStringAsFixed(0)})',
          theme,
          colorScheme),
      _buildInsightRow(
          'Worst ${showHours ? 'hour' : 'day'}',
          '${worstTime['label']} (\$${(worstTime['profit'] as double).toStringAsFixed(0)})',
          theme,
          colorScheme),
      _buildInsightRow(
          'Recommendation',
          showHours
              ? 'Focus trading during ${bestTime['label']} for optimal results'
              : 'Avoid trading on ${worstTime['label']} to minimize losses',
          theme,
          colorScheme),
    ];
  }

  Widget _buildInsightRow(
      String label, String value, ThemeData theme, ColorScheme colorScheme) {
    return Padding(
        padding: EdgeInsets.symmetric(vertical: 0.5.h),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(
              width: 20.w,
              child: Text(label,
                  style: theme.textTheme.bodySmall?.copyWith(
                      color: colorScheme.onSurfaceVariant,
                      fontWeight: FontWeight.w500))),
          Expanded(
              child: Text(value,
                  style: theme.textTheme.bodySmall
                      ?.copyWith(color: colorScheme.onSurface))),
        ]));
  }
}
