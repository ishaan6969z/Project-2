import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class RiskAnalysisWidget extends StatelessWidget {
  final Map<String, dynamic> riskData;

  const RiskAnalysisWidget({
    super.key,
    required this.riskData,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: colorScheme.outline.withValues(alpha: 0.2),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'security',
                color: colorScheme.primary,
                size: 20,
              ),
              SizedBox(width: 2.w),
              Text(
                'Risk Analysis',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: colorScheme.onSurface,
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          _buildRiskMetricCard(
            'Risk of Ruin',
            '${riskData['riskOfRuin']}%',
            'Probability of losing entire account',
            _getRiskColor(riskData['riskOfRuin'] as double),
            theme,
            colorScheme,
          ),
          SizedBox(height: 2.h),
          _buildRiskMetricCard(
            'Kelly Criterion',
            '${riskData['kellyCriterion']}%',
            'Optimal position size per trade',
            colorScheme.primary,
            theme,
            colorScheme,
          ),
          SizedBox(height: 2.h),
          _buildRiskMetricCard(
            'Maximum Drawdown',
            '${riskData['maxDrawdown']}%',
            'Largest peak-to-trough decline',
            const Color(0xFFD97706),
            theme,
            colorScheme,
          ),
          SizedBox(height: 2.h),
          _buildRiskMetricCard(
            'Sharpe Ratio',
            '${riskData['sharpeRatio']}',
            'Risk-adjusted return measure',
            _getSharpeColor(riskData['sharpeRatio'] as double),
            theme,
            colorScheme,
          ),
          SizedBox(height: 3.h),
          Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: colorScheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'info',
                      color: colorScheme.primary,
                      size: 16,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Risk Recommendations',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: colorScheme.onSurface,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 2.h),
                ..._buildRecommendations(theme, colorScheme),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRiskMetricCard(
    String title,
    String value,
    String description,
    Color valueColor,
    ThemeData theme,
    ColorScheme colorScheme,
  ) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: colorScheme.outline.withValues(alpha: 0.1),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: colorScheme.onSurface,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                value,
                style: theme.textTheme.titleMedium?.copyWith(
                  color: valueColor,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Text(
            description,
            style: theme.textTheme.bodySmall?.copyWith(
              color: colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> _buildRecommendations(ThemeData theme, ColorScheme colorScheme) {
    final recommendations = <String>[];

    final riskOfRuin = riskData['riskOfRuin'] as double;
    final kellyCriterion = riskData['kellyCriterion'] as double;
    final maxDrawdown = riskData['maxDrawdown'] as double;
    final sharpeRatio = riskData['sharpeRatio'] as double;

    if (riskOfRuin > 10) {
      recommendations.add('• Reduce position sizes to lower risk of ruin');
    }

    if (kellyCriterion > 25) {
      recommendations.add('• Kelly Criterion suggests reducing position size');
    }

    if (maxDrawdown > 20) {
      recommendations.add('• Consider tighter stop losses to reduce drawdowns');
    }

    if (sharpeRatio < 1.0) {
      recommendations.add('• Focus on improving risk-adjusted returns');
    }

    if (recommendations.isEmpty) {
      recommendations
          .add('• Your risk metrics look healthy - maintain current approach');
    }

    return recommendations.map((recommendation) {
      return Padding(
        padding: EdgeInsets.symmetric(vertical: 0.5.h),
        child: Text(
          recommendation,
          style: theme.textTheme.bodySmall?.copyWith(
            color: colorScheme.onSurfaceVariant,
          ),
        ),
      );
    }).toList();
  }

  Color _getRiskColor(double riskOfRuin) {
    if (riskOfRuin <= 5) return const Color(0xFF059669);
    if (riskOfRuin <= 15) return const Color(0xFFD97706);
    return const Color(0xFFDC2626);
  }

  Color _getSharpeColor(double sharpeRatio) {
    if (sharpeRatio >= 1.5) return const Color(0xFF059669);
    if (sharpeRatio >= 1.0) return const Color(0xFFD97706);
    return const Color(0xFFDC2626);
  }
}
