import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class EquityCurveChartWidget extends StatefulWidget {
  final List<Map<String, dynamic>> equityData;
  final String selectedPeriod;

  const EquityCurveChartWidget({
    super.key,
    required this.equityData,
    required this.selectedPeriod,
  });

  @override
  State<EquityCurveChartWidget> createState() => _EquityCurveChartWidgetState();
}

class _EquityCurveChartWidgetState extends State<EquityCurveChartWidget> {
  int? touchedIndex;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
        margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
            color: colorScheme.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
                color: colorScheme.outline.withValues(alpha: 0.2), width: 1),
            boxShadow: [
              BoxShadow(
                  color: colorScheme.shadow.withValues(alpha: 0.05),
                  blurRadius: 8,
                  offset: const Offset(0, 4)),
            ]),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CustomIconWidget(
                iconName: 'trending_up', color: colorScheme.primary, size: 20),
            SizedBox(width: 2.w),
            Text('Equity Curve',
                style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600, color: colorScheme.onSurface)),
            const Spacer(),
            Text(widget.selectedPeriod,
                style: theme.textTheme.bodySmall?.copyWith(
                    color: colorScheme.onSurfaceVariant,
                    fontWeight: FontWeight.w500)),
          ]),
          SizedBox(height: 3.h),
          SizedBox(
              height: 25.h,
              child: LineChart(LineChartData(
                  gridData: FlGridData(
                      show: true,
                      drawVerticalLine: false,
                      horizontalInterval: 1000,
                      getDrawingHorizontalLine: (value) {
                        return FlLine(
                            color: colorScheme.outline.withValues(alpha: 0.1),
                            strokeWidth: 1);
                      }),
                  titlesData: FlTitlesData(
                      show: true,
                      rightTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                      topTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                      bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                              showTitles: true,
                              reservedSize: 30,
                              interval: 1,
                              getTitlesWidget: (value, meta) {
                                if (value.toInt() >= 0 &&
                                    value.toInt() < widget.equityData.length) {
                                  final data = widget.equityData[value.toInt()];
                                  return SideTitleWidget(
                                      axisSide: meta.axisSide,
                                      child: Text(data['date'] as String,
                                          style: theme.textTheme.bodySmall
                                              ?.copyWith(
                                                  color: colorScheme
                                                      .onSurfaceVariant,
                                                  fontSize: 10.sp)));
                                }
                                return const SizedBox.shrink();
                              })),
                      leftTitles: AxisTitles(
                          sideTitles: SideTitles(
                              showTitles: true,
                              interval: 2000,
                              reservedSize: 50,
                              getTitlesWidget: (value, meta) {
                                return SideTitleWidget(
                                    axisSide: meta.axisSide,
                                    child: Text(
                                        '\$${(value / 1000).toStringAsFixed(0)}K',
                                        style: theme.textTheme.bodySmall
                                            ?.copyWith(
                                                color: colorScheme
                                                    .onSurfaceVariant,
                                                fontSize: 10.sp)));
                              }))),
                  borderData: FlBorderData(show: false),
                  minX: 0,
                  maxX: (widget.equityData.length - 1).toDouble(),
                  minY: widget.equityData
                          .map((e) => e['value'] as double)
                          .reduce((a, b) => a < b ? a : b) -
                      1000,
                  maxY: widget.equityData
                          .map((e) => e['value'] as double)
                          .reduce((a, b) => a > b ? a : b) +
                      1000,
                  lineBarsData: [
                    LineChartBarData(
                        spots: widget.equityData.asMap().entries.map((entry) {
                          return FlSpot(entry.key.toDouble(),
                              entry.value['value'] as double);
                        }).toList(),
                        isCurved: true,
                        gradient: LinearGradient(colors: [
                          colorScheme.primary,
                          colorScheme.primary.withValues(alpha: 0.8),
                        ]),
                        barWidth: 3,
                        isStrokeCapRound: true,
                        dotData: FlDotData(show: false),
                        belowBarData: BarAreaData(
                            show: true,
                            gradient: LinearGradient(
                                colors: [
                                  colorScheme.primary.withValues(alpha: 0.2),
                                  colorScheme.primary.withValues(alpha: 0.05),
                                ],
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter))),
                  ],
                  lineTouchData: LineTouchData(
                      enabled: true,
                      touchTooltipData: LineTouchTooltipData(
                          tooltipRoundedRadius: 8,
                          getTooltipItems: (List<LineBarSpot> touchedBarSpots) {
                            return touchedBarSpots.map((barSpot) {
                              final flSpot = barSpot;
                              if (flSpot.x.toInt() >= 0 &&
                                  flSpot.x.toInt() < widget.equityData.length) {
                                final data =
                                    widget.equityData[flSpot.x.toInt()];
                                return LineTooltipItem(
                                    '${data['date']}\n\$${flSpot.y.toStringAsFixed(2)}',
                                    TextStyle(
                                        color: colorScheme.onInverseSurface,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 12.sp));
                              }
                              return null;
                            }).toList();
                          }),
                      handleBuiltInTouches: true)))),
        ]));
  }
}
