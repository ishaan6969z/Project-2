import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/confidence_correlation_widget.dart';
import './widgets/equity_curve_chart_widget.dart';
import './widgets/metrics_card_widget.dart';
import './widgets/monthly_returns_heatmap_widget.dart';
import './widgets/performance_breakdown_widget.dart';
import './widgets/risk_analysis_widget.dart';
import './widgets/strategy_comparison_widget.dart';
import './widgets/time_performance_widget.dart';
import './widgets/time_period_selector_widget.dart';

class Analytics extends StatefulWidget {
  const Analytics({super.key});

  @override
  State<Analytics> createState() => _AnalyticsState();
}

class _AnalyticsState extends State<Analytics> with TickerProviderStateMixin {
  int selectedPeriodIndex = 2; // Default to 6M
  final List<String> timePeriods = ['1M', '3M', '6M', '1Y', 'All'];

  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  // Mock data for analytics
  final List<Map<String, dynamic>> equityData = [
    {'date': 'Jan', 'value': 10000.0},
    {'date': 'Feb', 'value': 10500.0},
    {'date': 'Mar', 'value': 9800.0},
    {'date': 'Apr', 'value': 11200.0},
    {'date': 'May', 'value': 10900.0},
    {'date': 'Jun', 'value': 12300.0},
    {'date': 'Jul', 'value': 11800.0},
    {'date': 'Aug', 'value': 13100.0},
  ];

  final List<Map<String, dynamic>> monthlyReturnsData = [
    {
      'month': 'Jan 24',
      'return': 250.0,
      'trades': 15,
      'winRate': 67,
      'bestDay': 120.0,
      'worstDay': -80.0
    },
    {
      'month': 'Feb 24',
      'return': 180.0,
      'trades': 12,
      'winRate': 58,
      'bestDay': 95.0,
      'worstDay': -65.0
    },
    {
      'month': 'Mar 24',
      'return': -150.0,
      'trades': 18,
      'winRate': 44,
      'bestDay': 85.0,
      'worstDay': -120.0
    },
    {
      'month': 'Apr 24',
      'return': 420.0,
      'trades': 20,
      'winRate': 75,
      'bestDay': 180.0,
      'worstDay': -45.0
    },
    {
      'month': 'May 24',
      'return': 320.0,
      'trades': 16,
      'winRate': 69,
      'bestDay': 140.0,
      'worstDay': -70.0
    },
    {
      'month': 'Jun 24',
      'return': 480.0,
      'trades': 22,
      'winRate': 73,
      'bestDay': 200.0,
      'worstDay': -55.0
    },
    {
      'month': 'Jul 24',
      'return': 290.0,
      'trades': 14,
      'winRate': 64,
      'bestDay': 110.0,
      'worstDay': -85.0
    },
    {
      'month': 'Aug 24',
      'return': 380.0,
      'trades': 19,
      'winRate': 68,
      'bestDay': 160.0,
      'worstDay': -75.0
    },
  ];

  final List<Map<String, dynamic>> performanceByMarket = [
    {'market': 'Equity', 'wins': 45, 'losses': 23},
    {'market': 'Crypto', 'wins': 32, 'losses': 28},
    {'market': 'Forex', 'wins': 28, 'losses': 15},
  ];

  final List<Map<String, dynamic>> strategyPerformance = [
    {
      'strategy': 'Breakout',
      'percentage': 35.0,
      'trades': 42,
      'winRate': 71,
      'profit': 1250
    },
    {
      'strategy': 'Pullback',
      'percentage': 28.0,
      'trades': 34,
      'winRate': 65,
      'profit': 980
    },
    {
      'strategy': 'Reversal',
      'percentage': 22.0,
      'trades': 26,
      'winRate': 58,
      'profit': 720
    },
    {
      'strategy': 'Momentum',
      'percentage': 15.0,
      'trades': 18,
      'winRate': 67,
      'profit': 540
    },
  ];

  final List<Map<String, dynamic>> confidenceData = [
    {'confidence': 8, 'return': 150.0},
    {'confidence': 6, 'return': 80.0},
    {'confidence': 9, 'return': 220.0},
    {'confidence': 4, 'return': -45.0},
    {'confidence': 7, 'return': 120.0},
    {'confidence': 5, 'return': -20.0},
    {'confidence': 8, 'return': 180.0},
    {'confidence': 3, 'return': -80.0},
    {'confidence': 9, 'return': 250.0},
    {'confidence': 6, 'return': 90.0},
    {'confidence': 7, 'return': 140.0},
    {'confidence': 4, 'return': -30.0},
    {'confidence': 8, 'return': 200.0},
    {'confidence': 5, 'return': 60.0},
    {'confidence': 9, 'return': 280.0},
  ];

  final Map<String, dynamic> riskAnalysisData = {
    'riskOfRuin': 8.5,
    'kellyCriterion': 12.3,
    'maxDrawdown': 15.2,
    'sharpeRatio': 1.45,
  };

  final List<Map<String, dynamic>> timePerformanceData = [
// Hourly data
    {'type': 'hour', 'label': '9AM', 'profit': 320.0},
    {'type': 'hour', 'label': '10AM', 'profit': 480.0},
    {'type': 'hour', 'label': '11AM', 'profit': 280.0},
    {'type': 'hour', 'label': '12PM', 'profit': -120.0},
    {'type': 'hour', 'label': '1PM', 'profit': 180.0},
    {'type': 'hour', 'label': '2PM', 'profit': 420.0},
    {'type': 'hour', 'label': '3PM', 'profit': 380.0},
    {'type': 'hour', 'label': '4PM', 'profit': 220.0},
// Daily data
    {'type': 'day', 'label': 'Mon', 'profit': 450.0},
    {'type': 'day', 'label': 'Tue', 'profit': 320.0},
    {'type': 'day', 'label': 'Wed', 'profit': 280.0},
    {'type': 'day', 'label': 'Thu', 'profit': 380.0},
    {'type': 'day', 'label': 'Fri', 'profit': 520.0},
  ];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _onPeriodChanged(int index) {
    HapticFeedback.lightImpact();
    setState(() {
      selectedPeriodIndex = index;
    });
    _animationController.reset();
    _animationController.forward();
  }

  void _showFilterOptions() {
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildFilterModal(),
    );
  }

  Widget _buildFilterModal() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      margin: EdgeInsets.all(4.w),
      padding: EdgeInsets.all(6.w),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.1),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Filter Analytics',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: colorScheme.onSurface,
                ),
              ),
              const Spacer(),
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: CustomIconWidget(
                  iconName: 'close',
                  color: colorScheme.onSurfaceVariant,
                  size: 20,
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          _buildFilterSection('Market Type',
              ['All', 'Equity', 'Crypto', 'Forex'], theme, colorScheme),
          SizedBox(height: 2.h),
          _buildFilterSection('Strategy',
              ['All', 'Breakout', 'Pullback', 'Reversal'], theme, colorScheme),
          SizedBox(height: 2.h),
          _buildFilterSection('Date Range',
              ['Custom', 'Last 30 days', 'Last 90 days'], theme, colorScheme),
          SizedBox(height: 3.h),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Reset'),
                ),
              ),
              SizedBox(width: 4.w),
              Expanded(
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Apply'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFilterSection(String title, List<String> options,
      ThemeData theme, ColorScheme colorScheme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: colorScheme.onSurface,
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 1.h),
        Wrap(
          spacing: 2.w,
          runSpacing: 1.h,
          children: options.map((option) {
            final isSelected = option == options.first;
            return GestureDetector(
              onTap: () => HapticFeedback.lightImpact(),
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                decoration: BoxDecoration(
                  color: isSelected ? colorScheme.primary : Colors.transparent,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isSelected
                        ? colorScheme.primary
                        : colorScheme.outline.withValues(alpha: 0.5),
                    width: 1,
                  ),
                ),
                child: Text(
                  option,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: isSelected
                        ? Colors.white
                        : colorScheme.onSurfaceVariant,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      appBar: AppBar(
        backgroundColor: colorScheme.surface,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        title: Text(
          'Analytics',
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w700,
            color: colorScheme.onSurface,
          ),
        ),
        centerTitle: false,
        actions: [
          IconButton(
            onPressed: _showFilterOptions,
            icon: CustomIconWidget(
              iconName: 'filter_list',
              color: colorScheme.onSurface,
              size: 24,
            ),
            tooltip: 'Filter',
          ),
          IconButton(
            onPressed: () {
              HapticFeedback.lightImpact();
              // Handle export functionality
            },
            icon: CustomIconWidget(
              iconName: 'download',
              color: colorScheme.onSurface,
              size: 24,
            ),
            tooltip: 'Export',
          ),
        ],
      ),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: RefreshIndicator(
          onRefresh: () async {
            HapticFeedback.lightImpact();
            await Future.delayed(const Duration(milliseconds: 1000));
            setState(() {});
          },
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Time Period Selector
                TimePeriodSelectorWidget(
                  periods: timePeriods,
                  selectedIndex: selectedPeriodIndex,
                  onPeriodChanged: _onPeriodChanged,
                ),

                // Key Metrics Cards
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 4.w),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: MetricsCardWidget(
                              title: 'Total Trades',
                              value: '156',
                              subtitle: '+12 this month',
                              icon: Icons.trending_up,
                            ),
                          ),
                          SizedBox(width: 3.w),
                          Expanded(
                            child: MetricsCardWidget(
                              title: 'Win Rate',
                              value: '68.5%',
                              subtitle: '+2.3% vs last month',
                              valueColor: const Color(0xFF059669),
                              icon: Icons.check_circle,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 2.h),
                      Row(
                        children: [
                          Expanded(
                            child: MetricsCardWidget(
                              title: 'Avg Win',
                              value: '\$142.50',
                              subtitle: 'Per winning trade',
                              valueColor: const Color(0xFF059669),
                              icon: Icons.arrow_upward,
                            ),
                          ),
                          SizedBox(width: 3.w),
                          Expanded(
                            child: MetricsCardWidget(
                              title: 'Sharpe Ratio',
                              value: '1.45',
                              subtitle: 'Risk-adjusted return',
                              valueColor: colorScheme.primary,
                              icon: Icons.analytics,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // Equity Curve Chart
                EquityCurveChartWidget(
                  equityData: equityData,
                  selectedPeriod: timePeriods[selectedPeriodIndex],
                ),

                // Monthly Returns Heatmap
                MonthlyReturnsHeatmapWidget(
                  monthlyData: monthlyReturnsData,
                ),

                // Performance Breakdown
                PerformanceBreakdownWidget(
                  performanceData: performanceByMarket,
                ),

                // Strategy Comparison
                StrategyComparisonWidget(
                  strategyData: strategyPerformance,
                ),

                // Confidence Correlation
                ConfidenceCorrelationWidget(
                  confidenceData: confidenceData,
                ),

                // Risk Analysis
                RiskAnalysisWidget(
                  riskData: riskAnalysisData,
                ),

                // Time Performance
                TimePerformanceWidget(
                  timeData: timePerformanceData,
                ),

                // Bottom padding for safe area
                SizedBox(height: 10.h),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
