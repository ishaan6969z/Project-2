import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class RecentTradesWidget extends StatelessWidget {
  const RecentTradesWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final List<Map<String, dynamic>> recentTrades = [
      {
        "id": "TRD-2025-001",
        "symbol": "AAPL",
        "type": "Long",
        "pnl": 245.50,
        "timestamp": DateTime.now().subtract(const Duration(hours: 2)),
        "status": "Closed",
        "quantity": 10,
        "entryPrice": 185.20,
        "exitPrice": 187.75,
      },
      {
        "id": "TRD-2025-002",
        "symbol": "BTC/USD",
        "type": "Short",
        "pnl": -125.30,
        "timestamp": DateTime.now().subtract(const Duration(hours: 4)),
        "status": "Closed",
        "quantity": 0.5,
        "entryPrice": 42500.00,
        "exitPrice": 42750.60,
      },
      {
        "id": "TRD-2025-003",
        "symbol": "TSLA",
        "type": "Long",
        "pnl": 0.0,
        "timestamp": DateTime.now().subtract(const Duration(hours: 6)),
        "status": "Open",
        "quantity": 5,
        "entryPrice": 245.80,
        "exitPrice": 0.0,
      },
      {
        "id": "TRD-2025-004",
        "symbol": "EUR/USD",
        "type": "Long",
        "pnl": 89.75,
        "timestamp": DateTime.now().subtract(const Duration(days: 1)),
        "status": "Closed",
        "quantity": 10000,
        "entryPrice": 1.0845,
        "exitPrice": 1.0854,
      },
      {
        "id": "TRD-2025-005",
        "symbol": "NVDA",
        "type": "Short",
        "pnl": 312.40,
        "timestamp": DateTime.now().subtract(const Duration(days: 1, hours: 3)),
        "status": "Closed",
        "quantity": 8,
        "entryPrice": 875.20,
        "exitPrice": 836.15,
      },
    ];

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Recent Trades',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: colorScheme.onSurface,
                ),
              ),
              GestureDetector(
                onTap: () {
                  HapticFeedback.lightImpact();
                  Navigator.pushNamed(context, '/trade-list');
                },
                child: Text(
                  'View All',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: colorScheme.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: recentTrades.length,
            separatorBuilder: (context, index) => SizedBox(height: 2.h),
            itemBuilder: (context, index) {
              final trade = recentTrades[index];
              return _buildTradeCard(context, trade);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildTradeCard(BuildContext context, Map<String, dynamic> trade) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final pnl = trade["pnl"] as double;
    final isProfit = pnl > 0;
    final isOpen = trade["status"] == "Open";

    Color pnlColor;
    if (isOpen) {
      pnlColor = colorScheme.onSurfaceVariant;
    } else {
      pnlColor = isProfit ? colorScheme.primary : colorScheme.error;
    }

    return Dismissible(
      key: Key(trade["id"] as String),
      background: Container(
        padding: EdgeInsets.symmetric(horizontal: 4.w),
        decoration: BoxDecoration(
          color: colorScheme.primary.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        alignment: Alignment.centerLeft,
        child: Row(
          children: [
            CustomIconWidget(
              iconName: 'edit',
              color: colorScheme.primary,
              size: 20,
            ),
            SizedBox(width: 2.w),
            Text(
              'Edit',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: colorScheme.primary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
      secondaryBackground: Container(
        padding: EdgeInsets.symmetric(horizontal: 4.w),
        decoration: BoxDecoration(
          color: colorScheme.error.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        alignment: Alignment.centerRight,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Text(
              'Delete',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: colorScheme.error,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(width: 2.w),
            CustomIconWidget(
              iconName: 'delete',
              color: colorScheme.error,
              size: 20,
            ),
          ],
        ),
      ),
      confirmDismiss: (direction) async {
        if (direction == DismissDirection.startToEnd) {
          // Edit action
          HapticFeedback.lightImpact();
          Navigator.pushNamed(context, '/add-trade');
          return false;
        } else {
          // Delete action
          HapticFeedback.mediumImpact();
          return await _showDeleteConfirmation(context);
        }
      },
      child: GestureDetector(
        onTap: () {
          HapticFeedback.lightImpact();
          Navigator.pushNamed(context, '/trade-detail');
        },
        child: Container(
          padding: EdgeInsets.all(3.w),
          decoration: BoxDecoration(
            color: colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: colorScheme.outline.withValues(alpha: 0.2),
              width: 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 12.w,
                height: 12.w,
                decoration: BoxDecoration(
                  color:
                      _getMarketColor(trade["symbol"] as String, colorScheme),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: Text(
                    _getMarketIcon(trade["symbol"] as String),
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 12.sp,
                    ),
                  ),
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          trade["symbol"] as String,
                          style: theme.textTheme.bodyMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                            color: colorScheme.onSurface,
                          ),
                        ),
                        Text(
                          isOpen
                              ? 'OPEN'
                              : (isProfit
                                  ? '+\$${pnl.toStringAsFixed(2)}'
                                  : '-\$${pnl.abs().toStringAsFixed(2)}'),
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: pnlColor,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 0.5.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 2.w, vertical: 0.2.h),
                              decoration: BoxDecoration(
                                color: trade["type"] == "Long"
                                    ? colorScheme.primary.withValues(alpha: 0.1)
                                    : colorScheme.error.withValues(alpha: 0.1),
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                trade["type"] as String,
                                style: theme.textTheme.bodySmall?.copyWith(
                                  color: trade["type"] == "Long"
                                      ? colorScheme.primary
                                      : colorScheme.error,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 9.sp,
                                ),
                              ),
                            ),
                            SizedBox(width: 2.w),
                            Text(
                              '${trade["quantity"]} units',
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: colorScheme.onSurfaceVariant,
                                fontSize: 10.sp,
                              ),
                            ),
                          ],
                        ),
                        Text(
                          _formatTimestamp(trade["timestamp"] as DateTime),
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: colorScheme.onSurfaceVariant,
                            fontSize: 10.sp,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getMarketColor(String symbol, ColorScheme colorScheme) {
    if (symbol.contains('BTC') || symbol.contains('ETH')) {
      return const Color(0xFFF7931A); // Bitcoin orange
    } else if (symbol.contains('/')) {
      return const Color(0xFF2E7D32); // Forex green
    } else {
      return colorScheme.primary; // Equity blue
    }
  }

  String _getMarketIcon(String symbol) {
    if (symbol.contains('BTC') || symbol.contains('ETH')) {
      return '₿';
    } else if (symbol.contains('/')) {
      return 'FX';
    } else {
      return symbol.substring(0, 2);
    }
  }

  String _formatTimestamp(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inDays}d ago';
    }
  }

  Future<bool> _showDeleteConfirmation(BuildContext context) async {
    return await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Delete Trade'),
            content: const Text(
                'Are you sure you want to delete this trade? This action cannot be undone.'),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: const Text('Cancel'),
              ),
              TextButton(
                onPressed: () => Navigator.of(context).pop(true),
                style: TextButton.styleFrom(
                  foregroundColor: Theme.of(context).colorScheme.error,
                ),
                child: const Text('Delete'),
              ),
            ],
          ),
        ) ??
        false;
  }
}
