import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class EquityCurveWidget extends StatefulWidget {
  const EquityCurveWidget({super.key});

  @override
  State<EquityCurveWidget> createState() => _EquityCurveWidgetState();
}

class _EquityCurveWidgetState extends State<EquityCurveWidget> {
  bool _showTooltip = false;
  int _touchedIndex = -1;

  final List<Map<String, dynamic>> _equityData = [
    {"date": "Jan 1", "balance": 10000.0, "timestamp": DateTime(2025, 1, 1)},
    {"date": "Jan 5", "balance": 10250.0, "timestamp": DateTime(2025, 1, 5)},
    {"date": "Jan 10", "balance": 9800.0, "timestamp": DateTime(2025, 1, 10)},
    {"date": "Jan 15", "balance": 10400.0, "timestamp": DateTime(2025, 1, 15)},
    {"date": "Jan 20", "balance": 10150.0, "timestamp": DateTime(2025, 1, 20)},
    {"date": "Jan 25", "balance": 10600.0, "timestamp": DateTime(2025, 1, 25)},
    {"date": "Jan 30", "balance": 10350.0, "timestamp": DateTime(2025, 1, 30)},
    {"date": "Feb 5", "balance": 10800.0, "timestamp": DateTime(2025, 2, 5)},
    {"date": "Feb 10", "balance": 11200.0, "timestamp": DateTime(2025, 2, 10)},
    {"date": "Feb 15", "balance": 10950.0, "timestamp": DateTime(2025, 2, 15)},
    {"date": "Feb 20", "balance": 11400.0, "timestamp": DateTime(2025, 2, 20)},
    {"date": "Feb 25", "balance": 11650.0, "timestamp": DateTime(2025, 2, 25)},
    {"date": "Mar 1", "balance": 11300.0, "timestamp": DateTime(2025, 3, 1)},
    {"date": "Mar 5", "balance": 11800.0, "timestamp": DateTime(2025, 3, 5)},
    {"date": "Mar 10", "balance": 12100.0, "timestamp": DateTime(2025, 3, 10)},
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
        width: double.infinity,
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
            color: colorScheme.surface,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                  color: colorScheme.shadow.withValues(alpha: 0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 2)),
            ]),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('Equity Curve',
                style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600, color: colorScheme.onSurface)),
            Row(children: [
              Container(
                  padding:
                      EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                  decoration: BoxDecoration(
                      color: colorScheme.primary.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(6)),
                  child: Text('3M',
                      style: theme.textTheme.bodySmall?.copyWith(
                          color: colorScheme.primary,
                          fontWeight: FontWeight.w600,
                          fontSize: 10.sp))),
              SizedBox(width: 2.w),
              CustomIconWidget(
                  iconName: 'fullscreen',
                  color: colorScheme.onSurfaceVariant,
                  size: 20),
            ]),
          ]),
          SizedBox(height: 3.h),
          SizedBox(
              height: 25.h,
              child: LineChart(LineChartData(
                  gridData: FlGridData(
                      show: true,
                      drawVerticalLine: false,
                      horizontalInterval: 500,
                      getDrawingHorizontalLine: (value) {
                        return FlLine(
                            color: colorScheme.outline.withValues(alpha: 0.2),
                            strokeWidth: 1);
                      }),
                  titlesData: FlTitlesData(
                      show: true,
                      rightTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                      topTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                      bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                              showTitles: true,
                              reservedSize: 30,
                              interval: 3,
                              getTitlesWidget: (double value, TitleMeta meta) {
                                final index = value.toInt();
                                if (index >= 0 && index < _equityData.length) {
                                  final data = _equityData[index];
                                  return SideTitleWidget(
                                      axisSide: meta.axisSide,
                                      child: Text(
                                          (data["date"] as String)
                                              .split(' ')[0],
                                          style: theme.textTheme.bodySmall
                                              ?.copyWith(
                                                  color: colorScheme
                                                      .onSurfaceVariant,
                                                  fontSize: 9.sp)));
                                }
                                return const Text('');
                              })),
                      leftTitles: AxisTitles(
                          sideTitles: SideTitles(
                              showTitles: true,
                              interval: 500,
                              reservedSize: 50,
                              getTitlesWidget: (double value, TitleMeta meta) {
                                return Text(
                                    '\$${(value / 1000).toStringAsFixed(1)}K',
                                    style: theme.textTheme.bodySmall?.copyWith(
                                        color: colorScheme.onSurfaceVariant,
                                        fontSize: 9.sp));
                              }))),
                  borderData: FlBorderData(show: false),
                  minX: 0,
                  maxX: (_equityData.length - 1).toDouble(),
                  minY: 9500,
                  maxY: 12500,
                  lineTouchData: LineTouchData(
                      enabled: true,
                      touchCallback: (FlTouchEvent event,
                          LineTouchResponse? touchResponse) {
                        setState(() {
                          if (touchResponse != null &&
                              touchResponse.lineBarSpots != null) {
                            _touchedIndex =
                                touchResponse.lineBarSpots!.first.spotIndex;
                            _showTooltip = true;
                          } else {
                            _showTooltip = false;
                            _touchedIndex = -1;
                          }
                        });
                      },
                      touchTooltipData: LineTouchTooltipData(
                          tooltipRoundedRadius: 8,
                          getTooltipItems: (List<LineBarSpot> touchedBarSpots) {
                            return touchedBarSpots.map((barSpot) {
                              final index = barSpot.spotIndex;
                              if (index >= 0 && index < _equityData.length) {
                                final data = _equityData[index];
                                return LineTooltipItem(
                                    '${data["date"]}\n\$${(data["balance"] as double).toStringAsFixed(2)}',
                                    TextStyle(
                                        color: colorScheme.onInverseSurface,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 11.sp));
                              }
                              return null;
                            }).toList();
                          })),
                  lineBarsData: [
                    LineChartBarData(
                        spots: _equityData.asMap().entries.map((entry) {
                          final index = entry.key;
                          final data = entry.value;
                          return FlSpot(
                              index.toDouble(), (data["balance"] as double));
                        }).toList(),
                        isCurved: true,
                        gradient: LinearGradient(colors: [
                          colorScheme.primary,
                          colorScheme.primary.withValues(alpha: 0.8),
                        ]),
                        barWidth: 3,
                        isStrokeCapRound: true,
                        dotData: FlDotData(
                            show: _showTooltip,
                            getDotPainter: (spot, percent, barData, index) {
                              if (index == _touchedIndex) {
                                return FlDotCirclePainter(
                                    radius: 6,
                                    color: colorScheme.primary,
                                    strokeWidth: 3,
                                    strokeColor: colorScheme.surface);
                              }
                              return FlDotCirclePainter(
                                  radius: 0, color: Colors.transparent);
                            }),
                        belowBarData: BarAreaData(
                            show: true,
                            gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  colorScheme.primary.withValues(alpha: 0.2),
                                  colorScheme.primary.withValues(alpha: 0.05),
                                ]))),
                  ]))),
          SizedBox(height: 2.h),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            _buildStatItem(
                context, 'Total Return', '+21.0%', colorScheme.primary),
            _buildStatItem(context, 'Max Drawdown', '-8.2%', colorScheme.error),
            _buildStatItem(
                context, 'Sharpe Ratio', '1.45', colorScheme.onSurfaceVariant),
          ]),
        ]));
  }

  Widget _buildStatItem(
      BuildContext context, String label, String value, Color valueColor) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
              fontSize: 10.sp)),
      SizedBox(height: 0.5.h),
      Text(value,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: valueColor, fontWeight: FontWeight.w600, fontSize: 12.sp)),
    ]);
  }
}
