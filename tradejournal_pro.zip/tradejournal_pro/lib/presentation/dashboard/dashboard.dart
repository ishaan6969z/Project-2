import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/equity_curve_widget.dart';
import './widgets/performance_card_widget.dart';
import './widgets/recent_trades_widget.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> with TickerProviderStateMixin {
  bool _isPrivacyMode = false;
  bool _isRefreshing = false;
  late AnimationController _refreshController;
  late Animation<double> _refreshAnimation;

  @override
  void initState() {
    super.initState();
    _refreshController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _refreshAnimation = CurvedAnimation(
      parent: _refreshController,
      curve: Curves.easeInOut,
    );
  }

  @override
  void dispose() {
    _refreshController.dispose();
    super.dispose();
  }

  Future<void> _handleRefresh() async {
    if (_isRefreshing) return;

    setState(() {
      _isRefreshing = true;
    });

    HapticFeedback.lightImpact();
    _refreshController.forward();

    // Simulate data refresh
    await Future.delayed(const Duration(seconds: 2));

    _refreshController.reverse();
    setState(() {
      _isRefreshing = false;
    });

    HapticFeedback.selectionClick();
  }

  void _togglePrivacyMode() {
    HapticFeedback.lightImpact();
    setState(() {
      _isPrivacyMode = !_isPrivacyMode;
    });
  }

  void _showQuickTradeModal() {
    HapticFeedback.mediumImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        height: 60.h,
        padding: EdgeInsets.all(6.w),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 12.w,
                height: 0.5.h,
                decoration: BoxDecoration(
                  color: Theme.of(context)
                      .colorScheme
                      .onSurfaceVariant
                      .withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'Quick Trade Entry',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
            SizedBox(height: 3.h),
            _buildQuickTradeButton(context, 'Add New Trade',
                Icons.add_circle_outline, '/add-trade'),
            SizedBox(height: 2.h),
            _buildQuickTradeButton(
                context, 'View All Trades', Icons.list_alt, '/trade-list'),
            SizedBox(height: 2.h),
            _buildQuickTradeButton(
                context, 'Analytics', Icons.analytics_outlined, '/analytics'),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/add-trade');
                },
                child: const Text('Start Trading'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickTradeButton(
      BuildContext context, String title, IconData icon, String route) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        Navigator.pop(context);
        Navigator.pushNamed(context, route);
      },
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: Theme.of(context)
              .colorScheme
              .surfaceContainerHighest
              .withValues(alpha: 0.5),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.2),
            width: 1,
          ),
        ),
        child: Row(
          children: [
            CustomIconWidget(
              iconName: _getIconName(icon),
              color: Theme.of(context).colorScheme.primary,
              size: 24,
            ),
            SizedBox(width: 4.w),
            Text(
              title,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    fontWeight: FontWeight.w500,
                  ),
            ),
            const Spacer(),
            CustomIconWidget(
              iconName: 'chevron_right',
              color: Theme.of(context).colorScheme.onSurfaceVariant,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }

  String _getIconName(IconData icon) {
    if (icon == Icons.add_circle_outline) return 'add_circle_outline';
    if (icon == Icons.list_alt) return 'list_alt';
    if (icon == Icons.analytics_outlined) return 'analytics_outlined';
    return 'circle';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      appBar: CustomAppBar.dashboard(
        actions: [
          IconButton(
            onPressed: _togglePrivacyMode,
            icon: CustomIconWidget(
              iconName: _isPrivacyMode ? 'visibility_off' : 'visibility',
              color: colorScheme.onSurface,
              size: 24,
            ),
            tooltip: _isPrivacyMode ? 'Show amounts' : 'Hide amounts',
          ),
          IconButton(
            onPressed: () {
              HapticFeedback.lightImpact();
              // Handle notifications
            },
            icon: Stack(
              children: [
                CustomIconWidget(
                  iconName: 'notifications_outlined',
                  color: colorScheme.onSurface,
                  size: 24,
                ),
                Positioned(
                  right: 0,
                  top: 0,
                  child: Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: colorScheme.error,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              ],
            ),
            tooltip: 'Notifications',
          ),
          IconButton(
            onPressed: () {
              HapticFeedback.lightImpact();
              // Handle settings
            },
            icon: CustomIconWidget(
              iconName: 'settings_outlined',
              color: colorScheme.onSurface,
              size: 24,
            ),
            tooltip: 'Settings',
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _handleRefresh,
        color: colorScheme.primary,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: EdgeInsets.all(4.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Welcome section
              Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Welcome back,',
                        style: theme.textTheme.bodyLarge?.copyWith(
                          color: colorScheme.onSurfaceVariant,
                        ),
                      ),
                      Text(
                        'Trader',
                        style: theme.textTheme.headlineMedium?.copyWith(
                          fontWeight: FontWeight.w700,
                          color: colorScheme.onSurface,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                    decoration: BoxDecoration(
                      color: colorScheme.primary.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: colorScheme.primary,
                            shape: BoxShape.circle,
                          ),
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          'Live',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: colorScheme.primary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height: 4.h),

              // Performance cards
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  PerformanceCardWidget(
                    title: 'Total P&L',
                    value: '\$2,145.75',
                    subtitle: 'All time',
                    valueColor: colorScheme.primary,
                    icon: Icons.trending_up,
                    isPrivacyMode: _isPrivacyMode,
                    onTap: () {
                      Navigator.pushNamed(context, '/analytics');
                    },
                  ),
                  PerformanceCardWidget(
                    title: 'Win Rate',
                    value: '68.5%',
                    subtitle: 'Last 30 trades',
                    valueColor: colorScheme.primary,
                    icon: Icons.percent,
                    isPrivacyMode: false, // Win rate is not sensitive
                  ),
                ],
              ),
              SizedBox(height: 3.h),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  PerformanceCardWidget(
                    title: 'This Month',
                    value: '\$485.20',
                    subtitle: 'March 2025',
                    valueColor: colorScheme.primary,
                    icon: Icons.calendar_month,
                    isPrivacyMode: _isPrivacyMode,
                  ),
                  PerformanceCardWidget(
                    title: 'Balance',
                    value: '\$12,100.00',
                    subtitle: 'Available',
                    valueColor: colorScheme.onSurface,
                    icon: Icons.account_balance_wallet,
                    isPrivacyMode: _isPrivacyMode,
                  ),
                ],
              ),
              SizedBox(height: 4.h),

              // Equity curve
              const EquityCurveWidget(),
              SizedBox(height: 4.h),

              // Recent trades
              const RecentTradesWidget(),
              SizedBox(height: 10.h), // Extra space for FAB
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showQuickTradeModal,
        tooltip: 'Quick Trade',
        child: AnimatedBuilder(
          animation: _refreshAnimation,
          builder: (context, child) {
            return Transform.rotate(
              angle: _refreshAnimation.value * 2 * 3.14159,
              child: CustomIconWidget(
                iconName: 'add',
                color: Colors.white,
                size: 28,
              ),
            );
          },
        ),
      ),
      bottomNavigationBar: const CustomBottomBar(
        currentIndex: 0,
      ),
    );
  }
}
