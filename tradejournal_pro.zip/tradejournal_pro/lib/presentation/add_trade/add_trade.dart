import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_export.dart';
import '../../theme/app_theme.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/confidence_slider_widget.dart';
import './widgets/emotional_state_widget.dart';
import './widgets/market_conditions_widget.dart';
import './widgets/market_selector_widget.dart';
import './widgets/position_toggle_widget.dart';
import './widgets/price_input_widget.dart';
import './widgets/quantity_input_widget.dart';
import './widgets/risk_reward_widget.dart';
import './widgets/screenshot_widget.dart';
import './widgets/strategy_tags_widget.dart';
import './widgets/symbol_input_widget.dart';
import './widgets/trade_thesis_widget.dart';
import 'widgets/confidence_slider_widget.dart';
import 'widgets/emotional_state_widget.dart';
import 'widgets/market_conditions_widget.dart';
import 'widgets/market_selector_widget.dart';
import 'widgets/position_toggle_widget.dart';
import 'widgets/price_input_widget.dart';
import 'widgets/quantity_input_widget.dart';
import 'widgets/risk_reward_widget.dart';
import 'widgets/screenshot_widget.dart';
import 'widgets/strategy_tags_widget.dart';
import 'widgets/symbol_input_widget.dart';
import 'widgets/trade_thesis_widget.dart';

class AddTrade extends StatefulWidget {
  const AddTrade({super.key});

  @override
  State<AddTrade> createState() => _AddTradeState();
}

class _AddTradeState extends State<AddTrade> with TickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _scrollController = ScrollController();

  // Trade data
  String _selectedMarket = 'Equity';
  String? _selectedSymbol;
  String _selectedPosition = 'Long';
  String? _entryPrice;
  String? _exitPrice;
  String? _stopLoss;
  String? _takeProfit;
  String? _quantity;
  String? _commission;
  double _confidence = 5.0;
  String? _emotionalState;
  List<String> _selectedTags = [];
  String? _tradeThesis;
  Map<String, dynamic> _marketConditions = {};
  List<XFile> _screenshots = [];

  bool _isLoading = false;
  bool _hasUnsavedChanges = false;

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _markAsChanged() {
    if (!_hasUnsavedChanges) {
      setState(() => _hasUnsavedChanges = true);
    }
  }

  Future<bool> _onWillPop() async {
    if (!_hasUnsavedChanges) return true;

    final shouldPop = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Discard Changes?',
          style: GoogleFonts.inter(
            fontSize: 18.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Text(
          'You have unsaved changes. Are you sure you want to discard them?',
          style: GoogleFonts.inter(
            fontSize: 14.sp,
            fontWeight: FontWeight.w400,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text(
              'Cancel',
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: Text(
              'Discard',
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                fontWeight: FontWeight.w500,
                color: Theme.of(context).colorScheme.error,
              ),
            ),
          ),
        ],
      ),
    );

    return shouldPop ?? false;
  }

  void _saveTrade() async {
    if (!_formKey.currentState!.validate()) {
      // Scroll to first error
      _scrollController.animateTo(
        0,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      // Generate trade ID
      final tradeId = 'TRD-${DateTime.now().millisecondsSinceEpoch}';

      // Calculate P&L if exit price is provided
      double? pnl;
      if (_exitPrice != null && _exitPrice!.isNotEmpty) {
        final entry = double.tryParse(_entryPrice ?? '0') ?? 0;
        final exit = double.tryParse(_exitPrice!) ?? 0;
        final qty = int.tryParse(_quantity ?? '0') ?? 0;
        final comm = double.tryParse(_commission ?? '0') ?? 0;

        if (_selectedPosition == 'Long') {
          pnl = (exit - entry) * qty - comm;
        } else {
          pnl = (entry - exit) * qty - comm;
        }
      }

      // Create trade data
      final tradeData = {
        'id': tradeId,
        'market': _selectedMarket,
        'symbol': _selectedSymbol,
        'position': _selectedPosition,
        'entryPrice': double.tryParse(_entryPrice ?? '0'),
        'exitPrice': _exitPrice != null && _exitPrice!.isNotEmpty
            ? double.tryParse(_exitPrice!)
            : null,
        'stopLoss': _stopLoss != null && _stopLoss!.isNotEmpty
            ? double.tryParse(_stopLoss!)
            : null,
        'takeProfit': _takeProfit != null && _takeProfit!.isNotEmpty
            ? double.tryParse(_takeProfit!)
            : null,
        'quantity': int.tryParse(_quantity ?? '0'),
        'commission': double.tryParse(_commission ?? '0'),
        'confidence': _confidence,
        'emotionalState': _emotionalState,
        'strategies': _selectedTags,
        'thesis': _tradeThesis,
        'marketConditions': _marketConditions,
        'screenshots': _screenshots.map((s) => s.path).toList(),
        'pnl': pnl,
        'status':
            _exitPrice != null && _exitPrice!.isNotEmpty ? 'Closed' : 'Open',
        'createdAt': DateTime.now().toIso8601String(),
        'updatedAt': DateTime.now().toIso8601String(),
      };

      // Simulate save delay
      await Future.delayed(const Duration(seconds: 1));

      // Show success message
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Trade saved successfully! ID: $tradeId',
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                fontWeight: FontWeight.w500,
              ),
            ),
            backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
            behavior: SnackBarBehavior.floating,
          ),
        );

        // Navigate back to dashboard
        Navigator.pushNamedAndRemoveUntil(
          context,
          '/dashboard',
          (route) => false,
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Error saving trade. Please try again.',
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                fontWeight: FontWeight.w500,
              ),
            ),
            backgroundColor: Theme.of(context).colorScheme.error,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  double _calculatePnL() {
    if (_entryPrice == null ||
        _entryPrice!.isEmpty ||
        _exitPrice == null ||
        _exitPrice!.isEmpty ||
        _quantity == null ||
        _quantity!.isEmpty) {
      return 0.0;
    }

    final entry = double.tryParse(_entryPrice!) ?? 0;
    final exit = double.tryParse(_exitPrice!) ?? 0;
    final qty = int.tryParse(_quantity!) ?? 0;
    final comm = double.tryParse(_commission ?? '0') ?? 0;

    if (_selectedPosition == 'Long') {
      return (exit - entry) * qty - comm;
    } else {
      return (entry - exit) * qty - comm;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final pnl = _calculatePnL();

    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        backgroundColor: colorScheme.surface,
        appBar: AppBar(
          title: Text(
            'Add Trade',
            style: GoogleFonts.inter(
              fontSize: 18.sp,
              fontWeight: FontWeight.w600,
              color: colorScheme.onSurface,
            ),
          ),
          leading: IconButton(
            onPressed: () async {
              if (await _onWillPop()) {
                Navigator.pop(context);
              }
            },
            icon: CustomIconWidget(
              iconName: 'arrow_back_ios_new',
              size: 20,
              color: colorScheme.onSurface,
            ),
          ),
          actions: [
            if (_hasUnsavedChanges)
              Container(
                margin: EdgeInsets.only(right: 2.w),
                child: CustomIconWidget(
                  iconName: 'circle',
                  size: 8,
                  color: colorScheme.error,
                ),
              ),
            TextButton(
              onPressed: _isLoading ? null : _saveTrade,
              child: _isLoading
                  ? SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor:
                            AlwaysStoppedAnimation<Color>(colorScheme.primary),
                      ),
                    )
                  : Text(
                      'Save',
                      style: GoogleFonts.inter(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w600,
                        color: colorScheme.primary,
                      ),
                    ),
            ),
          ],
          elevation: 0,
          backgroundColor: colorScheme.surface,
          surfaceTintColor: Colors.transparent,
        ),
        body: Form(
          key: _formKey,
          child: Column(
            children: [
              // P&L Display (if exit price is entered)
              if (_exitPrice != null && _exitPrice!.isNotEmpty && pnl != 0) ...[
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(4.w),
                  decoration: BoxDecoration(
                    color: pnl > 0
                        ? AppTheme.lightTheme.colorScheme.tertiary
                            .withValues(alpha: 0.1)
                        : colorScheme.error.withValues(alpha: 0.1),
                    border: Border(
                      bottom: BorderSide(
                        color: colorScheme.outline.withValues(alpha: 0.2),
                        width: 1,
                      ),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomIconWidget(
                        iconName: pnl > 0 ? 'trending_up' : 'trending_down',
                        size: 20,
                        color: pnl > 0
                            ? AppTheme.lightTheme.colorScheme.tertiary
                            : colorScheme.error,
                      ),
                      SizedBox(width: 2.w),
                      Text(
                        'P&L: ${pnl > 0 ? '+' : ''}\$${pnl.toStringAsFixed(2)}',
                        style: GoogleFonts.inter(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w700,
                          color: pnl > 0
                              ? AppTheme.lightTheme.colorScheme.tertiary
                              : colorScheme.error,
                        ),
                      ),
                    ],
                  ),
                ),
              ],

              // Form Content
              Expanded(
                child: SingleChildScrollView(
                  controller: _scrollController,
                  padding: EdgeInsets.all(4.w),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Market Selector
                      MarketSelectorWidget(
                        selectedMarket: _selectedMarket,
                        onMarketChanged: (market) {
                          setState(() {
                            _selectedMarket = market;
                            _selectedSymbol = null;
                            _marketConditions.clear();
                          });
                          _markAsChanged();
                        },
                      ),

                      SizedBox(height: 3.h),

                      // Symbol Input
                      SymbolInputWidget(
                        selectedMarket: _selectedMarket,
                        selectedSymbol: _selectedSymbol,
                        onSymbolChanged: (symbol) {
                          setState(() => _selectedSymbol = symbol);
                          _markAsChanged();
                        },
                      ),

                      SizedBox(height: 3.h),

                      // Position Toggle
                      PositionToggleWidget(
                        selectedPosition: _selectedPosition,
                        onPositionChanged: (position) {
                          setState(() => _selectedPosition = position);
                          _markAsChanged();
                        },
                      ),

                      SizedBox(height: 3.h),

                      // Price Inputs
                      Row(
                        children: [
                          Expanded(
                            child: PriceInputWidget(
                              label: 'Entry Price',
                              value: _entryPrice,
                              onChanged: (value) {
                                setState(() => _entryPrice = value);
                                _markAsChanged();
                              },
                              isRequired: true,
                            ),
                          ),
                          SizedBox(width: 4.w),
                          Expanded(
                            child: PriceInputWidget(
                              label: 'Exit Price',
                              value: _exitPrice,
                              onChanged: (value) {
                                setState(() => _exitPrice = value);
                                _markAsChanged();
                              },
                              hintText: 'Optional',
                            ),
                          ),
                        ],
                      ),

                      SizedBox(height: 3.h),

                      // Quantity Input
                      QuantityInputWidget(
                        quantity: _quantity,
                        onQuantityChanged: (quantity) {
                          setState(() => _quantity = quantity);
                          _markAsChanged();
                        },
                        entryPrice: _entryPrice,
                      ),

                      SizedBox(height: 3.h),

                      // Stop Loss and Take Profit
                      Row(
                        children: [
                          Expanded(
                            child: PriceInputWidget(
                              label: 'Stop Loss',
                              value: _stopLoss,
                              onChanged: (value) {
                                setState(() => _stopLoss = value);
                                _markAsChanged();
                              },
                            ),
                          ),
                          SizedBox(width: 4.w),
                          Expanded(
                            child: PriceInputWidget(
                              label: 'Take Profit',
                              value: _takeProfit,
                              onChanged: (value) {
                                setState(() => _takeProfit = value);
                                _markAsChanged();
                              },
                            ),
                          ),
                        ],
                      ),

                      SizedBox(height: 3.h),

                      // Commission
                      SizedBox(
                        width: 50.w,
                        child: PriceInputWidget(
                          label: 'Commission/Fees',
                          value: _commission,
                          onChanged: (value) {
                            setState(() => _commission = value);
                            _markAsChanged();
                          },
                          hintText: '0.00',
                        ),
                      ),

                      SizedBox(height: 3.h),

                      // Risk/Reward Analysis
                      RiskRewardWidget(
                        entryPrice: _entryPrice,
                        stopLoss: _stopLoss,
                        takeProfit: _takeProfit,
                      ),

                      SizedBox(height: 3.h),

                      // Confidence Slider
                      ConfidenceSliderWidget(
                        confidence: _confidence,
                        onConfidenceChanged: (confidence) {
                          setState(() => _confidence = confidence);
                          _markAsChanged();
                        },
                      ),

                      SizedBox(height: 3.h),

                      // Emotional State
                      EmotionalStateWidget(
                        selectedState: _emotionalState,
                        onStateChanged: (state) {
                          setState(() => _emotionalState = state);
                          _markAsChanged();
                        },
                      ),

                      SizedBox(height: 3.h),

                      // Strategy Tags
                      StrategyTagsWidget(
                        selectedTags: _selectedTags,
                        onTagsChanged: (tags) {
                          setState(() => _selectedTags = tags);
                          _markAsChanged();
                        },
                      ),

                      SizedBox(height: 3.h),

                      // Trade Thesis
                      TradeThesisWidget(
                        thesis: _tradeThesis,
                        onThesisChanged: (thesis) {
                          setState(() => _tradeThesis = thesis);
                          _markAsChanged();
                        },
                      ),

                      SizedBox(height: 3.h),

                      // Market Conditions
                      MarketConditionsWidget(
                        selectedMarket: _selectedMarket,
                        conditions: _marketConditions,
                        onConditionsChanged: (conditions) {
                          setState(() => _marketConditions = conditions);
                          _markAsChanged();
                        },
                      ),

                      SizedBox(height: 3.h),

                      // Screenshots
                      ScreenshotWidget(
                        screenshots: _screenshots,
                        onScreenshotsChanged: (screenshots) {
                          setState(() => _screenshots = screenshots);
                          _markAsChanged();
                        },
                      ),

                      SizedBox(height: 10.h),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}