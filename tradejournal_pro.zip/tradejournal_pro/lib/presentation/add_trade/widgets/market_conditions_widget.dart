import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class MarketConditionsWidget extends StatefulWidget {
  final String selectedMarket;
  final Map<String, dynamic> conditions;
  final Function(Map<String, dynamic>) onConditionsChanged;

  const MarketConditionsWidget({
    super.key,
    required this.selectedMarket,
    required this.conditions,
    required this.onConditionsChanged,
  });

  @override
  State<MarketConditionsWidget> createState() => _MarketConditionsWidgetState();
}

class _MarketConditionsWidgetState extends State<MarketConditionsWidget> {
  late Map<String, dynamic> _conditions;

  @override
  void initState() {
    super.initState();
    _conditions = Map<String, dynamic>.from(widget.conditions);
  }

  void _updateCondition(String key, dynamic value) {
    setState(() {
      _conditions[key] = value;
    });
    widget.onConditionsChanged(_conditions);
  }

  Widget _buildEquityConditions() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Market Conditions',
          style: TextStyle(
            fontSize: 14.sp,
            fontWeight: FontWeight.w500,
            color: colorScheme.onSurface,
          ),
        ),
        SizedBox(height: 2.h),
        DropdownButtonFormField<String>(
          value: _conditions['sector'] as String?,
          decoration: const InputDecoration(
            labelText: 'Sector',
            hintText: 'Select sector',
          ),
          items: [
            'Technology',
            'Healthcare',
            'Financial',
            'Energy',
            'Consumer Discretionary',
            'Consumer Staples',
            'Industrials',
            'Materials',
            'Utilities',
            'Real Estate',
            'Communication Services',
          ].map((sector) {
            return DropdownMenuItem<String>(
              value: sector,
              child: Text(sector),
            );
          }).toList(),
          onChanged: (value) => _updateCondition('sector', value),
        ),
        SizedBox(height: 2.h),
        DropdownButtonFormField<String>(
          value: _conditions['marketTrend'] as String?,
          decoration: const InputDecoration(
            labelText: 'Market Trend',
            hintText: 'Select market trend',
          ),
          items: [
            'Bullish',
            'Bearish',
            'Sideways',
            'Volatile',
          ].map((trend) {
            return DropdownMenuItem<String>(
              value: trend,
              child: Text(trend),
            );
          }).toList(),
          onChanged: (value) => _updateCondition('marketTrend', value),
        ),
        SizedBox(height: 2.h),
        TextFormField(
          initialValue: _conditions['economicEvent'] as String? ?? '',
          decoration: const InputDecoration(
            labelText: 'Economic Event (Optional)',
            hintText: 'e.g., Earnings, FDA Approval, etc.',
          ),
          onChanged: (value) => _updateCondition('economicEvent', value),
        ),
      ],
    );
  }

  Widget _buildCryptoConditions() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Crypto Market Conditions',
          style: TextStyle(
            fontSize: 14.sp,
            fontWeight: FontWeight.w500,
            color: colorScheme.onSurface,
          ),
        ),
        SizedBox(height: 2.h),
        TextFormField(
          initialValue: _conditions['btcDominance'] as String? ?? '',
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          inputFormatters: [
            FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*')),
          ],
          decoration: const InputDecoration(
            labelText: 'BTC Dominance (%)',
            hintText: 'e.g., 42.5',
            suffixText: '%',
          ),
          onChanged: (value) => _updateCondition('btcDominance', value),
        ),
        SizedBox(height: 2.h),
        DropdownButtonFormField<String>(
          value: _conditions['marketSentiment'] as String?,
          decoration: const InputDecoration(
            labelText: 'Market Sentiment',
            hintText: 'Select sentiment',
          ),
          items: [
            'Extreme Fear',
            'Fear',
            'Neutral',
            'Greed',
            'Extreme Greed',
          ].map((sentiment) {
            return DropdownMenuItem<String>(
              value: sentiment,
              child: Text(sentiment),
            );
          }).toList(),
          onChanged: (value) => _updateCondition('marketSentiment', value),
        ),
        SizedBox(height: 2.h),
        TextFormField(
          initialValue: _conditions['altcoinSeason'] as String? ?? '',
          decoration: const InputDecoration(
            labelText: 'Altcoin Season Index (Optional)',
            hintText: 'e.g., 75',
            suffixText: '/100',
          ),
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          onChanged: (value) => _updateCondition('altcoinSeason', value),
        ),
      ],
    );
  }

  Widget _buildForexConditions() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Forex Market Conditions',
          style: TextStyle(
            fontSize: 14.sp,
            fontWeight: FontWeight.w500,
            color: colorScheme.onSurface,
          ),
        ),
        SizedBox(height: 2.h),
        DropdownButtonFormField<String>(
          value: _conditions['session'] as String?,
          decoration: const InputDecoration(
            labelText: 'Trading Session',
            hintText: 'Select session',
          ),
          items: [
            'Asian Session',
            'European Session',
            'US Session',
            'Session Overlap',
          ].map((session) {
            return DropdownMenuItem<String>(
              value: session,
              child: Text(session),
            );
          }).toList(),
          onChanged: (value) => _updateCondition('session', value),
        ),
        SizedBox(height: 2.h),
        TextFormField(
          initialValue: _conditions['economicEvent'] as String? ?? '',
          decoration: const InputDecoration(
            labelText: 'Economic Event',
            hintText: 'e.g., NFP, FOMC, ECB Meeting',
          ),
          onChanged: (value) => _updateCondition('economicEvent', value),
        ),
        SizedBox(height: 2.h),
        DropdownButtonFormField<String>(
          value: _conditions['volatility'] as String?,
          decoration: const InputDecoration(
            labelText: 'Market Volatility',
            hintText: 'Select volatility level',
          ),
          items: [
            'Low',
            'Medium',
            'High',
            'Extreme',
          ].map((volatility) {
            return DropdownMenuItem<String>(
              value: volatility,
              child: Text(volatility),
            );
          }).toList(),
          onChanged: (value) => _updateCondition('volatility', value),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    switch (widget.selectedMarket) {
      case 'Equity':
        return _buildEquityConditions();
      case 'Crypto':
        return _buildCryptoConditions();
      case 'Forex':
        return _buildForexConditions();
      default:
        return const SizedBox.shrink();
    }
  }
}