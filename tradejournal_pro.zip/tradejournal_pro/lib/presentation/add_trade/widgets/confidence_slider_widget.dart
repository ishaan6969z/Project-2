import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class ConfidenceSliderWidget extends StatefulWidget {
  final double confidence;
  final Function(double) onConfidenceChanged;

  const ConfidenceSliderWidget({
    super.key,
    required this.confidence,
    required this.onConfidenceChanged,
  });

  @override
  State<ConfidenceSliderWidget> createState() => _ConfidenceSliderWidgetState();
}

class _ConfidenceSliderWidgetState extends State<ConfidenceSliderWidget> {
  Color _getConfidenceColor(double value) {
    if (value >= 8) return AppTheme.lightTheme.colorScheme.tertiary;
    if (value >= 6) return AppTheme.lightTheme.colorScheme.primary;
    if (value >= 4) return AppTheme.warningLight;
    return AppTheme.lightTheme.colorScheme.error;
  }

  String _getConfidenceLabel(double value) {
    if (value >= 9) return 'Very High';
    if (value >= 7) return 'High';
    if (value >= 5) return 'Medium';
    if (value >= 3) return 'Low';
    return 'Very Low';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Pre-Trade Confidence',
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                fontWeight: FontWeight.w500,
                color: colorScheme.onSurface,
              ),
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.5.h),
              decoration: BoxDecoration(
                color: _getConfidenceColor(widget.confidence)
                    .withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                _getConfidenceLabel(widget.confidence),
                style: GoogleFonts.inter(
                  fontSize: 12.sp,
                  fontWeight: FontWeight.w600,
                  color: _getConfidenceColor(widget.confidence),
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 2.h),
        Container(
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            color: colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '1',
                    style: GoogleFonts.inter(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w500,
                      color: colorScheme.onSurfaceVariant,
                    ),
                  ),
                  Text(
                    widget.confidence.toInt().toString(),
                    style: GoogleFonts.inter(
                      fontSize: 20.sp,
                      fontWeight: FontWeight.w700,
                      color: _getConfidenceColor(widget.confidence),
                    ),
                  ),
                  Text(
                    '10',
                    style: GoogleFonts.inter(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w500,
                      color: colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
              SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  activeTrackColor: _getConfidenceColor(widget.confidence),
                  thumbColor: _getConfidenceColor(widget.confidence),
                  overlayColor: _getConfidenceColor(widget.confidence)
                      .withValues(alpha: 0.2),
                  inactiveTrackColor:
                      colorScheme.outline.withValues(alpha: 0.3),
                  trackHeight: 4,
                  thumbShape:
                      const RoundSliderThumbShape(enabledThumbRadius: 10),
                  overlayShape:
                      const RoundSliderOverlayShape(overlayRadius: 20),
                ),
                child: Slider(
                  value: widget.confidence,
                  min: 1,
                  max: 10,
                  divisions: 9,
                  onChanged: (value) {
                    HapticFeedback.lightImpact();
                    widget.onConfidenceChanged(value);
                  },
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Low Confidence',
                    style: GoogleFonts.inter(
                      fontSize: 11.sp,
                      fontWeight: FontWeight.w400,
                      color: colorScheme.onSurfaceVariant,
                    ),
                  ),
                  Text(
                    'High Confidence',
                    style: GoogleFonts.inter(
                      fontSize: 11.sp,
                      fontWeight: FontWeight.w400,
                      color: colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}