import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

class RiskRewardWidget extends StatelessWidget {
  final String? entryPrice;
  final String? stopLoss;
  final String? takeProfit;

  const RiskRewardWidget({
    super.key,
    this.entryPrice,
    this.stopLoss,
    this.takeProfit,
  });

  double _calculateRiskRewardRatio() {
    final entry = double.tryParse(entryPrice ?? '0') ?? 0;
    final stop = double.tryParse(stopLoss ?? '0') ?? 0;
    final target = double.tryParse(takeProfit ?? '0') ?? 0;

    if (entry == 0 || stop == 0 || target == 0) return 0;

    final risk = (entry - stop).abs();
    final reward = (target - entry).abs();

    if (risk == 0) return 0;
    return reward / risk;
  }

  Color _getRiskRewardColor(double ratio, ColorScheme colorScheme) {
    if (ratio >= 2.0) return AppTheme.lightTheme.colorScheme.tertiary;
    if (ratio >= 1.5) return colorScheme.primary;
    if (ratio >= 1.0) return AppTheme.warningLight;
    return colorScheme.error;
  }

  String _getRiskRewardText(double ratio) {
    if (ratio == 0) return 'N/A';
    return '1:${ratio.toStringAsFixed(2)}';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final ratio = _calculateRiskRewardRatio();

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: _getRiskRewardColor(ratio, colorScheme).withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'trending_up',
                size: 20,
                color: _getRiskRewardColor(ratio, colorScheme),
              ),
              SizedBox(width: 2.w),
              Text(
                'Risk/Reward Analysis',
                style: GoogleFonts.inter(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w600,
                  color: colorScheme.onSurface,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Risk/Reward Ratio',
                    style: GoogleFonts.inter(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w400,
                      color: colorScheme.onSurfaceVariant,
                    ),
                  ),
                  SizedBox(height: 0.5.h),
                  Text(
                    _getRiskRewardText(ratio),
                    style: GoogleFonts.inter(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.w700,
                      color: _getRiskRewardColor(ratio, colorScheme),
                    ),
                  ),
                ],
              ),
              if (ratio > 0) ...[
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                  decoration: BoxDecoration(
                    color: _getRiskRewardColor(ratio, colorScheme)
                        .withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    ratio >= 2.0
                        ? 'Excellent'
                        : ratio >= 1.5
                            ? 'Good'
                            : ratio >= 1.0
                                ? 'Fair'
                                : 'Poor',
                    style: GoogleFonts.inter(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w600,
                      color: _getRiskRewardColor(ratio, colorScheme),
                    ),
                  ),
                ),
              ],
            ],
          ),
          if (ratio > 0) ...[
            SizedBox(height: 2.h),
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Risk Amount',
                        style: GoogleFonts.inter(
                          fontSize: 11.sp,
                          fontWeight: FontWeight.w400,
                          color: colorScheme.onSurfaceVariant,
                        ),
                      ),
                      Text(
                        '\$${((double.tryParse(entryPrice ?? '0') ?? 0) - (double.tryParse(stopLoss ?? '0') ?? 0)).abs().toStringAsFixed(2)}',
                        style: GoogleFonts.inter(
                          fontSize: 13.sp,
                          fontWeight: FontWeight.w600,
                          color: colorScheme.error,
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        'Reward Amount',
                        style: GoogleFonts.inter(
                          fontSize: 11.sp,
                          fontWeight: FontWeight.w400,
                          color: colorScheme.onSurfaceVariant,
                        ),
                      ),
                      Text(
                        '\$${((double.tryParse(takeProfit ?? '0') ?? 0) - (double.tryParse(entryPrice ?? '0') ?? 0)).abs().toStringAsFixed(2)}',
                        style: GoogleFonts.inter(
                          fontSize: 13.sp,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.lightTheme.colorScheme.tertiary,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}