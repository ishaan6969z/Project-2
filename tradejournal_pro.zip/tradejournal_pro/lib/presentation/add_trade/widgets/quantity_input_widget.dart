import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class QuantityInputWidget extends StatefulWidget {
  final String? quantity;
  final Function(String) onQuantityChanged;
  final String? entryPrice;

  const QuantityInputWidget({
    super.key,
    this.quantity,
    required this.onQuantityChanged,
    this.entryPrice,
  });

  @override
  State<QuantityInputWidget> createState() => _QuantityInputWidgetState();
}

class _QuantityInputWidgetState extends State<QuantityInputWidget> {
  late TextEditingController _controller;
  bool _showCalculator = false;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.quantity ?? '');
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _showPositionSizeCalculator() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildPositionSizeCalculator(),
    );
  }

  Widget _buildPositionSizeCalculator() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final accountBalanceController = TextEditingController(text: '10000');
    final riskPercentController = TextEditingController(text: '2');
    final stopLossController = TextEditingController();

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: colorScheme.onSurfaceVariant.withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          SizedBox(height: 3.h),
          Text(
            'Position Size Calculator',
            style: GoogleFonts.inter(
              fontSize: 18.sp,
              fontWeight: FontWeight.w600,
              color: colorScheme.onSurface,
            ),
          ),
          SizedBox(height: 3.h),
          TextFormField(
            controller: accountBalanceController,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'Account Balance',
              prefixText: '\$ ',
            ),
          ),
          SizedBox(height: 2.h),
          TextFormField(
            controller: riskPercentController,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'Risk Percentage',
              suffixText: '%',
            ),
          ),
          SizedBox(height: 2.h),
          TextFormField(
            controller: stopLossController,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'Stop Loss Price',
              prefixText: '\$ ',
            ),
          ),
          SizedBox(height: 3.h),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                final accountBalance =
                    double.tryParse(accountBalanceController.text) ?? 0;
                final riskPercent =
                    double.tryParse(riskPercentController.text) ?? 0;
                final entryPrice =
                    double.tryParse(widget.entryPrice ?? '0') ?? 0;
                final stopLoss = double.tryParse(stopLossController.text) ?? 0;

                if (accountBalance > 0 &&
                    riskPercent > 0 &&
                    entryPrice > 0 &&
                    stopLoss > 0) {
                  final riskAmount = accountBalance * (riskPercent / 100);
                  final priceRisk = (entryPrice - stopLoss).abs();
                  final quantity = (riskAmount / priceRisk).floor();

                  _controller.text = quantity.toString();
                  widget.onQuantityChanged(quantity.toString());
                  Navigator.pop(context);
                }
              },
              child: Text(
                'Calculate & Apply',
                style: GoogleFonts.inter(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
          SizedBox(height: 2.h),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              'Quantity',
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                fontWeight: FontWeight.w500,
                color: colorScheme.onSurface,
              ),
            ),
            Text(
              ' *',
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                fontWeight: FontWeight.w500,
                color: colorScheme.error,
              ),
            ),
            const Spacer(),
            GestureDetector(
              onTap: _showPositionSizeCalculator,
              child: Row(
                children: [
                  CustomIconWidget(
                    iconName: 'calculate',
                    size: 16,
                    color: colorScheme.primary,
                  ),
                  SizedBox(width: 1.w),
                  Text(
                    'Calculator',
                    style: GoogleFonts.inter(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w500,
                      color: colorScheme.primary,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        SizedBox(height: 1.h),
        TextFormField(
          controller: _controller,
          keyboardType: TextInputType.number,
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
          ],
          onChanged: (value) {
            widget.onQuantityChanged(value);
          },
          decoration: InputDecoration(
            hintText: 'Enter quantity',
            suffixIcon: _controller.text.isNotEmpty
                ? IconButton(
                    onPressed: () {
                      _controller.clear();
                      widget.onQuantityChanged('');
                    },
                    icon: CustomIconWidget(
                      iconName: 'clear',
                      size: 20,
                      color: colorScheme.onSurfaceVariant,
                    ),
                  )
                : null,
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Please enter quantity';
            }
            final quantity = int.tryParse(value);
            if (quantity == null || quantity <= 0) {
              return 'Please enter a valid quantity';
            }
            return null;
          },
        ),
      ],
    );
  }
}