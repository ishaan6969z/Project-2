import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

class EmotionalStateWidget extends StatelessWidget {
  final String? selectedState;
  final Function(String?) onStateChanged;

  const EmotionalStateWidget({
    super.key,
    this.selectedState,
    required this.onStateChanged,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final emotionalStates = [
      {
        'value': 'Confident',
        'icon': 'sentiment_very_satisfied',
        'color': AppTheme.lightTheme.colorScheme.tertiary
      },
      {
        'value': 'Calm',
        'icon': 'sentiment_satisfied',
        'color': colorScheme.primary
      },
      {
        'value': 'Neutral',
        'icon': 'sentiment_neutral',
        'color': colorScheme.onSurfaceVariant
      },
      {
        'value': 'Anxious',
        'icon': 'sentiment_dissatisfied',
        'color': AppTheme.warningLight
      },
      {
        'value': 'Fearful',
        'icon': 'sentiment_very_dissatisfied',
        'color': colorScheme.error
      },
      {
        'value': 'Greedy',
        'icon': 'attach_money',
        'color': AppTheme.warningLight
      },
      {'value': 'FOMO', 'icon': 'trending_up', 'color': colorScheme.error},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Emotional State',
          style: GoogleFonts.inter(
            fontSize: 14.sp,
            fontWeight: FontWeight.w500,
            color: colorScheme.onSurface,
          ),
        ),
        SizedBox(height: 1.h),
        DropdownButtonFormField<String>(
          value: selectedState,
          decoration: InputDecoration(
            hintText: 'Select your emotional state',
            prefixIcon: selectedState != null
                ? Padding(
                    padding: EdgeInsets.all(3.w),
                    child: CustomIconWidget(
                      iconName: emotionalStates.firstWhere((state) =>
                          state['value'] == selectedState)['icon'] as String,
                      size: 20,
                      color: emotionalStates.firstWhere((state) =>
                          state['value'] == selectedState)['color'] as Color,
                    ),
                  )
                : null,
          ),
          items: emotionalStates.map((state) {
            return DropdownMenuItem<String>(
              value: state['value'] as String,
              child: Row(
                children: [
                  CustomIconWidget(
                    iconName: state['icon'] as String,
                    size: 20,
                    color: state['color'] as Color,
                  ),
                  SizedBox(width: 3.w),
                  Text(
                    state['value'] as String,
                    style: GoogleFonts.inter(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w500,
                      color: colorScheme.onSurface,
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
          onChanged: onStateChanged,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Please select your emotional state';
            }
            return null;
          },
        ),
      ],
    );
  }
}