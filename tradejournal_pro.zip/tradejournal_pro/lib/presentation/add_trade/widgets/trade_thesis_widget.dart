import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class TradeThesisWidget extends StatefulWidget {
  final String? thesis;
  final Function(String) onThesisChanged;

  const TradeThesisWidget({
    super.key,
    this.thesis,
    required this.onThesisChanged,
  });

  @override
  State<TradeThesisWidget> createState() => _TradeThesisWidgetState();
}

class _TradeThesisWidgetState extends State<TradeThesisWidget> {
  late TextEditingController _controller;
  final int _maxLength = 500;
  bool _isListening = false;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.thesis ?? '');
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _startVoiceInput() {
    // Voice input functionality would be implemented here
    // For now, we'll show a placeholder
    setState(() => _isListening = true);

    // Simulate voice input completion after 3 seconds
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        setState(() => _isListening = false);
        // In real implementation, this would be the transcribed text
        const sampleText =
            "Strong bullish momentum with volume confirmation. Breaking above key resistance level.";
        _controller.text = widget.thesis ?? '' + sampleText;
        widget.onThesisChanged(_controller.text);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final currentLength = _controller.text.length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Trade Thesis & Reasoning',
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                fontWeight: FontWeight.w500,
                color: colorScheme.onSurface,
              ),
            ),
            Row(
              children: [
                GestureDetector(
                  onTap: _isListening ? null : _startVoiceInput,
                  child: Container(
                    padding: EdgeInsets.all(2.w),
                    decoration: BoxDecoration(
                      color: _isListening
                          ? colorScheme.error.withValues(alpha: 0.1)
                          : colorScheme.primary.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: CustomIconWidget(
                      iconName: _isListening ? 'mic' : 'mic_none',
                      size: 16,
                      color: _isListening
                          ? colorScheme.error
                          : colorScheme.primary,
                    ),
                  ),
                ),
                SizedBox(width: 2.w),
                Text(
                  '$currentLength/$_maxLength',
                  style: GoogleFonts.inter(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w400,
                    color: currentLength > _maxLength * 0.9
                        ? colorScheme.error
                        : colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ],
        ),
        SizedBox(height: 1.h),
        TextFormField(
          controller: _controller,
          maxLines: 4,
          maxLength: _maxLength,
          textInputAction: TextInputAction.newline,
          onChanged: (value) {
            widget.onThesisChanged(value);
            setState(() {});
          },
          decoration: InputDecoration(
            hintText:
                'Describe your trade setup, analysis, and reasoning...\n\nExample: "Strong bullish momentum after earnings beat. Breaking above 200 MA with high volume. Target previous high at \$150."',
            counterText: '',
            alignLabelWithHint: true,
            suffixIcon: _isListening
                ? Padding(
                    padding: EdgeInsets.all(3.w),
                    child: SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor:
                            AlwaysStoppedAnimation<Color>(colorScheme.error),
                      ),
                    ),
                  )
                : null,
          ),
          validator: (value) {
            if (value == null || value.trim().isEmpty) {
              return 'Please provide your trade thesis';
            }
            if (value.length < 20) {
              return 'Please provide more detailed reasoning (minimum 20 characters)';
            }
            return null;
          },
        ),
        if (_isListening) ...[
          SizedBox(height: 1.h),
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: colorScheme.error.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor:
                        AlwaysStoppedAnimation<Color>(colorScheme.error),
                  ),
                ),
                SizedBox(width: 3.w),
                Text(
                  'Listening... Speak your trade analysis',
                  style: GoogleFonts.inter(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w500,
                    color: colorScheme.error,
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}