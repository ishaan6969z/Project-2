import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class SymbolInputWidget extends StatefulWidget {
  final String selectedMarket;
  final String? selectedSymbol;
  final Function(String) onSymbolChanged;

  const SymbolInputWidget({
    super.key,
    required this.selectedMarket,
    this.selectedSymbol,
    required this.onSymbolChanged,
  });

  @override
  State<SymbolInputWidget> createState() => _SymbolInputWidgetState();
}

class _SymbolInputWidgetState extends State<SymbolInputWidget> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  bool _showSuggestions = false;
  List<String> _filteredSymbols = [];

  final Map<String, List<String>> _symbolsByMarket = {
    'Equity': [
      'AAPL',
      'GOOGL',
      'MSFT',
      'TSLA',
      'AMZN',
      'NVDA',
      'META',
      'NFLX',
      'AMD',
      'INTC'
    ],
    'Crypto': [
      'BTC/USD',
      'ETH/USD',
      'ADA/USD',
      'SOL/USD',
      'DOT/USD',
      'LINK/USD',
      'UNI/USD',
      'AVAX/USD',
      'MATIC/USD',
      'ATOM/USD'
    ],
    'Forex': [
      'EUR/USD',
      'GBP/USD',
      'USD/JPY',
      'AUD/USD',
      'USD/CAD',
      'USD/CHF',
      'NZD/USD',
      'EUR/GBP',
      'EUR/JPY',
      'GBP/JPY'
    ],
  };

  @override
  void initState() {
    super.initState();
    if (widget.selectedSymbol != null) {
      _controller.text = widget.selectedSymbol!;
    }
    _focusNode.addListener(_onFocusChange);
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _onFocusChange() {
    if (_focusNode.hasFocus) {
      _updateSuggestions(_controller.text);
      setState(() => _showSuggestions = true);
    } else {
      setState(() => _showSuggestions = false);
    }
  }

  void _updateSuggestions(String query) {
    final symbols = _symbolsByMarket[widget.selectedMarket] ?? [];
    if (query.isEmpty) {
      _filteredSymbols = symbols.take(5).toList();
    } else {
      _filteredSymbols = symbols
          .where((symbol) => symbol.toLowerCase().contains(query.toLowerCase()))
          .take(5)
          .toList();
    }
    setState(() {});
  }

  void _selectSymbol(String symbol) {
    _controller.text = symbol;
    widget.onSymbolChanged(symbol);
    _focusNode.unfocus();
    setState(() => _showSuggestions = false);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Symbol/Pair',
          style: GoogleFonts.inter(
            fontSize: 14.sp,
            fontWeight: FontWeight.w500,
            color: colorScheme.onSurface,
          ),
        ),
        SizedBox(height: 1.h),
        TextFormField(
          controller: _controller,
          focusNode: _focusNode,
          onChanged: (value) {
            _updateSuggestions(value);
            widget.onSymbolChanged(value);
          },
          decoration: InputDecoration(
            hintText: widget.selectedMarket == 'Equity'
                ? 'e.g., AAPL'
                : widget.selectedMarket == 'Crypto'
                    ? 'e.g., BTC/USD'
                    : 'e.g., EUR/USD',
            suffixIcon: _controller.text.isNotEmpty
                ? IconButton(
                    onPressed: () {
                      _controller.clear();
                      widget.onSymbolChanged('');
                      _updateSuggestions('');
                    },
                    icon: CustomIconWidget(
                      iconName: 'clear',
                      size: 20,
                      color: colorScheme.onSurfaceVariant,
                    ),
                  )
                : null,
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Please enter a symbol';
            }
            return null;
          },
        ),
        if (_showSuggestions && _filteredSymbols.isNotEmpty) ...[
          SizedBox(height: 1.h),
          Container(
            constraints: BoxConstraints(maxHeight: 25.h),
            decoration: BoxDecoration(
              color: colorScheme.surface,
              borderRadius: BorderRadius.circular(8),
              border:
                  Border.all(color: colorScheme.outline.withValues(alpha: 0.3)),
              boxShadow: [
                BoxShadow(
                  color: colorScheme.shadow.withValues(alpha: 0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: ListView.separated(
              shrinkWrap: true,
              itemCount: _filteredSymbols.length,
              separatorBuilder: (context, index) => Divider(
                height: 1,
                color: colorScheme.outline.withValues(alpha: 0.2),
              ),
              itemBuilder: (context, index) {
                final symbol = _filteredSymbols[index];
                return ListTile(
                  dense: true,
                  title: Text(
                    symbol,
                    style: GoogleFonts.inter(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w500,
                      color: colorScheme.onSurface,
                    ),
                  ),
                  onTap: () => _selectSymbol(symbol),
                );
              },
            ),
          ),
        ],
      ],
    );
  }
}