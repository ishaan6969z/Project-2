import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class MarketContextCard extends StatelessWidget {
  final Map<String, dynamic> trade;

  const MarketContextCard({
    super.key,
    required this.trade,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final marketType = (trade['market_type'] as String?) ?? 'equity';

    return Card(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CustomIconWidget(
                  iconName: _getMarketIcon(marketType),
                  color: colorScheme.primary,
                  size: 24,
                ),
                SizedBox(width: 2.w),
                Text(
                  'Market Context',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            SizedBox(height: 2.h),
            _buildMarketTypeInfo(context, marketType),
            SizedBox(height: 2.h),
            _buildMarketSpecificData(context, marketType),
            SizedBox(height: 2.h),
            _buildSetupAndStrategy(context),
          ],
        ),
      ),
    );
  }

  Widget _buildMarketTypeInfo(BuildContext context, String marketType) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: colorScheme.primary.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              color: colorScheme.primary,
              borderRadius: BorderRadius.circular(6),
            ),
            child: CustomIconWidget(
              iconName: _getMarketIcon(marketType),
              color: Colors.white,
              size: 20,
            ),
          ),
          SizedBox(width: 3.w),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                marketType.toUpperCase(),
                style: theme.textTheme.labelMedium?.copyWith(
                  color: colorScheme.primary,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(
                _getMarketDescription(marketType),
                style: theme.textTheme.bodySmall?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMarketSpecificData(BuildContext context, String marketType) {
    final theme = Theme.of(context);

    switch (marketType.toLowerCase()) {
      case 'crypto':
        return _buildCryptoData(context);
      case 'forex':
        return _buildForexData(context);
      case 'equity':
      default:
        return _buildEquityData(context);
    }
  }

  Widget _buildEquityData(BuildContext context) {
    final theme = Theme.of(context);
    final sectorPerformance = (trade['sector_performance'] as String?) ?? 'N/A';
    final marketCondition = (trade['market_condition'] as String?) ?? 'Neutral';

    return Column(
      children: [
        _buildContextRow(
          context,
          'Sector Performance',
          sectorPerformance,
          _getSectorColor(sectorPerformance),
        ),
        SizedBox(height: 1.h),
        _buildContextRow(
          context,
          'Market Condition',
          marketCondition,
          _getMarketConditionColor(marketCondition),
        ),
      ],
    );
  }

  Widget _buildCryptoData(BuildContext context) {
    final theme = Theme.of(context);
    final btcDominance = (trade['btc_dominance'] as double?) ?? 0.0;
    final marketSentiment = (trade['market_sentiment'] as String?) ?? 'Neutral';

    return Column(
      children: [
        _buildContextRow(
          context,
          'BTC Dominance',
          btcDominance > 0 ? '${btcDominance.toStringAsFixed(1)}%' : 'N/A',
          _getBtcDominanceColor(btcDominance),
        ),
        SizedBox(height: 1.h),
        _buildContextRow(
          context,
          'Market Sentiment',
          marketSentiment,
          _getMarketConditionColor(marketSentiment),
        ),
      ],
    );
  }

  Widget _buildForexData(BuildContext context) {
    final theme = Theme.of(context);
    final economicEvent = (trade['economic_event'] as String?) ?? 'None';
    final volatility = (trade['volatility'] as String?) ?? 'Normal';

    return Column(
      children: [
        _buildContextRow(
          context,
          'Economic Event',
          economicEvent,
          economicEvent != 'None'
              ? const Color(0xFFD97706)
              : const Color(0xFF64748B),
        ),
        SizedBox(height: 1.h),
        _buildContextRow(
          context,
          'Volatility',
          volatility,
          _getVolatilityColor(volatility),
        ),
      ],
    );
  }

  Widget _buildSetupAndStrategy(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final setupType = (trade['setup_type'] as String?) ?? 'Breakout';
    final strategy = (trade['strategy'] as String?) ?? 'Momentum';

    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Setup Type',
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                decoration: BoxDecoration(
                  color: _getSetupTypeColor(setupType).withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: _getSetupTypeColor(setupType).withValues(alpha: 0.3),
                    width: 1,
                  ),
                ),
                child: Text(
                  setupType,
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: _getSetupTypeColor(setupType),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Strategy',
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                decoration: BoxDecoration(
                  color: colorScheme.primary.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: colorScheme.primary.withValues(alpha: 0.3),
                    width: 1,
                  ),
                ),
                child: Text(
                  strategy,
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: colorScheme.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildContextRow(
      BuildContext context, String label, String value, Color valueColor) {
    final theme = Theme.of(context);

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        Text(
          value,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: valueColor,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  String _getMarketIcon(String marketType) {
    switch (marketType.toLowerCase()) {
      case 'crypto':
        return 'currency_bitcoin';
      case 'forex':
        return 'currency_exchange';
      case 'equity':
      default:
        return 'trending_up';
    }
  }

  String _getMarketDescription(String marketType) {
    switch (marketType.toLowerCase()) {
      case 'crypto':
        return 'Cryptocurrency Market';
      case 'forex':
        return 'Foreign Exchange Market';
      case 'equity':
      default:
        return 'Stock Market';
    }
  }

  Color _getSectorColor(String performance) {
    switch (performance.toLowerCase()) {
      case 'outperforming':
      case 'strong':
        return const Color(0xFF059669);
      case 'underperforming':
      case 'weak':
        return const Color(0xFFDC2626);
      case 'neutral':
      case 'mixed':
      default:
        return const Color(0xFFD97706);
    }
  }

  Color _getMarketConditionColor(String condition) {
    switch (condition.toLowerCase()) {
      case 'bullish':
      case 'positive':
      case 'greed':
        return const Color(0xFF059669);
      case 'bearish':
      case 'negative':
      case 'fear':
        return const Color(0xFFDC2626);
      case 'neutral':
      case 'sideways':
      default:
        return const Color(0xFFD97706);
    }
  }

  Color _getBtcDominanceColor(double dominance) {
    if (dominance >= 50) {
      return const Color(0xFF059669);
    } else if (dominance >= 40) {
      return const Color(0xFFD97706);
    } else {
      return const Color(0xFFDC2626);
    }
  }

  Color _getVolatilityColor(String volatility) {
    switch (volatility.toLowerCase()) {
      case 'low':
        return const Color(0xFF059669);
      case 'normal':
      case 'medium':
        return const Color(0xFFD97706);
      case 'high':
      case 'extreme':
        return const Color(0xFFDC2626);
      default:
        return const Color(0xFF64748B);
    }
  }

  Color _getSetupTypeColor(String setupType) {
    switch (setupType.toLowerCase()) {
      case 'breakout':
        return const Color(0xFF059669);
      case 'pullback':
        return const Color(0xFFD97706);
      case 'reversal':
        return const Color(0xFFDC2626);
      default:
        return const Color(0xFF64748B);
    }
  }
}
