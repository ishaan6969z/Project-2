import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class RiskAnalysisCard extends StatelessWidget {
  final Map<String, dynamic> trade;

  const RiskAnalysisCard({
    super.key,
    required this.trade,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final stopLoss = (trade['stop_loss'] as double?) ?? 0.0;
    final takeProfit = (trade['take_profit'] as double?) ?? 0.0;
    final riskRewardRatio = _calculateRiskRewardRatio();

    return Card(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Risk Analysis',
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 2.h),
            _buildRiskRow(
              context,
              'Stop Loss',
              stopLoss > 0 ? '\$${stopLoss.toStringAsFixed(2)}' : 'Not set',
              stopLoss > 0 ? colorScheme.error : colorScheme.onSurfaceVariant,
            ),
            SizedBox(height: 1.h),
            _buildRiskRow(
              context,
              'Take Profit',
              takeProfit > 0 ? '\$${takeProfit.toStringAsFixed(2)}' : 'Not set',
              takeProfit > 0
                  ? const Color(0xFF059669)
                  : colorScheme.onSurfaceVariant,
            ),
            SizedBox(height: 1.h),
            _buildRiskRow(
              context,
              'Risk/Reward Ratio',
              riskRewardRatio > 0
                  ? '1:${riskRewardRatio.toStringAsFixed(2)}'
                  : 'N/A',
              _getRiskRewardColor(riskRewardRatio),
            ),
            SizedBox(height: 2.h),
            if (riskRewardRatio > 0)
              _buildRiskRewardIndicator(context, riskRewardRatio),
            SizedBox(height: 1.h),
            _buildRiskMetrics(context),
          ],
        ),
      ),
    );
  }

  Widget _buildRiskRow(
      BuildContext context, String label, String value, Color valueColor) {
    final theme = Theme.of(context);

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        Text(
          value,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: valueColor,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Widget _buildRiskRewardIndicator(BuildContext context, double ratio) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: _getRiskRewardColor(ratio).withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Risk Assessment',
            style: theme.textTheme.labelMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 1.h),
          Row(
            children: [
              Expanded(
                flex: 1,
                child: Container(
                  height: 0.8.h,
                  decoration: BoxDecoration(
                    color: colorScheme.error,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                flex: ratio.round(),
                child: Container(
                  height: 0.8.h,
                  decoration: BoxDecoration(
                    color: const Color(0xFF059669),
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Risk: 1',
                style: theme.textTheme.labelSmall?.copyWith(
                  color: colorScheme.error,
                ),
              ),
              Text(
                'Reward: ${ratio.toStringAsFixed(1)}',
                style: theme.textTheme.labelSmall?.copyWith(
                  color: const Color(0xFF059669),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildRiskMetrics(BuildContext context) {
    final theme = Theme.of(context);
    final entryPrice = (trade['entry_price'] as double?) ?? 0.0;
    final quantity = (trade['quantity'] as int?) ?? 0;
    final stopLoss = (trade['stop_loss'] as double?) ?? 0.0;

    final positionSize = entryPrice * quantity;
    final riskAmount =
        stopLoss > 0 ? (entryPrice - stopLoss).abs() * quantity : 0.0;
    final riskPercentage =
        positionSize > 0 ? (riskAmount / positionSize) * 100 : 0.0;

    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Position Size',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
              Text(
                '\$${positionSize.toStringAsFixed(2)}',
                style: theme.textTheme.bodySmall?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          SizedBox(height: 0.5.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Risk Amount',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
              Text(
                '\$${riskAmount.toStringAsFixed(2)}',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.error,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          SizedBox(height: 0.5.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Risk %',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
              Text(
                '${riskPercentage.toStringAsFixed(2)}%',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: _getRiskPercentageColor(riskPercentage),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  double _calculateRiskRewardRatio() {
    final entryPrice = (trade['entry_price'] as double?) ?? 0.0;
    final stopLoss = (trade['stop_loss'] as double?) ?? 0.0;
    final takeProfit = (trade['take_profit'] as double?) ?? 0.0;
    final positionType = (trade['position_type'] as String?) ?? 'long';

    if (entryPrice == 0.0 || stopLoss == 0.0 || takeProfit == 0.0) return 0.0;

    double risk, reward;

    if (positionType.toLowerCase() == 'long') {
      risk = (entryPrice - stopLoss).abs();
      reward = (takeProfit - entryPrice).abs();
    } else {
      risk = (stopLoss - entryPrice).abs();
      reward = (entryPrice - takeProfit).abs();
    }

    return risk > 0 ? reward / risk : 0.0;
  }

  Color _getRiskRewardColor(double ratio) {
    if (ratio >= 2.0) {
      return const Color(0xFF059669);
    } else if (ratio >= 1.0) {
      return const Color(0xFFD97706);
    } else {
      return const Color(0xFFDC2626);
    }
  }

  Color _getRiskPercentageColor(double percentage) {
    if (percentage <= 2.0) {
      return const Color(0xFF059669);
    } else if (percentage <= 5.0) {
      return const Color(0xFFD97706);
    } else {
      return const Color(0xFFDC2626);
    }
  }
}
