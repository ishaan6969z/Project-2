import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class TradeSummaryCard extends StatelessWidget {
  final Map<String, dynamic> trade;

  const TradeSummaryCard({
    super.key,
    required this.trade,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Card(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Trade Summary',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Container(
                  padding:
                      EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.5.h),
                  decoration: BoxDecoration(
                    color: _getPositionColor(trade['position_type'])
                        .withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    (trade['position_type'] as String).toUpperCase(),
                    style: theme.textTheme.labelSmall?.copyWith(
                      color: _getPositionColor(trade['position_type']),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 2.h),
            _buildSummaryRow(
              context,
              'Entry Price',
              '\$${(trade['entry_price'] as double).toStringAsFixed(2)}',
            ),
            SizedBox(height: 1.h),
            _buildSummaryRow(
              context,
              'Exit Price',
              trade['exit_price'] != null
                  ? '\$${(trade['exit_price'] as double).toStringAsFixed(2)}'
                  : 'Not closed',
            ),
            SizedBox(height: 1.h),
            _buildSummaryRow(
              context,
              'Quantity',
              '${trade['quantity']} shares',
            ),
            SizedBox(height: 1.h),
            _buildSummaryRow(
              context,
              'Entry Date',
              _formatDate(trade['entry_date']),
            ),
            if (trade['exit_date'] != null) ...[
              SizedBox(height: 1.h),
              _buildSummaryRow(
                context,
                'Exit Date',
                _formatDate(trade['exit_date']),
              ),
            ],
            SizedBox(height: 1.h),
            _buildSummaryRow(
              context,
              'Duration',
              _calculateDuration(trade['entry_date'], trade['exit_date']),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryRow(BuildContext context, String label, String value) {
    final theme = Theme.of(context);

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        Text(
          value,
          style: theme.textTheme.bodyMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Color _getPositionColor(String positionType) {
    switch (positionType.toLowerCase()) {
      case 'long':
        return const Color(0xFF059669);
      case 'short':
        return const Color(0xFFDC2626);
      default:
        return const Color(0xFF64748B);
    }
  }

  String _formatDate(dynamic date) {
    if (date == null) return 'N/A';
    if (date is DateTime) {
      return '${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')}/${date.year}';
    }
    return date.toString();
  }

  String _calculateDuration(dynamic entryDate, dynamic exitDate) {
    if (entryDate == null) return 'N/A';
    if (exitDate == null) return 'Open';

    if (entryDate is DateTime && exitDate is DateTime) {
      final duration = exitDate.difference(entryDate);
      if (duration.inDays > 0) {
        return '${duration.inDays} days';
      } else if (duration.inHours > 0) {
        return '${duration.inHours} hours';
      } else {
        return '${duration.inMinutes} minutes';
      }
    }
    return 'N/A';
  }
}
