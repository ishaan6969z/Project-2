import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class PsychologySectionCard extends StatefulWidget {
  final Map<String, dynamic> trade;

  const PsychologySectionCard({
    super.key,
    required this.trade,
  });

  @override
  State<PsychologySectionCard> createState() => _PsychologySectionCardState();
}

class _PsychologySectionCardState extends State<PsychologySectionCard> {
  bool _isExpanded = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final confidence = (widget.trade['confidence_level'] as int?) ?? 5;
    final emotionalState =
        (widget.trade['emotional_state'] as String?) ?? 'Neutral';
    final postTradeAnalysis =
        (widget.trade['post_trade_analysis'] as String?) ?? '';

    return Card(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Psychology & Mindset',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    setState(() {
                      _isExpanded = !_isExpanded;
                    });
                  },
                  child: CustomIconWidget(
                    iconName: _isExpanded ? 'expand_less' : 'expand_more',
                    color: colorScheme.onSurfaceVariant,
                    size: 24,
                  ),
                ),
              ],
            ),
            SizedBox(height: 2.h),
            _buildConfidenceLevel(context, confidence),
            SizedBox(height: 2.h),
            _buildEmotionalState(context, emotionalState),
            if (_isExpanded) ...[
              SizedBox(height: 2.h),
              _buildPostTradeAnalysis(context, postTradeAnalysis),
              SizedBox(height: 2.h),
              _buildPsychologyMetrics(context),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildConfidenceLevel(BuildContext context, int confidence) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Pre-Trade Confidence',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: colorScheme.onSurfaceVariant,
              ),
            ),
            Text(
              '$confidence/10',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: _getConfidenceColor(confidence),
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        SizedBox(height: 1.h),
        Container(
          height: 0.8.h,
          decoration: BoxDecoration(
            color: colorScheme.outline.withValues(alpha: 0.3),
            borderRadius: BorderRadius.circular(4),
          ),
          child: FractionallySizedBox(
            alignment: Alignment.centerLeft,
            widthFactor: confidence / 10.0,
            child: Container(
              decoration: BoxDecoration(
                color: _getConfidenceColor(confidence),
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ),
        ),
        SizedBox(height: 0.5.h),
        Text(
          _getConfidenceLabel(confidence),
          style: theme.textTheme.labelSmall?.copyWith(
            color: _getConfidenceColor(confidence),
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget _buildEmotionalState(BuildContext context, String emotionalState) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          'Emotional State',
          style: theme.textTheme.bodyMedium?.copyWith(
            color: colorScheme.onSurfaceVariant,
          ),
        ),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.5.h),
          decoration: BoxDecoration(
            color:
                _getEmotionalStateColor(emotionalState).withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: _getEmotionalStateColor(emotionalState)
                  .withValues(alpha: 0.3),
              width: 1,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                _getEmotionalStateEmoji(emotionalState),
                style: TextStyle(fontSize: 14.sp),
              ),
              SizedBox(width: 1.w),
              Text(
                emotionalState,
                style: theme.textTheme.labelMedium?.copyWith(
                  color: _getEmotionalStateColor(emotionalState),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPostTradeAnalysis(BuildContext context, String analysis) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    if (analysis.isEmpty) {
      return Container(
        padding: EdgeInsets.all(3.w),
        decoration: BoxDecoration(
          color: colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: colorScheme.outline.withValues(alpha: 0.3),
            width: 1,
          ),
        ),
        child: Row(
          children: [
            CustomIconWidget(
              iconName: 'info_outline',
              color: colorScheme.onSurfaceVariant,
              size: 20,
            ),
            SizedBox(width: 2.w),
            Text(
              'No post-trade analysis available',
              style: theme.textTheme.bodySmall?.copyWith(
                color: colorScheme.onSurfaceVariant,
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Post-Trade Analysis',
          style: theme.textTheme.bodyMedium?.copyWith(
            color: colorScheme.onSurfaceVariant,
            fontWeight: FontWeight.w500,
          ),
        ),
        SizedBox(height: 1.h),
        Container(
          width: double.infinity,
          padding: EdgeInsets.all(3.w),
          decoration: BoxDecoration(
            color: colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            analysis,
            style: theme.textTheme.bodyMedium,
          ),
        ),
      ],
    );
  }

  Widget _buildPsychologyMetrics(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final sleepHours = (widget.trade['sleep_hours'] as double?) ?? 0.0;
    final stressLevel = (widget.trade['stress_level'] as int?) ?? 5;

    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'External Factors',
            style: theme.textTheme.labelMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 1.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Sleep Hours',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                ),
              ),
              Text(
                sleepHours > 0
                    ? '${sleepHours.toStringAsFixed(1)}h'
                    : 'Not recorded',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: _getSleepColor(sleepHours),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          SizedBox(height: 0.5.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Stress Level',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                ),
              ),
              Text(
                '$stressLevel/10',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: _getStressColor(stressLevel),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Color _getConfidenceColor(int confidence) {
    if (confidence >= 8) {
      return const Color(0xFF059669);
    } else if (confidence >= 6) {
      return const Color(0xFFD97706);
    } else {
      return const Color(0xFFDC2626);
    }
  }

  String _getConfidenceLabel(int confidence) {
    if (confidence >= 9) return 'Very High';
    if (confidence >= 7) return 'High';
    if (confidence >= 5) return 'Moderate';
    if (confidence >= 3) return 'Low';
    return 'Very Low';
  }

  Color _getEmotionalStateColor(String state) {
    switch (state.toLowerCase()) {
      case 'confident':
      case 'calm':
      case 'focused':
        return const Color(0xFF059669);
      case 'neutral':
      case 'cautious':
        return const Color(0xFFD97706);
      case 'anxious':
      case 'fearful':
      case 'greedy':
      case 'frustrated':
        return const Color(0xFFDC2626);
      default:
        return const Color(0xFF64748B);
    }
  }

  String _getEmotionalStateEmoji(String state) {
    switch (state.toLowerCase()) {
      case 'confident':
        return '😎';
      case 'calm':
        return '😌';
      case 'focused':
        return '🎯';
      case 'neutral':
        return '😐';
      case 'cautious':
        return '🤔';
      case 'anxious':
        return '😰';
      case 'fearful':
        return '😨';
      case 'greedy':
        return '🤑';
      case 'frustrated':
        return '😤';
      default:
        return '😐';
    }
  }

  Color _getSleepColor(double hours) {
    if (hours >= 7) {
      return const Color(0xFF059669);
    } else if (hours >= 5) {
      return const Color(0xFFD97706);
    } else {
      return const Color(0xFFDC2626);
    }
  }

  Color _getStressColor(int level) {
    if (level <= 3) {
      return const Color(0xFF059669);
    } else if (level <= 6) {
      return const Color(0xFFD97706);
    } else {
      return const Color(0xFFDC2626);
    }
  }
}
