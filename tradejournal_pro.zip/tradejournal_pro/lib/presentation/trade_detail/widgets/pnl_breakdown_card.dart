import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class PnlBreakdownCard extends StatelessWidget {
  final Map<String, dynamic> trade;

  const PnlBreakdownCard({
    super.key,
    required this.trade,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final grossPnl = _calculateGrossPnl();
    final commission = (trade['commission'] as double?) ?? 0.0;
    final fees = (trade['fees'] as double?) ?? 0.0;
    final netPnl = grossPnl - commission - fees;

    return Card(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'P&L Breakdown',
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 2.h),
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: _getPnlColor(netPnl).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _getPnlColor(netPnl).withValues(alpha: 0.3),
                  width: 1,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Net P&L',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    '${netPnl >= 0 ? '+' : ''}\$${netPnl.toStringAsFixed(2)}',
                    style: theme.textTheme.titleMedium?.copyWith(
                      color: _getPnlColor(netPnl),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 2.h),
            _buildBreakdownRow(
              context,
              'Gross P&L',
              '${grossPnl >= 0 ? '+' : ''}\$${grossPnl.toStringAsFixed(2)}',
              _getPnlColor(grossPnl),
            ),
            SizedBox(height: 1.h),
            _buildBreakdownRow(
              context,
              'Commission',
              '-\$${commission.toStringAsFixed(2)}',
              colorScheme.error,
            ),
            SizedBox(height: 1.h),
            _buildBreakdownRow(
              context,
              'Fees',
              '-\$${fees.toStringAsFixed(2)}',
              colorScheme.error,
            ),
            SizedBox(height: 1.h),
            Divider(color: colorScheme.outline.withValues(alpha: 0.3)),
            SizedBox(height: 1.h),
            _buildBreakdownRow(
              context,
              'Return %',
              '${_calculateReturnPercentage(netPnl).toStringAsFixed(2)}%',
              _getPnlColor(netPnl),
              isPercentage: true,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBreakdownRow(
    BuildContext context,
    String label,
    String value,
    Color valueColor, {
    bool isPercentage = false,
  }) {
    final theme = Theme.of(context);

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        Text(
          value,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: valueColor,
            fontWeight: isPercentage ? FontWeight.w700 : FontWeight.w600,
          ),
        ),
      ],
    );
  }

  double _calculateGrossPnl() {
    final entryPrice = (trade['entry_price'] as double?) ?? 0.0;
    final exitPrice = (trade['exit_price'] as double?) ?? 0.0;
    final quantity = (trade['quantity'] as int?) ?? 0;
    final positionType = (trade['position_type'] as String?) ?? 'long';

    if (exitPrice == 0.0) return 0.0;

    if (positionType.toLowerCase() == 'long') {
      return (exitPrice - entryPrice) * quantity;
    } else {
      return (entryPrice - exitPrice) * quantity;
    }
  }

  double _calculateReturnPercentage(double netPnl) {
    final entryPrice = (trade['entry_price'] as double?) ?? 0.0;
    final quantity = (trade['quantity'] as int?) ?? 0;
    final totalInvestment = entryPrice * quantity;

    if (totalInvestment == 0.0) return 0.0;
    return (netPnl / totalInvestment) * 100;
  }

  Color _getPnlColor(double value) {
    if (value > 0) {
      return const Color(0xFF059669);
    } else if (value < 0) {
      return const Color(0xFFDC2626);
    } else {
      return const Color(0xFF64748B);
    }
  }
}
