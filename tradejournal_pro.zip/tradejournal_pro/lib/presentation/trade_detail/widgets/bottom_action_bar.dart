import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class BottomActionBar extends StatelessWidget {
  final Map<String, dynamic> trade;
  final VoidCallback? onEdit;
  final VoidCallback? onDuplicate;
  final VoidCallback? onDelete;
  final VoidCallback? onShare;

  const BottomActionBar({
    super.key,
    required this.trade,
    this.onEdit,
    this.onDuplicate,
    this.onDelete,
    this.onShare,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      decoration: BoxDecoration(
        color: colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
          child: Row(
            children: [
              Expanded(
                child: _buildActionButton(
                  context,
                  icon: 'edit',
                  label: 'Edit',
                  color: colorScheme.primary,
                  onTap: () {
                    HapticFeedback.lightImpact();
                    if (onEdit != null) {
                      onEdit!();
                    } else {
                      Navigator.pushNamed(context, '/add-trade');
                    }
                  },
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: _buildActionButton(
                  context,
                  icon: 'content_copy',
                  label: 'Duplicate',
                  color: colorScheme.secondary,
                  onTap: () {
                    HapticFeedback.lightImpact();
                    if (onDuplicate != null) {
                      onDuplicate!();
                    } else {
                      _showDuplicateDialog(context);
                    }
                  },
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: _buildActionButton(
                  context,
                  icon: 'delete_outline',
                  label: 'Delete',
                  color: colorScheme.error,
                  onTap: () {
                    HapticFeedback.lightImpact();
                    if (onDelete != null) {
                      onDelete!();
                    } else {
                      _showDeleteDialog(context);
                    }
                  },
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: _buildActionButton(
                  context,
                  icon: 'share',
                  label: 'Share',
                  color: const Color(0xFF059669),
                  onTap: () {
                    HapticFeedback.lightImpact();
                    if (onShare != null) {
                      onShare!();
                    } else {
                      _showShareOptions(context);
                    }
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActionButton(
    BuildContext context, {
    required String icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    final theme = Theme.of(context);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 1.5.h),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: color.withValues(alpha: 0.3),
            width: 1,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CustomIconWidget(
              iconName: icon,
              color: color,
              size: 24,
            ),
            SizedBox(height: 0.5.h),
            Text(
              label,
              style: theme.textTheme.labelSmall?.copyWith(
                color: color,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showDeleteDialog(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              CustomIconWidget(
                iconName: 'warning_amber',
                color: colorScheme.error,
                size: 24,
              ),
              SizedBox(width: 2.w),
              Text(
                'Delete Trade',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Are you sure you want to delete this trade?',
                style: theme.textTheme.bodyMedium,
              ),
              SizedBox(height: 1.h),
              Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: colorScheme.error.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'info_outline',
                      color: colorScheme.error,
                      size: 20,
                    ),
                    SizedBox(width: 2.w),
                    Expanded(
                      child: Text(
                        'This action cannot be undone.',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: colorScheme.error,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text(
                'Cancel',
                style: theme.textTheme.labelMedium?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Trade deleted successfully'),
                    backgroundColor: colorScheme.error,
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: colorScheme.error,
                foregroundColor: Colors.white,
              ),
              child: Text('Delete'),
            ),
          ],
        );
      },
    );
  }

  void _showDuplicateDialog(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              CustomIconWidget(
                iconName: 'content_copy',
                color: colorScheme.secondary,
                size: 24,
              ),
              SizedBox(width: 2.w),
              Text(
                'Duplicate Trade',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          content: Text(
            'This will create a new trade with the same parameters. You can modify the details before saving.',
            style: theme.textTheme.bodyMedium,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text(
                'Cancel',
                style: theme.textTheme.labelMedium?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.pushNamed(context, '/add-trade');
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Trade duplicated - ready for editing'),
                    backgroundColor: colorScheme.secondary,
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: colorScheme.secondary,
                foregroundColor: Colors.white,
              ),
              child: Text('Duplicate'),
            ),
          ],
        );
      },
    );
  }

  void _showShareOptions(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (BuildContext context) {
        return Container(
          padding: EdgeInsets.all(4.w),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 12.w,
                height: 0.5.h,
                decoration: BoxDecoration(
                  color: colorScheme.outline.withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              SizedBox(height: 2.h),
              Text(
                'Share Trade',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 3.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildShareOption(
                    context,
                    icon: 'description',
                    label: 'Summary',
                    onTap: () {
                      Navigator.pop(context);
                      _shareTradeAsSummary(context);
                    },
                  ),
                  _buildShareOption(
                    context,
                    icon: 'image',
                    label: 'Screenshot',
                    onTap: () {
                      Navigator.pop(context);
                      _shareTradeAsImage(context);
                    },
                  ),
                  _buildShareOption(
                    context,
                    icon: 'file_download',
                    label: 'Export',
                    onTap: () {
                      Navigator.pop(context);
                      _exportTradeData(context);
                    },
                  ),
                ],
              ),
              SizedBox(height: 3.h),
            ],
          ),
        );
      },
    );
  }

  Widget _buildShareOption(
    BuildContext context, {
    required String icon,
    required String label,
    required VoidCallback onTap,
  }) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: colorScheme.primary.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(16),
            ),
            child: CustomIconWidget(
              iconName: icon,
              color: colorScheme.primary,
              size: 32,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            label,
            style: theme.textTheme.labelMedium?.copyWith(
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  void _shareTradeAsSummary(BuildContext context) {
    final symbol = trade['symbol'] ?? 'Unknown';
    final pnl = _calculateNetPnl();
    final positionType = trade['position_type'] ?? 'Long';
    final entryPrice = trade['entry_price'] ?? 0.0;
    final exitPrice = trade['exit_price'] ?? 0.0;

    final summary = '''
Trade Summary - $symbol

Position: $positionType
Entry: \$${entryPrice.toStringAsFixed(2)}
Exit: \$${exitPrice.toStringAsFixed(2)}
P&L: ${pnl >= 0 ? '+' : ''}\$${pnl.toStringAsFixed(2)}

Generated by TradeJournal Pro
''';

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Trade summary copied to clipboard'),
        backgroundColor: const Color(0xFF059669),
      ),
    );
  }

  void _shareTradeAsImage(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Screenshot feature coming soon'),
        backgroundColor: const Color(0xFFD97706),
      ),
    );
  }

  void _exportTradeData(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Trade data exported successfully'),
        backgroundColor: const Color(0xFF059669),
      ),
    );
  }

  double _calculateNetPnl() {
    final entryPrice = (trade['entry_price'] as double?) ?? 0.0;
    final exitPrice = (trade['exit_price'] as double?) ?? 0.0;
    final quantity = (trade['quantity'] as int?) ?? 0;
    final commission = (trade['commission'] as double?) ?? 0.0;
    final fees = (trade['fees'] as double?) ?? 0.0;
    final positionType = (trade['position_type'] as String?) ?? 'long';

    if (exitPrice == 0.0) return 0.0;

    double grossPnl;
    if (positionType.toLowerCase() == 'long') {
      grossPnl = (exitPrice - entryPrice) * quantity;
    } else {
      grossPnl = (entryPrice - exitPrice) * quantity;
    }

    return grossPnl - commission - fees;
  }
}
