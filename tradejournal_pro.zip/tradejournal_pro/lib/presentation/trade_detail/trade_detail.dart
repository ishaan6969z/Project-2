import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/bottom_action_bar.dart';
import './widgets/lessons_learned_card.dart';
import './widgets/market_context_card.dart';
import './widgets/pnl_breakdown_card.dart';
import './widgets/psychology_section_card.dart';
import './widgets/risk_analysis_card.dart';
import './widgets/screenshots_gallery.dart';
import './widgets/trade_summary_card.dart';

class TradeDetail extends StatefulWidget {
  const TradeDetail({super.key});

  @override
  State<TradeDetail> createState() => _TradeDetailState();
}

class _TradeDetailState extends State<TradeDetail> {
  late ScrollController _scrollController;
  bool _isAppBarCollapsed = false;

  // Mock trade data
  final Map<String, dynamic> _tradeData = {
    "id": "TRD-2025-001",
    "symbol": "AAPL",
    "market_type": "equity",
    "position_type": "long",
    "entry_price": 185.50,
    "exit_price": 192.75,
    "quantity": 100,
    "entry_date": DateTime(2025, 1, 8, 9, 30),
    "exit_date": DateTime(2025, 1, 10, 15, 45),
    "stop_loss": 180.00,
    "take_profit": 195.00,
    "commission": 2.50,
    "fees": 1.25,
    "confidence_level": 8,
    "emotional_state": "Confident",
    "post_trade_analysis":
        "Excellent execution on the breakout setup. Entry timing was perfect as the stock broke above the 185 resistance level with strong volume. The trade played out exactly as anticipated with the stock reaching near the take profit target.",
    "sleep_hours": 7.5,
    "stress_level": 3,
    "sector_performance": "Outperforming",
    "market_condition": "Bullish",
    "setup_type": "Breakout",
    "strategy": "Momentum",
    "trade_thesis":
        "AAPL showing strong momentum after breaking above key resistance at 185. Volume confirmation and positive sector rotation into tech stocks. Expecting continuation to 195 target based on measured move from consolidation pattern.",
    "exit_reasoning":
        "Took profits at 192.75 as stock approached take profit target and showed signs of exhaustion. RSI was overbought and volume was declining on the final push higher.",
    "lessons_learned":
        "Perfect example of patience paying off. Waited for proper breakout confirmation rather than jumping in early. Risk management worked well with tight stop loss placement.",
    "mistakes": [
      "Could have held for full target at 195",
      "Exit was slightly early due to fear of giving back profits"
    ],
    "success_factors": [
      "Excellent entry timing on breakout",
      "Strong volume confirmation",
      "Proper risk management with stop loss",
      "Good sector analysis before entry"
    ],
    "screenshots": [
      "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=400&h=600&fit=crop",
      "https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?w=400&h=600&fit=crop",
      "https://images.unsplash.com/photo-1642790106117-e829e14a795f?w=400&h=600&fit=crop"
    ]
  };

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    const double threshold = 100.0;
    final bool isCollapsed = _scrollController.offset > threshold;

    if (isCollapsed != _isAppBarCollapsed) {
      setState(() {
        _isAppBarCollapsed = isCollapsed;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      body: Column(
        children: [
          _buildCustomAppBar(context),
          Expanded(
            child: SingleChildScrollView(
              controller: _scrollController,
              physics: const BouncingScrollPhysics(),
              child: Column(
                children: [
                  _buildTradeHeader(context),
                  SizedBox(height: 1.h),
                  TradeSummaryCard(trade: _tradeData),
                  PnlBreakdownCard(trade: _tradeData),
                  RiskAnalysisCard(trade: _tradeData),
                  PsychologySectionCard(trade: _tradeData),
                  MarketContextCard(trade: _tradeData),
                  ScreenshotsGallery(
                      screenshots:
                          (_tradeData['screenshots'] as List).cast<String>()),
                  LessonsLearnedCard(trade: _tradeData),
                  SizedBox(height: 10.h), // Space for bottom action bar
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomActionBar(
        trade: _tradeData,
        onEdit: () => _handleEdit(context),
        onDuplicate: () => _handleDuplicate(context),
        onDelete: () => _handleDelete(context),
        onShare: () => _handleShare(context),
      ),
    );
  }

  Widget _buildCustomAppBar(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      decoration: BoxDecoration(
        color: colorScheme.surface,
        boxShadow: _isAppBarCollapsed
            ? [
                BoxShadow(
                  color: colorScheme.shadow.withValues(alpha: 0.1),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ]
            : null,
      ),
      child: SafeArea(
        child: Container(
          height: 7.h,
          padding: EdgeInsets.symmetric(horizontal: 4.w),
          child: Row(
            children: [
              GestureDetector(
                onTap: () {
                  HapticFeedback.lightImpact();
                  Navigator.of(context).pop();
                },
                child: Container(
                  padding: EdgeInsets.all(2.w),
                  decoration: BoxDecoration(
                    color: colorScheme.surfaceContainerHighest
                        .withValues(alpha: 0.5),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: CustomIconWidget(
                    iconName: 'arrow_back_ios',
                    color: colorScheme.onSurface,
                    size: 20,
                  ),
                ),
              ),
              SizedBox(width: 4.w),
              Expanded(
                child: AnimatedOpacity(
                  duration: const Duration(milliseconds: 200),
                  opacity: _isAppBarCollapsed ? 1.0 : 0.0,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        _tradeData['symbol'] ?? 'Trade Detail',
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        _getPnlText(),
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: _getPnlColor(),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              GestureDetector(
                onTap: () {
                  HapticFeedback.lightImpact();
                  Navigator.pushNamed(context, '/add-trade');
                },
                child: Container(
                  padding: EdgeInsets.all(2.w),
                  decoration: BoxDecoration(
                    color: colorScheme.primary.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: CustomIconWidget(
                    iconName: 'edit',
                    color: colorScheme.primary,
                    size: 20,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTradeHeader(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                decoration: BoxDecoration(
                  color: colorScheme.primary.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  _tradeData['id'] ?? 'TRD-001',
                  style: theme.textTheme.labelMedium?.copyWith(
                    color: colorScheme.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: [
              Text(
                _tradeData['symbol'] ?? 'SYMBOL',
                style: theme.textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                  letterSpacing: -0.5,
                ),
              ),
              SizedBox(width: 2.w),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                decoration: BoxDecoration(
                  color: _getPositionTypeColor().withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  (_tradeData['position_type'] as String? ?? 'LONG')
                      .toUpperCase(),
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: _getPositionTypeColor(),
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Text(
            _getPnlText(),
            style: theme.textTheme.headlineSmall?.copyWith(
              color: _getPnlColor(),
              fontWeight: FontWeight.w700,
            ),
          ),
          SizedBox(height: 0.5.h),
          Text(
            '${_calculateReturnPercentage().toStringAsFixed(2)}% Return',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: _getPnlColor(),
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  String _getPnlText() {
    final netPnl = _calculateNetPnl();
    return '${netPnl >= 0 ? '+' : ''}\$${netPnl.toStringAsFixed(2)}';
  }

  Color _getPnlColor() {
    final netPnl = _calculateNetPnl();
    if (netPnl > 0) {
      return const Color(0xFF059669);
    } else if (netPnl < 0) {
      return const Color(0xFFDC2626);
    } else {
      return const Color(0xFF64748B);
    }
  }

  Color _getPositionTypeColor() {
    final positionType =
        (_tradeData['position_type'] as String? ?? 'long').toLowerCase();
    return positionType == 'long'
        ? const Color(0xFF059669)
        : const Color(0xFFDC2626);
  }

  double _calculateNetPnl() {
    final entryPrice = (_tradeData['entry_price'] as double?) ?? 0.0;
    final exitPrice = (_tradeData['exit_price'] as double?) ?? 0.0;
    final quantity = (_tradeData['quantity'] as int?) ?? 0;
    final commission = (_tradeData['commission'] as double?) ?? 0.0;
    final fees = (_tradeData['fees'] as double?) ?? 0.0;
    final positionType = (_tradeData['position_type'] as String?) ?? 'long';

    if (exitPrice == 0.0) return 0.0;

    double grossPnl;
    if (positionType.toLowerCase() == 'long') {
      grossPnl = (exitPrice - entryPrice) * quantity;
    } else {
      grossPnl = (entryPrice - exitPrice) * quantity;
    }

    return grossPnl - commission - fees;
  }

  double _calculateReturnPercentage() {
    final entryPrice = (_tradeData['entry_price'] as double?) ?? 0.0;
    final quantity = (_tradeData['quantity'] as int?) ?? 0;
    final netPnl = _calculateNetPnl();
    final totalInvestment = entryPrice * quantity;

    if (totalInvestment == 0.0) return 0.0;
    return (netPnl / totalInvestment) * 100;
  }

  void _handleEdit(BuildContext context) {
    HapticFeedback.lightImpact();
    Navigator.pushNamed(context, '/add-trade');
  }

  void _handleDuplicate(BuildContext context) {
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Trade duplicated successfully'),
        backgroundColor: Theme.of(context).colorScheme.secondary,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _handleDelete(BuildContext context) {
    HapticFeedback.lightImpact();
    // Delete functionality handled in BottomActionBar widget
  }

  void _handleShare(BuildContext context) {
    HapticFeedback.lightImpact();
    // Share functionality handled in BottomActionBar widget
  }
}
