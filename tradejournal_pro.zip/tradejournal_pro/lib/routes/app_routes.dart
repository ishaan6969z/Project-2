import 'package:flutter/material.dart';
import '../presentation/login_screen/login_screen.dart';
import '../presentation/dashboard/dashboard.dart';
import '../presentation/trade_list/trade_list.dart';
import '../presentation/trade_detail/trade_detail.dart';
import '../presentation/analytics/analytics.dart';
import '../presentation/add_trade/add_trade.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String login = '/login-screen';
  static const String dashboard = '/dashboard';
  static const String tradeList = '/trade-list';
  static const String tradeDetail = '/trade-detail';
  static const String analytics = '/analytics';
  static const String addTrade = '/add-trade';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const LoginScreen(),
    login: (context) => const LoginScreen(),
    dashboard: (context) => const Dashboard(),
    tradeList: (context) => const TradeList(),
    tradeDetail: (context) => const TradeDetail(),
    analytics: (context) => const Analytics(),
    addTrade: (context) => const AddTrade(),
    // TODO: Add your other routes here
  };
}
