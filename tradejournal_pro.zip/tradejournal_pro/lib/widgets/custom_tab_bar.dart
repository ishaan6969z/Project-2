import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

enum CustomTabBarVariant {
  standard,
  pills,
  underline,
  segmented,
}

class CustomTabBar extends StatefulWidget implements PreferredSizeWidget {
  final List<String> tabs;
  final int currentIndex;
  final ValueChanged<int>? onTap;
  final CustomTabBarVariant variant;
  final Color? backgroundColor;
  final Color? selectedColor;
  final Color? unselectedColor;
  final Color? indicatorColor;
  final bool isScrollable;
  final EdgeInsetsGeometry? padding;
  final double height;

  const CustomTabBar({
    super.key,
    required this.tabs,
    required this.currentIndex,
    this.onTap,
    this.variant = CustomTabBarVariant.standard,
    this.backgroundColor,
    this.selectedColor,
    this.unselectedColor,
    this.indicatorColor,
    this.isScrollable = false,
    this.padding,
    this.height = 48,
  });

  @override
  State<CustomTabBar> createState() => _CustomTabBarState();

  @override
  Size get preferredSize => Size.fromHeight(height);

  /// Factory constructor for analytics tab bar
  factory CustomTabBar.analytics({
    Key? key,
    int currentIndex = 0,
    ValueChanged<int>? onTap,
  }) {
    return CustomTabBar(
      key: key,
      tabs: const ['Overview', 'Performance', 'Risk', 'History'],
      currentIndex: currentIndex,
      onTap: onTap,
      variant: CustomTabBarVariant.underline,
      isScrollable: true,
    );
  }

  /// Factory constructor for trade list filters
  factory CustomTabBar.tradeFilters({
    Key? key,
    int currentIndex = 0,
    ValueChanged<int>? onTap,
  }) {
    return CustomTabBar(
      key: key,
      tabs: const ['All', 'Wins', 'Losses', 'Pending'],
      currentIndex: currentIndex,
      onTap: onTap,
      variant: CustomTabBarVariant.pills,
      height: 40,
    );
  }

  /// Factory constructor for dashboard sections
  factory CustomTabBar.dashboard({
    Key? key,
    int currentIndex = 0,
    ValueChanged<int>? onTap,
  }) {
    return CustomTabBar(
      key: key,
      tabs: const ['Today', 'Week', 'Month', 'Year'],
      currentIndex: currentIndex,
      onTap: onTap,
      variant: CustomTabBarVariant.segmented,
      height: 44,
    );
  }
}

class _CustomTabBarState extends State<CustomTabBar>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 250),
      vsync: this,
    );
    _animation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _handleTap(int index) {
    if (index == widget.currentIndex) return;

    HapticFeedback.lightImpact();

    if (widget.onTap != null) {
      widget.onTap!(index);
    }

    _animationController.reset();
    _animationController.forward();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    switch (widget.variant) {
      case CustomTabBarVariant.standard:
        return _buildStandardTabBar(theme, colorScheme);
      case CustomTabBarVariant.pills:
        return _buildPillsTabBar(theme, colorScheme);
      case CustomTabBarVariant.underline:
        return _buildUnderlineTabBar(theme, colorScheme);
      case CustomTabBarVariant.segmented:
        return _buildSegmentedTabBar(theme, colorScheme);
    }
  }

  Widget _buildStandardTabBar(ThemeData theme, ColorScheme colorScheme) {
    return Container(
      height: widget.height,
      color: widget.backgroundColor ?? colorScheme.surface,
      padding: widget.padding ?? const EdgeInsets.symmetric(horizontal: 16),
      child: widget.isScrollable
          ? SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: _buildTabRow(theme, colorScheme),
            )
          : _buildTabRow(theme, colorScheme),
    );
  }

  Widget _buildPillsTabBar(ThemeData theme, ColorScheme colorScheme) {
    return Container(
      height: widget.height,
      color: widget.backgroundColor ?? colorScheme.surface,
      padding: widget.padding ?? const EdgeInsets.all(8),
      child: widget.isScrollable
          ? SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: _buildPillsRow(theme, colorScheme),
            )
          : _buildPillsRow(theme, colorScheme),
    );
  }

  Widget _buildUnderlineTabBar(ThemeData theme, ColorScheme colorScheme) {
    return Container(
      height: widget.height,
      decoration: BoxDecoration(
        color: widget.backgroundColor ?? colorScheme.surface,
        border: Border(
          bottom: BorderSide(
            color: colorScheme.outline.withValues(alpha: 0.2),
            width: 1,
          ),
        ),
      ),
      child: Stack(
        children: [
          if (widget.isScrollable)
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: _buildUnderlineRow(theme, colorScheme),
            )
          else
            _buildUnderlineRow(theme, colorScheme),
          _buildUnderlineIndicator(colorScheme),
        ],
      ),
    );
  }

  Widget _buildSegmentedTabBar(ThemeData theme, ColorScheme colorScheme) {
    return Container(
      height: widget.height,
      color: widget.backgroundColor ?? colorScheme.surface,
      padding: widget.padding ?? const EdgeInsets.all(4),
      child: Container(
        decoration: BoxDecoration(
          color: colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(8),
        ),
        child: _buildSegmentedRow(theme, colorScheme),
      ),
    );
  }

  Widget _buildTabRow(ThemeData theme, ColorScheme colorScheme) {
    return Row(
      mainAxisAlignment: widget.isScrollable
          ? MainAxisAlignment.start
          : MainAxisAlignment.spaceEvenly,
      children: widget.tabs.asMap().entries.map((entry) {
        final index = entry.key;
        final tab = entry.value;
        final isSelected = index == widget.currentIndex;

        return GestureDetector(
          onTap: () => _handleTap(index),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Text(
              tab,
              style: GoogleFonts.inter(
                fontSize: 14,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                color: isSelected
                    ? (widget.selectedColor ?? colorScheme.primary)
                    : (widget.unselectedColor ?? colorScheme.onSurfaceVariant),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildPillsRow(ThemeData theme, ColorScheme colorScheme) {
    return Row(
      mainAxisSize: widget.isScrollable ? MainAxisSize.min : MainAxisSize.max,
      mainAxisAlignment: widget.isScrollable
          ? MainAxisAlignment.start
          : MainAxisAlignment.spaceEvenly,
      children: widget.tabs.asMap().entries.map((entry) {
        final index = entry.key;
        final tab = entry.value;
        final isSelected = index == widget.currentIndex;

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: GestureDetector(
            onTap: () => _handleTap(index),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: isSelected
                    ? (widget.selectedColor ?? colorScheme.primary)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: isSelected
                      ? (widget.selectedColor ?? colorScheme.primary)
                      : colorScheme.outline.withValues(alpha: 0.5),
                  width: 1,
                ),
              ),
              child: Text(
                tab,
                style: GoogleFonts.inter(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: isSelected
                      ? Colors.white
                      : (widget.unselectedColor ??
                          colorScheme.onSurfaceVariant),
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildUnderlineRow(ThemeData theme, ColorScheme colorScheme) {
    return Row(
      mainAxisSize: widget.isScrollable ? MainAxisSize.min : MainAxisSize.max,
      mainAxisAlignment: widget.isScrollable
          ? MainAxisAlignment.start
          : MainAxisAlignment.spaceEvenly,
      children: widget.tabs.asMap().entries.map((entry) {
        final index = entry.key;
        final tab = entry.value;
        final isSelected = index == widget.currentIndex;

        return GestureDetector(
          onTap: () => _handleTap(index),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Text(
              tab,
              style: GoogleFonts.inter(
                fontSize: 14,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                color: isSelected
                    ? (widget.selectedColor ?? colorScheme.primary)
                    : (widget.unselectedColor ?? colorScheme.onSurfaceVariant),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildSegmentedRow(ThemeData theme, ColorScheme colorScheme) {
    return Row(
      children: widget.tabs.asMap().entries.map((entry) {
        final index = entry.key;
        final tab = entry.value;
        final isSelected = index == widget.currentIndex;

        return Expanded(
          child: GestureDetector(
            onTap: () => _handleTap(index),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.all(2),
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: isSelected
                    ? (widget.selectedColor ?? colorScheme.surface)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(6),
                boxShadow: isSelected
                    ? [
                        BoxShadow(
                          color: colorScheme.shadow.withValues(alpha: 0.1),
                          blurRadius: 2,
                          offset: const Offset(0, 1),
                        ),
                      ]
                    : null,
              ),
              child: Center(
                child: Text(
                  tab,
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: isSelected
                        ? colorScheme.onSurface
                        : (widget.unselectedColor ??
                            colorScheme.onSurfaceVariant),
                  ),
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildUnderlineIndicator(ColorScheme colorScheme) {
    if (widget.variant != CustomTabBarVariant.underline) {
      return const SizedBox.shrink();
    }

    final tabWidth = MediaQuery.of(context).size.width / widget.tabs.length;
    final indicatorWidth = tabWidth * 0.6;
    final indicatorOffset = (tabWidth - indicatorWidth) / 2;

    return Positioned(
      bottom: 0,
      left: widget.currentIndex * tabWidth + indicatorOffset,
      child: AnimatedBuilder(
        animation: _animation,
        builder: (context, child) {
          return Container(
            width: indicatorWidth,
            height: 2,
            decoration: BoxDecoration(
              color: widget.indicatorColor ?? colorScheme.primary,
              borderRadius: BorderRadius.circular(1),
            ),
          );
        },
      ),
    );
  }
}
