import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

enum CustomAppBarVariant {
  primary,
  secondary,
  transparent,
  minimal,
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String? title;
  final List<Widget>? actions;
  final Widget? leading;
  final bool automaticallyImplyLeading;
  final CustomAppBarVariant variant;
  final bool centerTitle;
  final double? elevation;
  final Color? backgroundColor;
  final Color? foregroundColor;
  final bool showBackButton;
  final VoidCallback? onBackPressed;
  final PreferredSizeWidget? bottom;
  final double toolbarHeight;

  const CustomAppBar({
    super.key,
    this.title,
    this.actions,
    this.leading,
    this.automaticallyImplyLeading = true,
    this.variant = CustomAppBarVariant.primary,
    this.centerTitle = true,
    this.elevation,
    this.backgroundColor,
    this.foregroundColor,
    this.showBackButton = false,
    this.onBackPressed,
    this.bottom,
    this.toolbarHeight = kToolbarHeight,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final isDark = theme.brightness == Brightness.dark;

    // Determine colors based on variant
    Color? appBarBackgroundColor;
    Color? appBarForegroundColor;
    double appBarElevation;
    SystemUiOverlayStyle overlayStyle;

    switch (variant) {
      case CustomAppBarVariant.primary:
        appBarBackgroundColor = backgroundColor ?? colorScheme.surface;
        appBarForegroundColor = foregroundColor ?? colorScheme.onSurface;
        appBarElevation = elevation ?? 0;
        overlayStyle =
            isDark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark;
        break;
      case CustomAppBarVariant.secondary:
        appBarBackgroundColor =
            backgroundColor ?? colorScheme.surfaceContainerHighest;
        appBarForegroundColor = foregroundColor ?? colorScheme.onSurface;
        appBarElevation = elevation ?? 2;
        overlayStyle =
            isDark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark;
        break;
      case CustomAppBarVariant.transparent:
        appBarBackgroundColor = backgroundColor ?? Colors.transparent;
        appBarForegroundColor = foregroundColor ?? colorScheme.onSurface;
        appBarElevation = elevation ?? 0;
        overlayStyle =
            isDark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark;
        break;
      case CustomAppBarVariant.minimal:
        appBarBackgroundColor = backgroundColor ?? colorScheme.surface;
        appBarForegroundColor = foregroundColor ?? colorScheme.onSurface;
        appBarElevation = elevation ?? 0;
        overlayStyle =
            isDark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark;
        break;
    }

    Widget? leadingWidget;
    if (leading != null) {
      leadingWidget = leading;
    } else if (showBackButton ||
        (automaticallyImplyLeading && Navigator.of(context).canPop())) {
      leadingWidget = IconButton(
        icon: Icon(
          Icons.arrow_back_ios_new,
          color: appBarForegroundColor,
          size: 20,
        ),
        onPressed: onBackPressed ?? () => Navigator.of(context).pop(),
        tooltip: 'Back',
      );
    }

    return AppBar(
      title: title != null
          ? Text(
              title!,
              style: GoogleFonts.inter(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: appBarForegroundColor,
              ),
            )
          : null,
      leading: leadingWidget,
      actions: actions?.map((action) {
        if (action is IconButton) {
          return IconButton(
            icon: action.icon,
            onPressed: action.onPressed,
            tooltip: action.tooltip,
            color: appBarForegroundColor,
          );
        }
        return action;
      }).toList(),
      automaticallyImplyLeading: automaticallyImplyLeading,
      centerTitle: centerTitle,
      elevation: appBarElevation,
      backgroundColor: appBarBackgroundColor,
      foregroundColor: appBarForegroundColor,
      surfaceTintColor: Colors.transparent,
      systemOverlayStyle: overlayStyle,
      bottom: bottom,
      toolbarHeight: toolbarHeight,
      shape: variant == CustomAppBarVariant.minimal
          ? const Border(
              bottom: BorderSide(
                color: Colors.transparent,
                width: 0,
              ),
            )
          : null,
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(
        toolbarHeight + (bottom?.preferredSize.height ?? 0.0),
      );

  /// Factory constructor for dashboard app bar
  factory CustomAppBar.dashboard({
    Key? key,
    String? title,
    List<Widget>? actions,
  }) {
    return CustomAppBar(
      key: key,
      title: title ?? 'Trading Journal',
      variant: CustomAppBarVariant.primary,
      centerTitle: false,
      actions: actions ??
          [
            Builder(
              builder: (context) => IconButton(
                icon: const Icon(Icons.notifications_outlined),
                onPressed: () {
                  // Handle notifications
                  HapticFeedback.lightImpact();
                },
                tooltip: 'Notifications',
              ),
            ),
            Builder(
              builder: (context) => IconButton(
                icon: const Icon(Icons.settings_outlined),
                onPressed: () {
                  // Handle settings
                  HapticFeedback.lightImpact();
                },
                tooltip: 'Settings',
              ),
            ),
          ],
    );
  }

  /// Factory constructor for trade detail app bar
  factory CustomAppBar.tradeDetail({
    Key? key,
    String? title,
    List<Widget>? actions,
  }) {
    return CustomAppBar(
      key: key,
      title: title ?? 'Trade Details',
      variant: CustomAppBarVariant.primary,
      showBackButton: true,
      actions: actions ??
          [
            Builder(
              builder: (context) => IconButton(
                icon: const Icon(Icons.edit_outlined),
                onPressed: () {
                  // Navigate to edit trade
                  HapticFeedback.lightImpact();
                  Navigator.pushNamed(context, '/add-trade');
                },
                tooltip: 'Edit Trade',
              ),
            ),
            Builder(
              builder: (context) => IconButton(
                icon: const Icon(Icons.share_outlined),
                onPressed: () {
                  // Handle share
                  HapticFeedback.lightImpact();
                },
                tooltip: 'Share',
              ),
            ),
          ],
    );
  }

  /// Factory constructor for add trade app bar
  factory CustomAppBar.addTrade({
    Key? key,
    String? title,
    VoidCallback? onSave,
  }) {
    return CustomAppBar(
      key: key,
      title: title ?? 'Add Trade',
      variant: CustomAppBarVariant.primary,
      showBackButton: true,
      actions: [
        Builder(
          builder: (context) => TextButton(
            onPressed: onSave ??
                () {
                  // Handle save
                  HapticFeedback.lightImpact();
                  Navigator.pop(context);
                },
            child: Text(
              'Save',
              style: GoogleFonts.inter(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
          ),
        ),
      ],
    );
  }

  /// Factory constructor for analytics app bar
  factory CustomAppBar.analytics({
    Key? key,
    String? title,
    List<Widget>? actions,
  }) {
    return CustomAppBar(
      key: key,
      title: title ?? 'Analytics',
      variant: CustomAppBarVariant.primary,
      centerTitle: false,
      actions: actions ??
          [
            Builder(
              builder: (context) => IconButton(
                icon: const Icon(Icons.filter_list_outlined),
                onPressed: () {
                  // Handle filter
                  HapticFeedback.lightImpact();
                },
                tooltip: 'Filter',
              ),
            ),
            Builder(
              builder: (context) => IconButton(
                icon: const Icon(Icons.download_outlined),
                onPressed: () {
                  // Handle export
                  HapticFeedback.lightImpact();
                },
                tooltip: 'Export',
              ),
            ),
          ],
    );
  }

  /// Factory constructor for minimal app bar
  factory CustomAppBar.minimal({
    Key? key,
    String? title,
    bool showBackButton = false,
  }) {
    return CustomAppBar(
      key: key,
      title: title,
      variant: CustomAppBarVariant.minimal,
      showBackButton: showBackButton,
      elevation: 0,
    );
  }
}
